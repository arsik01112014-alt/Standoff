#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

if ! command -v xcodebuild >/dev/null 2>&1; then
  echo "xcodebuild не найден. Нужен macOS + Xcode." >&2
  exit 1
fi
if ! command -v node >/dev/null 2>&1; then
  echo "node не найден." >&2
  exit 1
fi

node sync-web.mjs
npm install

if [ ! -d ios ]; then
  npx cap add ios
fi
npx cap sync ios

cd ios/App
rm -rf build
xcodebuild \
  -workspace App.xcworkspace \
  -scheme App \
  -configuration Release \
  -sdk iphoneos \
  -derivedDataPath build \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY="" \
  DEVELOPMENT_TEAM="" \
  build

APP="build/Build/Products/Release-iphoneos/App.app"
if [ ! -d "$APP" ]; then
  echo "Не найден $APP" >&2
  exit 1
fi

cd ../..
rm -rf Payload Standoff3Reborn-unsigned.ipa
mkdir Payload
cp -R "ios/App/$APP" Payload/App.app
zip -qry Standoff3Reborn-unsigned.ipa Payload
rm -rf Payload
echo "Готово: $(pwd)/Standoff3Reborn-unsigned.ipa"
