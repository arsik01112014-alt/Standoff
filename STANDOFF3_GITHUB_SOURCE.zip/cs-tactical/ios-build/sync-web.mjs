import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve('..');
const out = path.resolve('www');

fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(out, { recursive: true });
fs.copyFileSync(path.join(root, 'index.html'), path.join(out, 'index.html'));
fs.cpSync(path.join(root, 'css'), path.join(out, 'css'), { recursive: true });
fs.cpSync(path.join(root, 'dist'), path.join(out, 'dist'), { recursive: true });
console.log('ios-build/www synced from project root');
