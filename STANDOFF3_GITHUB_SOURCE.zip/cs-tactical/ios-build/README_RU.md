# STANDOFF 3 REBORN — iOS / IPA

В Termux нельзя собрать устанавливаемый `.ipa`: нужны macOS, Xcode, iOS SDK и подпись Apple. Этот каталог — готовый каркас Capacitor, который собирает `.ipa` на Mac или в GitHub Actions.

## Вариант A: Mac + Xcode

Требуется macOS, Xcode и CocoaPods.

```bash
cd ~/cs-tactical
node build.js
cd ios-build
npm install
bash build-unsigned-ipa.sh
```

Результат: `ios-build/Standoff3Reborn-unsigned.ipa` (без подписи).

Подписанный IPA:

```bash
cd ios-build
npx cap open ios
```

В Xcode выбери свою Team, устройство и сделай Product → Archive → Distribute App. Либо подпиши готовый unsigned IPA через Sideloadly / AltStore / ReSign.

## Вариант B: GitHub Actions

Загрузи проект в GitHub и запусти workflow `Build unsigned iOS IPA` вручную (Actions → Run workflow). Готовый артефакт `Standoff3Reborn-unsigned.ipa` появится в разделе Actions.

## Установка на iPhone

- Обычный iPhone: подпиши IPA своим Apple ID через Sideloadly/AltStore (free-аккаунт = 7 дней).
- TrollStore/jailbreak: можно ставить unsigned напрямую.
- Без IPA: открой веб-версию в Safari → «Поделиться» → «На экран Домой».

## Что внутри

- `capacitor.config.json` — bundle id `com.standoff3.reborn`.
- `sync-web.mjs` — копирует `index.html`, `css/`, `dist/` в `www/`.
- `build-unsigned-ipa.sh` — сборка Release `.app` без подписи и упаковка в `.ipa`.
- `ios/` создаётся автоматически командой `npx cap add ios`.
