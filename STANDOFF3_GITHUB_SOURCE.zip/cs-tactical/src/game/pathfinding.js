// A* pathfinding on the level grid, with line-of-sight smoothing.
import { isSolid } from '../data/maps.js';
import { walkLineClear } from '../world/raycast.js';

class MinHeap {
  constructor(){ this.a = []; }
  push(node){
    const a = this.a; a.push(node);
    let i = a.length - 1;
    while(i > 0){
      const p = (i - 1) >> 1;
      if(a[p].f <= a[i].f) break;
      [a[p], a[i]] = [a[i], a[p]];
      i = p;
    }
  }
  pop(){
    const a = this.a;
    const top = a[0];
    const last = a.pop();
    if(a.length){
      a[0] = last;
      let i = 0;
      for(;;){
        const l = i*2+1, r = l+1;
        let m = i;
        if(l < a.length && a[l].f < a[m].f) m = l;
        if(r < a.length && a[r].f < a[m].f) m = r;
        if(m === i) break;
        [a[m], a[i]] = [a[i], a[m]];
        i = m;
      }
    }
    return top;
  }
  get size(){ return this.a.length; }
}

export function worldToCell(map, x, z){
  return { cx: Math.floor(x / map.tile), cy: Math.floor(z / map.tile) };
}
export function cellToWorld(map, cx, cy){
  return { x: cx * map.tile + map.tile/2, z: cy * map.tile + map.tile/2 };
}

export function findPath(map, sx, sz, gx, gz){
  const start = worldToCell(map, sx, sz);
  const goal = worldToCell(map, gx, gz);
  const W = map.w, H = map.h;

  if(isSolid(map, start.cx, start.cy)) return [];
  // if goal is solid, find nearest open cell
  let gcx = goal.cx, gcy = goal.cy;
  if(isSolid(map, gcx, gcy)){
    let best = null, bd = Infinity;
    for(let r=1; r<=6 && !best; r++){
      for(let dy=-r; dy<=r; dy++){
        for(let dx=-r; dx<=r; dx++){
          if(Math.abs(dx)!==r && Math.abs(dy)!==r) continue;
          const x = gcx+dx, y = gcy+dy;
          if(x<0||y<0||x>=W||y>=H) continue;
          if(!isSolid(map,x,y)){
            const d = dx*dx+dy*dy;
            if(d < bd){ bd = d; best = {x,y}; }
          }
        }
      }
    }
    if(!best) return [];
    gcx = best.x; gcy = best.y;
  }

  const size = W*H;
  const gScore = new Float32Array(size).fill(Infinity);
  const came = new Int32Array(size).fill(-1);
  const closed = new Uint8Array(size);
  const open = new MinHeap();

  const sidx = start.cy*W + start.cx;
  const gidx = gcy*W + gcx;
  gScore[sidx] = 0;
  open.push({ idx:sidx, f:0 });

  const dirs = [[1,0,1],[-1,0,1],[0,1,1],[0,-1,1],[1,1,1.4142],[1,-1,1.4142],[-1,1,1.4142],[-1,-1,1.4142]];
  const h = (x,y) => Math.hypot(x-gcx, y-gcy);

  let found = false;
  let guard = 0;
  while(open.size && guard++ < 8000){
    const cur = open.pop();
    if(closed[cur.idx]) continue;
    closed[cur.idx] = 1;
    if(cur.idx === gidx){ found = true; break; }

    const cx = cur.idx % W, cy = (cur.idx / W) | 0;
    for(const [dx,dy,cost] of dirs){
      const nx = cx+dx, ny = cy+dy;
      if(nx<0||ny<0||nx>=W||ny>=H) continue;
      if(isSolid(map, nx, ny)) continue;
      // prevent cutting corners diagonally
      if(dx!==0 && dy!==0){
        if(isSolid(map, cx+dx, cy) || isSolid(map, cx, cy+dy)) continue;
      }
      const nidx = ny*W + nx;
      if(closed[nidx]) continue;
      const ng = gScore[cur.idx] + cost;
      if(ng < gScore[nidx]){
        gScore[nidx] = ng;
        came[nidx] = cur.idx;
        open.push({ idx:nidx, f: ng + h(nx,ny) });
      }
    }
  }
  if(!found) return [];

  // reconstruct
  const cells = [];
  let i = gidx;
  while(i !== -1){
    cells.push(i);
    if(i === sidx) break;
    i = came[i];
  }
  cells.reverse();

  // convert to world, then smooth
  let pts = cells.map(idx => cellToWorld(map, idx % W, (idx / W) | 0));
  pts = smoothPath(map, pts);
  return pts;
}

function smoothPath(map, pts){
  if(pts.length <= 2) return pts;
  const out = [pts[0]];
  let anchor = 0;
  for(let i = 2; i < pts.length; i++){
    if(!walkLineClear(map, pts[anchor].x, pts[anchor].z, pts[i].x, pts[i].z)){
      out.push(pts[i-1]);
      anchor = i-1;
    }
  }
  out.push(pts[pts.length-1]);
  return out;
}
