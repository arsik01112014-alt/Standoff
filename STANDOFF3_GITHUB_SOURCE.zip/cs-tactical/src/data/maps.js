// Procedural map layouts. Tile codes:
// 0 = empty, 1 = building (tall), 2 = crate (low, blocks movement), 3 = low wall
import { makeRNG, randRange } from '../core/utils.js';

export const MAP_INFO = [
  { id:'city',       name:'Улицы Рейна',     desc:'Городские кварталы, узкие улицы и переулки.', tag:'Город' },
  { id:'industrial', name:'Завод «Гамма»',   desc:'Промышленный комплекс: ангары и контейнеры.', tag:'Промышленность' },
  { id:'desert',     name:'Сухой Предел',    desc:'Пустынный аванпост с открытыми точками A и B.', tag:'Пустыня' },
  { id:'harbor',     name:'Порт «Норд»',     desc:'Контейнерные терминалы и причалы у холодной воды.', tag:'Порт' },
  { id:'office',     name:'Офис «Сигма»',    desc:'Стеклянные кабинеты, коридоры и тесные переговорные.', tag:'Офис' },
  { id:'dust',       name:'Пыльная Бухта',   desc:'Полузаброшенный причал под палящим солнцем.', tag:'Бухта' }
];

const H_BUILDING = 1, H_CRATE = 2, H_LOW = 3;

function blankMap(w, h){
  const grid = new Uint8Array(w * h);
  const hm = new Float32Array(w * h);
  for(let x=0; x<w; x++){
    setCell(grid, hm, w, x, 0, H_BUILDING, 7);
    setCell(grid, hm, w, x, h-1, H_BUILDING, 7);
  }
  for(let y=0; y<h; y++){
    setCell(grid, hm, w, 0, y, H_BUILDING, 7);
    setCell(grid, hm, w, w-1, y, H_BUILDING, 7);
  }
  return { grid, hm, w, h };
}

function setCell(grid, hm, w, x, y, type, height){
  const i = y * w + x;
  grid[i] = type;
  hm[i] = height;
}
function getCell(m, x, y){
  if(x < 0 || y < 0 || x >= m.w || y >= m.h) return H_BUILDING;
  return m.grid[y * m.w + x];
}

function rect(m, x0, y0, rw, rh, type, height){
  for(let y=y0; y<y0+rh; y++){
    for(let x=x0; x<x0+rw; x++){
      if(x<=0||y<=0||x>=m.w-1||y>=m.h-1) continue;
      setCell(m.grid, m.hm, m.w, x, y, type, height);
    }
  }
}

function findOpenCell(m, cx, cy, maxR=16){
  for(let r=0; r<=maxR; r++){
    for(let dy=-r; dy<=r; dy++){
      for(let dx=-r; dx<=r; dx++){
        if(Math.abs(dx)!==r && Math.abs(dy)!==r) continue;
        const x = cx+dx, y = cy+dy;
        if(x<2||y<2||x>m.w-3||y>m.h-3) continue;
        if(getCell(m,x,y)===0) return { x, y };
      }
    }
  }
  return { x: Math.floor(m.w/2), y: Math.floor(m.h/2) };
}

function clearArea(m, cx, cy, r){
  for(let y=cy-r; y<=cy+r; y++){
    for(let x=cx-r; x<=cx+r; x++){
      if(x<=0||y<=0||x>=m.w-1||y>=m.h-1) continue;
      // keep some cover at edges
      if(Math.abs(x-cx)===r || Math.abs(y-cy)===r){
        if((x+y) % 3 === 0) continue;
      }
      setCell(m.grid, m.hm, m.w, x, y, 0, 0);
    }
  }
}

function toWorld(cell, tile){ return cell * tile + tile/2; }

function buildSpawnList(m, cx, cy, tile, rng){
  const base = findOpenCell(m, cx, cy, 20);
  const cells = [];
  const used = new Set();
  for(let r=0; r<=6 && cells.length<12; r++){
    for(let dy=-r; dy<=r; dy++){
      for(let dx=-r; dx<=r; dx++){
        if(Math.max(Math.abs(dx), Math.abs(dy)) !== r) continue;
        const x = base.x+dx, y = base.y+dy;
        if(x<1 || y<1 || x>=m.w-1 || y>=m.h-1) continue;
        if(getCell(m,x,y) !== 0) continue;
        const k = x+','+y;
        if(used.has(k)) continue;
        used.add(k);
        cells.push({ x, y });
        if(cells.length >= 12) break;
      }
      if(cells.length >= 12) break;
    }
  }
  if(cells.length === 0) cells.push({ x: base.x, y: base.y });
  return cells.map(c=>({ x: toWorld(c.x,tile), z: toWorld(c.y,tile), ang: 0 }));
}

function faceSpawns(list, targetX, targetZ, tile){
  for(const s of list){
    s.ang = Math.atan2(-(targetX - s.x), -(targetZ - s.z));
  }
}

// ---------------- CITY ----------------
function genCity(seed){
  const w=44, h=44, tile=2;
  const m = blankMap(w,h);
  const rng = makeRNG(seed);

  // streets every 7 cells (2-wide roads), buildings fill blocks
  for(let by=2; by<h-2; by+=7){
    for(let bx=2; bx<w-2; bx+=7){
      const bw = 5, bh = 5;
      // building footprint with random alley gaps
      for(let y=by; y<by+bh && y<h-2; y++){
        for(let x=bx; x<bx+bw && x<w-2; x++){
          if(x<=0||y<=0) continue;
          const edgeAlley = (x===bx+bw-1 && rng()<0.5) || (y===by+bh-1 && rng()<0.4);
          if(edgeAlley) continue;
          const height = randRange(rng, 3.2, 7.5);
          setCell(m.grid, m.hm, m.w, x, y, H_BUILDING, height);
        }
      }
      // decorate block corners with crates sometimes
      if(rng() < 0.6){
        const cx = bx + Math.floor(rng()*bw);
        const cy = by + Math.floor(rng()*bh);
        if(getCell(m,cx,cy)===0) setCell(m.grid,m.hm,m.w,cx,cy,H_CRATE,1.25);
      }
    }
  }

  // crates along roads for cover
  for(let i=0; i<70; i++){
    const x = 2 + Math.floor(rng()*(w-4));
    const y = 2 + Math.floor(rng()*(h-4));
    if((x % 7 === 0 || x % 7 === 1 || y % 7 === 0 || y % 7 === 1) && getCell(m,x,y)===0){
      setCell(m.grid, m.hm, m.w, x, y, H_CRATE, 1.25);
    }
  }

  const siteA = findOpenCell(m, Math.floor(w*0.72), Math.floor(h*0.28));
  const siteB = findOpenCell(m, Math.floor(w*0.28), Math.floor(h*0.72));
  clearArea(m, siteA.x, siteA.y, 3);
  clearArea(m, siteB.x, siteB.y, 3);

  const ct = buildSpawnList(m, 4, 4, tile, rng);
  const t  = buildSpawnList(m, w-5, h-5, tile, rng);
  faceSpawns(ct, toWorld(siteB.x,tile), toWorld(siteB.y,tile), tile);
  faceSpawns(t, toWorld(siteA.x,tile), toWorld(siteA.y,tile), tile);

  return { m, tile, sites:[{name:'A', x:toWorld(siteA.x,tile), z:toWorld(siteA.y,tile)},{name:'B', x:toWorld(siteB.x,tile), z:toWorld(siteB.y,tile)}], ct, t,
    theme:'city', sky:'#aebfce', fog:'#9fb0c0', ground:'#4a4d50', wall:'#8b8f93', accent:'#c8863c' };
}

// ---------------- INDUSTRIAL ----------------
function genIndustrial(seed){
  const w=44, h=44, tile=2;
  const m = blankMap(w,h);
  const rng = makeRNG(seed);

  // large warehouse blocks
  const placed = [];
  const tryRect = (rw, rh) => {
    for(let attempt=0; attempt<40; attempt++){
      const x = 3 + Math.floor(rng()*(w-rw-6));
      const y = 3 + Math.floor(rng()*(h-rh-6));
      let ok = true;
      for(const p of placed){
        if(x < p.x+p.w+3 && x+rw+3 > p.x && y < p.y+p.h+3 && y+rh+3 > p.y){ ok=false; break; }
      }
      // keep spawn corners clear
      if(x < 8 && y < 8) ok=false;
      if(x+rw > w-8 && y+rh > h-8) ok=false;
      if(!ok) continue;
      placed.push({x,y,w:rw,h:rh});
      for(let yy=y; yy<y+rh; yy++) for(let xx=x; xx<x+rw; xx++){
        if(xx<=0||yy<=0||xx>=w-1||yy>=h-1) continue;
        setCell(m.grid,m.hm,m.w,xx,yy,H_BUILDING, randRange(rng,4.2,6.2));
      }
      return;
    }
  };
  tryRect(9,6); tryRect(8,7); tryRect(10,5); tryRect(7,8); tryRect(6,6); tryRect(9,5);

  // container yard: rows of crates with gaps
  for(let i=0;i<6;i++){
    const cx = 4 + Math.floor(rng()*(w-10));
    const cy = 4 + Math.floor(rng()*(h-10));
    for(let k=0;k<3;k++){
      const x = cx + k*2, y = cy + (k%2);
      if(getCell(m,x,y)===0) setCell(m.grid,m.hm,m.w,x,y,H_CRATE, randRange(rng,1.1,1.6));
    }
  }
  // scattered barrels/crates
  for(let i=0;i<60;i++){
    const x = 2+Math.floor(rng()*(w-4));
    const y = 2+Math.floor(rng()*(h-4));
    if(getCell(m,x,y)===0) setCell(m.grid,m.hm,m.w,x,y,H_CRATE,1.25);
  }

  const siteA = findOpenCell(m, Math.floor(w*0.68), Math.floor(h*0.32));
  const siteB = findOpenCell(m, Math.floor(w*0.32), Math.floor(h*0.68));
  clearArea(m, siteA.x, siteA.y, 3);
  clearArea(m, siteB.x, siteB.y, 3);

  const ct = buildSpawnList(m, 4, 4, tile, rng);
  const t  = buildSpawnList(m, w-5, h-5, tile, rng);
  faceSpawns(ct, toWorld(siteB.x,tile), toWorld(siteB.y,tile), tile);
  faceSpawns(t, toWorld(siteA.x,tile), toWorld(siteA.y,tile), tile);

  return { m, tile, sites:[{name:'A', x:toWorld(siteA.x,tile), z:toWorld(siteA.y,tile)},{name:'B', x:toWorld(siteB.x,tile), z:toWorld(siteB.y,tile)}], ct, t,
    theme:'industrial', sky:'#8a929c', fog:'#7d858f', ground:'#3a3d40', wall:'#6c7278', accent:'#d08a2a' };
}

// ---------------- DESERT ----------------
function genDesert(seed){
  const w=44, h=44, tile=2;
  const m = blankMap(w,h);
  const rng = makeRNG(seed);

  // scattered low adobe buildings
  for(let i=0;i<10;i++){
    const rw = 3 + Math.floor(rng()*4);
    const rh = 3 + Math.floor(rng()*4);
    const x = 3 + Math.floor(rng()*(w-rw-6));
    const y = 3 + Math.floor(rng()*(h-rh-6));
    if(x<8 && y<8) continue;
    if(x+rw>w-8 && y+rh>h-8) continue;
    for(let yy=y; yy<y+rh; yy++) for(let xx=x; xx<x+rw; xx++){
      if(getCell(m,xx,yy)!==0) continue;
      setCell(m.grid,m.hm,m.w,xx,yy,H_BUILDING, randRange(rng,2.4,3.8));
    }
  }
  // low walls (cover) lines
  for(let i=0;i<26;i++){
    const x = 3 + Math.floor(rng()*(w-6));
    const y = 3 + Math.floor(rng()*(h-6));
    const len = 2 + Math.floor(rng()*4);
    const horiz = rng() < 0.5;
    for(let k=0;k<len;k++){
      const xx = horiz ? x+k : x;
      const yy = horiz ? y : y+k;
      if(getCell(m,xx,yy)===0) setCell(m.grid,m.hm,m.w,xx,yy,H_LOW,1.15);
    }
  }
  // crates
  for(let i=0;i<45;i++){
    const x = 2+Math.floor(rng()*(w-4));
    const y = 2+Math.floor(rng()*(h-4));
    if(getCell(m,x,y)===0) setCell(m.grid,m.hm,m.w,x,y,H_CRATE,1.2);
  }

  const siteA = findOpenCell(m, Math.floor(w*0.5), Math.floor(h*0.22));
  const siteB = findOpenCell(m, Math.floor(w*0.5), Math.floor(h*0.78));
  clearArea(m, siteA.x, siteA.y, 3);
  clearArea(m, siteB.x, siteB.y, 3);

  const ct = buildSpawnList(m, 4, Math.floor(h/2), tile, rng);
  const t  = buildSpawnList(m, w-5, Math.floor(h/2), tile, rng);
  faceSpawns(ct, toWorld(siteA.x,tile), toWorld(siteA.y,tile), tile);
  faceSpawns(t, toWorld(siteB.x,tile), toWorld(siteB.y,tile), tile);

  return { m, tile, sites:[{name:'A', x:toWorld(siteA.x,tile), z:toWorld(siteA.y,tile)},{name:'B', x:toWorld(siteB.x,tile), z:toWorld(siteB.y,tile)}], ct, t,
    theme:'desert', sky:'#e8c88a', fog:'#dcb878', ground:'#b08850', wall:'#c8a878', accent:'#8a6030' };
}

// ---------------- HARBOR ----------------
function genHarbor(seed){
  const w=48, h=48, tile=2;
  const m = blankMap(w,h);
  const rng = makeRNG(seed);

  // Four corner warehouses frame a wide central dockyard.
  rect(m, 4, 4, 13, 5, H_BUILDING, 5.8);
  rect(m, 31, 4, 13, 5, H_BUILDING, 5.8);
  rect(m, 4, 39, 13, 5, H_BUILDING, 5.8);
  rect(m, 31, 39, 13, 5, H_BUILDING, 5.8);
  rect(m, 20, 20, 8, 8, H_BUILDING, 7.2);

  // Stacked shipping containers with walkable lanes between rows.
  for(let y=12; y<36; y+=4){
    for(let x=8; x<40; x+=1){
      if(x % 5 === 0) continue;
      if(getCell(m,x,y) !== 0) continue;
      if(y < 14 || y > 33) continue;
      setCell(m.grid,m.hm,m.w,x,y,H_CRATE,randRange(rng,1.15,1.7));
    }
  }
  for(let i=0;i<45;i++){
    const x = 6 + Math.floor(rng()*(w-12));
    const y = 6 + Math.floor(rng()*(h-12));
    if(getCell(m,x,y)===0) setCell(m.grid,m.hm,m.w,x,y,H_LOW,1.15);
  }
  // bollards / dock edge
  for(let y=5; y<h-5; y+=3){
    if(getCell(m,2,y)===0) setCell(m.grid,m.hm,m.w,2,y,H_LOW,0.9);
    if(getCell(m,w-3,y)===0) setCell(m.grid,m.hm,m.w,w-3,y,H_LOW,0.9);
  }

  const siteA = findOpenCell(m, Math.floor(w*0.73), Math.floor(h*0.24));
  const siteB = findOpenCell(m, Math.floor(w*0.27), Math.floor(h*0.76));
  clearArea(m, siteA.x, siteA.y, 3);
  clearArea(m, siteB.x, siteB.y, 3);

  const ct = buildSpawnList(m, 4, Math.floor(h/2), tile, rng);
  const t  = buildSpawnList(m, w-5, Math.floor(h/2), tile, rng);
  faceSpawns(ct, toWorld(siteB.x,tile), toWorld(siteB.y,tile), tile);
  faceSpawns(t, toWorld(siteA.x,tile), toWorld(siteA.y,tile), tile);

  return { m, tile, sites:[{name:'A', x:toWorld(siteA.x,tile), z:toWorld(siteA.y,tile)},{name:'B', x:toWorld(siteB.x,tile), z:toWorld(siteB.y,tile)}], ct, t,
    theme:'harbor', sky:'#7f98aa', fog:'#738fa2', ground:'#3d474c', wall:'#6b757c', accent:'#2fb0c8' };
}

// ---------------- OFFICE ----------------
function genOffice(seed){
  const w=42, h=42, tile=2;
  const m = blankMap(w,h);
  const rng = makeRNG(seed);

  // Corridor grid with doorway gaps; rooms stay connected and offer flanks.
  for(let x=8; x<w-6; x+=8){
    for(let y=4; y<h-4; y++){
      if(y % 7 === 3 || y % 7 === 4) continue;
      if(getCell(m,x,y)===0) setCell(m.grid,m.hm,m.w,x,y,H_BUILDING,3.8);
    }
  }
  for(let y=8; y<h-6; y+=8){
    for(let x=4; x<w-4; x++){
      if(x % 7 === 3 || x % 7 === 4) continue;
      if(getCell(m,x,y)===0) setCell(m.grid,m.hm,m.w,x,y,H_BUILDING,3.8);
    }
  }
  // open atrium in the center
  clearArea(m, Math.floor(w/2), Math.floor(h/2), 5);
  // desks, cabinets and planters
  for(let i=0;i<90;i++){
    const x = 3 + Math.floor(rng()*(w-6));
    const y = 3 + Math.floor(rng()*(h-6));
    if(getCell(m,x,y)!==0) continue;
    const kind = rng();
    if(kind < 0.55) setCell(m.grid,m.hm,m.w,x,y,H_CRATE,0.95);
    else setCell(m.grid,m.hm,m.w,x,y,H_LOW,0.8);
  }

  const siteA = findOpenCell(m, Math.floor(w*0.74), Math.floor(h*0.25));
  const siteB = findOpenCell(m, Math.floor(w*0.26), Math.floor(h*0.75));
  clearArea(m, siteA.x, siteA.y, 3);
  clearArea(m, siteB.x, siteB.y, 3);

  const ct = buildSpawnList(m, 4, 4, tile, rng);
  const t  = buildSpawnList(m, w-5, h-5, tile, rng);
  faceSpawns(ct, toWorld(siteB.x,tile), toWorld(siteB.y,tile), tile);
  faceSpawns(t, toWorld(siteA.x,tile), toWorld(siteA.y,tile), tile);

  return { m, tile, sites:[{name:'A', x:toWorld(siteA.x,tile), z:toWorld(siteA.y,tile)},{name:'B', x:toWorld(siteB.x,tile), z:toWorld(siteB.y,tile)}], ct, t,
    theme:'office', sky:'#9aa4ae', fog:'#8b96a2', ground:'#454a50', wall:'#a0a8b0', accent:'#7cffc4' };
}

// ---------------- DUST ----------------
function genDust(seed){
  const w=48, h=48, tile=2;
  const m = blankMap(w,h);
  const rng = makeRNG(seed);

  // Low adobe blocks and a central walled courtyard.
  for(let i=0;i<14;i++){
    const rw = 3 + Math.floor(rng()*5);
    const rh = 3 + Math.floor(rng()*5);
    const x = 4 + Math.floor(rng()*(w-rw-8));
    const y = 4 + Math.floor(rng()*(h-rh-8));
    if(x<9 && y<9) continue;
    if(x+rw>w-9 && y+rh>h-9) continue;
    for(let yy=y; yy<y+rh; yy++) for(let xx=x; xx<x+rw; xx++){
      if(getCell(m,xx,yy)!==0) continue;
      setCell(m.grid,m.hm,m.w,xx,yy,H_BUILDING, randRange(rng,2.2,4.4));
    }
  }
  // courtyard walls with gaps
  for(let x=17;x<=30;x++){
    if(x % 5 === 0) continue;
    if(getCell(m,x,17)===0) setCell(m.grid,m.hm,m.w,x,17,H_LOW,1.2);
    if(getCell(m,x,30)===0) setCell(m.grid,m.hm,m.w,x,30,H_LOW,1.2);
  }
  for(let y=17;y<=30;y++){
    if(y % 5 === 0) continue;
    if(getCell(m,17,y)===0) setCell(m.grid,m.hm,m.w,17,y,H_LOW,1.2);
    if(getCell(m,30,y)===0) setCell(m.grid,m.hm,m.w,30,y,H_LOW,1.2);
  }
  // long sightline cover
  for(let i=0;i<34;i++){
    const x = 3 + Math.floor(rng()*(w-6));
    const y = 3 + Math.floor(rng()*(h-6));
    if(getCell(m,x,y)!==0) continue;
    const horizontal = rng()<0.5;
    const len = 2 + Math.floor(rng()*5);
    for(let k=0;k<len;k++){
      const xx = horizontal ? x+k : x;
      const yy = horizontal ? y : y+k;
      if(getCell(m,xx,yy)===0) setCell(m.grid,m.hm,m.w,xx,yy,H_LOW,1.1);
    }
  }
  for(let i=0;i<36;i++){
    const x = 3 + Math.floor(rng()*(w-6));
    const y = 3 + Math.floor(rng()*(h-6));
    if(getCell(m,x,y)===0) setCell(m.grid,m.hm,m.w,x,y,H_CRATE,1.18);
  }

  const siteA = findOpenCell(m, Math.floor(w*0.5), Math.floor(h*0.23));
  const siteB = findOpenCell(m, Math.floor(w*0.5), Math.floor(h*0.77));
  clearArea(m, siteA.x, siteA.y, 3);
  clearArea(m, siteB.x, siteB.y, 3);

  const ct = buildSpawnList(m, 4, Math.floor(h/2), tile, rng);
  const t  = buildSpawnList(m, w-5, Math.floor(h/2), tile, rng);
  faceSpawns(ct, toWorld(siteA.x,tile), toWorld(siteA.y,tile), tile);
  faceSpawns(t, toWorld(siteB.x,tile), toWorld(siteB.y,tile), tile);

  return { m, tile, sites:[{name:'A', x:toWorld(siteA.x,tile), z:toWorld(siteA.y,tile)},{name:'B', x:toWorld(siteB.x,tile), z:toWorld(siteB.y,tile)}], ct, t,
    theme:'dust', sky:'#d8b878', fog:'#c9a868', ground:'#a47c4c', wall:'#c0a070', accent:'#e0a040' };
}

// ---------------- METRO ----------------
function genMetro(seed){
  const w=46, h=46, tile=2;
  const m = blankMap(w,h);
  const rng = makeRNG(seed);

  // two long station halls
  for(const bx of [6, w-13]){
    for(let y=5; y<h-5; y++){
      for(let x=bx; x<bx+7; x++){
        if(x<=0||y<=0||x>=w-1||y>=h-1) continue;
        const edge = (x===bx || x===bx+6);
        if(edge) setCell(m.grid,m.hm,m.w,x,y,H_BUILDING, randRange(rng,3.0,3.6));
        else if(y%3===0 && rng()<0.7) setCell(m.grid,m.hm,m.w,x,y,H_CRATE,1.35);
      }
    }
  }

  // platform edges (low walls) and central track divider
  for(let y=4; y<h-4; y++){
    if(y%9===0) continue;
    for(const x of [14,15,w-17,w-16]){
      if(x>0 && x<w-1 && getCell(m,x,y)===0) setCell(m.grid,m.hm,m.w,x,y,H_LOW,1.1);
    }
  }
  for(let x=18; x<w-18; x++){
    if(x%7===0) continue;
    if(getCell(m,x,Math.floor(h/2))===0) setCell(m.grid,m.hm,m.w,x,Math.floor(h/2),H_LOW,1.0);
  }

  // connectors / ticket halls at top and bottom
  for(let x=5; x<w-5; x++){
    for(const y of [3, h-4]){
      if(getCell(m,x,y)===0) setCell(m.grid,m.hm,m.w,x,y,H_CRATE,1.3);
    }
  }
  for(let i=0;i<30;i++){
    const x = 3 + Math.floor(rng()*(w-6));
    const y = 3 + Math.floor(rng()*(h-6));
    if(getCell(m,x,y)===0 && rng()<0.75) setCell(m.grid,m.hm,m.w,x,y,H_CRATE, randRange(rng,1.1,1.5));
  }

  const siteA = findOpenCell(m, Math.floor(w*0.74), Math.floor(h*0.25));
  const siteB = findOpenCell(m, Math.floor(w*0.26), Math.floor(h*0.75));
  clearArea(m, siteA.x, siteA.y, 3);
  clearArea(m, siteB.x, siteB.y, 3);

  const ct = buildSpawnList(m, 4, Math.floor(h/2), tile, rng);
  const t  = buildSpawnList(m, w-5, Math.floor(h/2), tile, rng);
  faceSpawns(ct, toWorld(siteB.x,tile), toWorld(siteB.y,tile), tile);
  faceSpawns(t, toWorld(siteA.x,tile), toWorld(siteA.y,tile), tile);

  return { m, tile, sites:[{name:'A', x:toWorld(siteA.x,tile), z:toWorld(siteA.y,tile)},{name:'B', x:toWorld(siteB.x,tile), z:toWorld(siteB.y,tile)}], ct, t,
    theme:'metro', sky:'#3a4a58', fog:'#2c3842', ground:'#2b3238', wall:'#5c6a72', accent:'#3fd0d8' };
}

// ---------------- VILLA ----------------
function genVilla(seed){
  const w=42, h=42, tile=2;
  const m = blankMap(w,h);
  const rng = makeRNG(seed);

  // outer villa wings with a central courtyard
  const wings = [
    [5,5,10,4], [w-15,5,10,4], [5,h-9,10,4], [w-15,h-9,10,4],
    [5,10,4,10], [5,h-20,4,10], [w-9,10,4,10], [w-9,h-20,4,10]
  ];
  for(const [x,y,rw,rh] of wings){
    for(let yy=y; yy<y+rh; yy++) for(let xx=x; xx<x+rw; xx++){
      if(xx<=0||yy<=0||xx>=w-1||yy>=h-1) continue;
      setCell(m.grid,m.hm,m.w,xx,yy,H_BUILDING, randRange(rng,3.4,6.4));
    }
  }

  // inner rooms
  for(let i=0;i<8;i++){
    const rw = 3 + Math.floor(rng()*3), rh = 3 + Math.floor(rng()*3);
    const x = 12 + Math.floor(rng()*(w-28)), y = 12 + Math.floor(rng()*(h-28));
    for(let yy=y; yy<y+rh; yy++) for(let xx=x; xx<x+rw; xx++){
      if(getCell(m,xx,yy)!==0) continue;
      if(yy%2===0 && xx%2===0) continue;
      setCell(m.grid,m.hm,m.w,xx,yy,H_BUILDING, randRange(rng,2.6,4.0));
    }
  }

  // courtyard fountain / hedge rows
  const cx = Math.floor(w/2), cy = Math.floor(h/2);
  for(let y=cy-5; y<=cy+5; y++) for(let x=cx-5; x<=cx+5; x++){
    if(getCell(m,x,y)!==0) continue;
    const edge = Math.abs(x-cx)===5 || Math.abs(y-cy)===5;
    if(edge) setCell(m.grid,m.hm,m.w,x,y,H_LOW,1.0);
  }
  for(let i=0;i<26;i++){
    const x = 4 + Math.floor(rng()*(w-8));
    const y = 4 + Math.floor(rng()*(h-8));
    if(getCell(m,x,y)===0) setCell(m.grid,m.hm,m.w,x,y, rng()<0.5?H_CRATE:H_LOW, rng()<0.5?1.25:1.0);
  }

  const siteA = findOpenCell(m, Math.floor(w*0.78), Math.floor(h*0.24));
  const siteB = findOpenCell(m, Math.floor(w*0.24), Math.floor(h*0.78));
  clearArea(m, siteA.x, siteA.y, 3);
  clearArea(m, siteB.x, siteB.y, 3);

  const ct = buildSpawnList(m, 4, 4, tile, rng);
  const t  = buildSpawnList(m, w-5, h-5, tile, rng);
  faceSpawns(ct, toWorld(siteB.x,tile), toWorld(siteB.y,tile), tile);
  faceSpawns(t, toWorld(siteA.x,tile), toWorld(siteA.y,tile), tile);

  return { m, tile, sites:[{name:'A', x:toWorld(siteA.x,tile), z:toWorld(siteA.y,tile)},{name:'B', x:toWorld(siteB.x,tile), z:toWorld(siteB.y,tile)}], ct, t,
    theme:'villa', sky:'#93a9b8', fog:'#88a0b0', ground:'#4c5048', wall:'#d8cfb8', accent:'#d8a848' };
}

const GENERATORS = { city: genCity, industrial: genIndustrial, desert: genDesert, harbor: genHarbor, office: genOffice, dust: genDust, metro: genMetro, villa: genVilla };
const SEEDS = { city: 1337, industrial: 4242, desert: 9090, harbor: 5150, office: 6060, dust: 7777, metro: 8181, villa: 6161 };

export function buildMap(id){
  const gen = GENERATORS[id] || genCity;
  const data = gen(SEEDS[id] || 1337);
  const { m, tile } = data;
  return {
    id,
    w: m.w, h: m.h, tile,
    grid: m.grid,
    heights: m.hm,
    spawns: { CT: data.ct, T: data.t },
    sites: data.sites,
    theme: data.theme,
    sky: data.sky, fog: data.fog, ground: data.ground, wall: data.wall, accent: data.accent,
    info: MAP_INFO.find(x => x.id === id)
  };
}

// ---------------- CUSTOM MAPS (editor) ----------------
export function buildCustomMap(data){
  const w = Math.max(16, Math.min(64, Math.round(data && data.w || 32)));
  const h = Math.max(16, Math.min(64, Math.round(data && data.h || 32)));
  const tile = data && data.tile ? data.tile : 2;
  const grid = new Uint8Array(w*h);
  const hm = new Float32Array(w*h);
  const src = (data && data.grid) || [];
  for(let y=0;y<h;y++){
    for(let x=0;x<w;x++){
      let v = 0;
      if(Array.isArray(src[y])){
        const c = src[y][x];
        v = typeof c === 'number' ? c : (c && c.type) || 0;
      } else if(typeof src[y] === 'string') v = parseInt(src[y][x] || '0', 10) || 0;
      if(x===0||y===0||x===w-1||y===h-1) v = H_BUILDING;
      if(v < 0 || v > 3) v = 0;
      const height = v === H_BUILDING ? 6 : (v === H_CRATE ? 1.25 : (v === H_LOW ? 1.15 : 0));
      setCell(grid, hm, w, x, y, v, height);
    }
  }
  const tmp = { grid, hm, w, h };
  const toSite = (s, fallback) => {
    if(s && Number.isFinite(s.x) && Number.isFinite(s.y)){
      return { name: s.name || fallback, x: clampCell(s.x,w-3), y: clampCell(s.y,h-3) };
    }
    return null;
  };
  let siteA = toSite(data && data.sites && data.sites[0], 'A');
  let siteB = toSite(data && data.sites && data.sites[1], 'B');
  if(!siteA){ const c = findOpenCell(tmp, Math.floor(w*0.72), Math.floor(h*0.28)); siteA = { name:'A', x:c.x, y:c.y }; }
  if(!siteB){ const c = findOpenCell(tmp, Math.floor(w*0.28), Math.floor(h*0.72)); siteB = { name:'B', x:c.x, y:c.y }; }
  clearArea(tmp, siteA.x, siteA.y, 2);
  clearArea(tmp, siteB.x, siteB.y, 2);

  const toSpawnWorld = (list, fallbackX, fallbackY) => {
    const clean = Array.isArray(list) ? list.filter(s => s && Number.isFinite(s.x) && Number.isFinite(s.y)) : [];
    if(!clean.length){
      return buildSpawnList(tmp, fallbackX, fallbackY, tile, makeRNG(99));
    }
    return clean.slice(0,12).map(s => ({
      x: toWorld(clampCell(s.x,w-2), tile),
      z: toWorld(clampCell(s.y,h-2), tile),
      ang: 0
    }));
  };
  const ct = toSpawnWorld(data && data.spawns && data.spawns.CT, 3, 3);
  const t = toSpawnWorld(data && data.spawns && data.spawns.T, w-4, h-4);
  const targetA = { x:toWorld(siteA.x,tile), z:toWorld(siteA.y,tile) };
  const targetB = { x:toWorld(siteB.x,tile), z:toWorld(siteB.y,tile) };
  faceSpawns(ct, targetB.x, targetB.z, tile);
  faceSpawns(t, targetA.x, targetA.z, tile);

  const theme = (data && data.theme) || 'city';
  const themes = {
    city:{ sky:'#aebfce', fog:'#9fb0c0', ground:'#4a4d50', wall:'#8b8f93', accent:'#c8863c' },
    harbor:{ sky:'#7f98aa', fog:'#738fa2', ground:'#3d474c', wall:'#6b757c', accent:'#2fb0c8' },
    office:{ sky:'#9aa4ae', fog:'#8b96a2', ground:'#454a50', wall:'#a0a8b0', accent:'#7cffc4' },
    dust:{ sky:'#d8b878', fog:'#c9a868', ground:'#a47c4c', wall:'#c0a070', accent:'#e0a040' },
    desert:{ sky:'#e8c88a', fog:'#dcb878', ground:'#b08850', wall:'#c8a878', accent:'#8a6030' },
    industrial:{ sky:'#8a929c', fog:'#7d858f', ground:'#3a3d40', wall:'#6c7278', accent:'#d08a2a' },
    metro:{ sky:'#3a4a58', fog:'#2c3842', ground:'#2b3238', wall:'#5c6a72', accent:'#3fd0d8' },
    villa:{ sky:'#93a9b8', fog:'#88a0b0', ground:'#4c5048', wall:'#d8cfb8', accent:'#d8a848' }
  };
  const th = themes[theme] || themes.city;
  return {
    id:'custom', w, h, tile, grid, heights:hm,
    spawns:{ CT:ct, T:t },
    sites:[{ name: siteA.name || 'A', x:targetA.x, z:targetA.z }, { name: siteB.name || 'B', x:targetB.x, z:targetB.z }],
    theme,
    light:(data && data.light) || 'day',
    sky:th.sky, fog:th.fog, ground:th.ground, wall:th.wall, accent:th.accent,
    info:{ id:'custom', name:(data && data.name) || 'Моя карта', desc:'Пользовательская карта из редактора.', tag:'Редактор' }
  };
}
function clampCell(v, max){ return Math.max(1, Math.min(max, Math.round(v))); }

// solid test used by movement + pathfinding
export function isSolid(map, cx, cy){
  if(cx < 0 || cy < 0 || cx >= map.w || cy >= map.h) return true;
  return map.grid[cy * map.w + cx] !== 0;
}

export { getCell as getMapCell };
