// Weapon / grenade / skin definitions. All numbers are original tuning.
import { SKIN_VARIANTS, RARITIES, buildSkinCatalog, pickWeighted, oddsFor, RARITY_ORDER } from './skins.js';
//
// Key handling notes:
//  - dmg is body damage at falloffStart, headMult applies to the head zone.
//  - spread is the standing hip-fire cone (radians). Move/air/ADS modifiers are
//    applied by src/game/combat.js so every weapon stays predictable.
//  - recoil is the vertical camera kick in degrees-ish units; recoilYaw adds
//    the characteristic horizontal drift of each platform.

export const SLOTS = { primary: 1, secondary: 2, knife: 3, grenade: 4 };

const COMMON = {
  falloff: 0.42,
  firstShotSpread: 0.5,
  moveSpread: 2.2,
  airSpread: 5.5,
  aimSpread: 0.55,
  recoilYaw: 0.35,
  recoilRecovery: 7,
  inspectTime: 1.7
};

export const WEAPONS = {
  knife: {
    id: 'knife', name: 'Нож', type: 'knife', slot: 3, price: 0,
    dmg: 65, headMult: 2.2, armorPen: 0.6, fireDelay: 420, auto: false,
    mag: Infinity, reserve: Infinity, reloadTime: 0, spread: 0, recoil: 0,
    range: 2.2, speed: 1.12, killReward: 1500, pellets: 1, zoom: 1,
    viewModel: 'knife', sound: 'knife', icon: '🔪',
    falloff: 0, firstShotSpread: 1, moveSpread: 1, airSpread: 1, aimSpread: 1,
    recoilYaw: 0, recoilRecovery: 1, inspectTime: 1.2
  },
  glock: {
    id: 'glock', name: 'Glock-18', type: 'pistol', slot: 2, price: 200,
    dmg: 30, headMult: 4, armorPen: 0.47, fireDelay: 150, auto: false,
    mag: 20, reserve: 120, reloadTime: 2100, spread: 0.010, recoil: 0.55,
    range: 40, falloffStart: 18, falloffEnd: 38, speed: 1, killReward: 300,
    pellets: 1, zoom: 1, viewModel: 'pistol', sound: 'pistol', icon: '🔫',
moveSpread: 1.9, recoilYaw: 0.3
  },
  usp: {
    id: 'usp', name: 'USP-S', type: 'pistol', slot: 2, price: 200,
    dmg: 35, headMult: 4, armorPen: 0.5, fireDelay: 170, auto: false,
    mag: 12, reserve: 100, reloadTime: 2200, spread: 0.008, recoil: 0.6,
    range: 42, falloffStart: 20, falloffEnd: 40, speed: 1, killReward: 300,
    pellets: 1, zoom: 1, viewModel: 'pistol', sound: 'pistol_sil', icon: '🔫',
moveSpread: 1.8, recoilYaw: 0.24
  },
  p250: {
    id: 'p250', name: 'P250', type: 'pistol', slot: 2, price: 300,
    dmg: 38, headMult: 4, armorPen: 0.64, fireDelay: 160, auto: false,
    mag: 13, reserve: 100, reloadTime: 2200, spread: 0.012, recoil: 0.66,
    range: 40, falloffStart: 17, falloffEnd: 37, speed: 1, killReward: 300,
    pellets: 1, zoom: 1, viewModel: 'pistol', sound: 'pistol', icon: '🔫',
moveSpread: 2, recoilYaw: 0.34
  },
  deagle: {
    id: 'deagle', name: 'Desert Eagle', type: 'pistol', slot: 2, price: 700,
    dmg: 63, headMult: 4, armorPen: 0.93, fireDelay: 350, auto: false,
    mag: 7, reserve: 35, reloadTime: 2300, spread: 0.020, recoil: 2.2,
    range: 50, falloffStart: 25, falloffEnd: 48, speed: 0.98, killReward: 300,
    pellets: 1, zoom: 1, viewModel: 'pistol_big', sound: 'deagle', icon: '🔫',
moveSpread: 2.8, recoilYaw: 0.9, recoilRecovery: 5.2, firstShotSpread: 0.3
  },
  cz75: {
    id: 'cz75', name: 'CZ75-Auto', type: 'pistol', slot: 2, price: 500,
    dmg: 31, headMult: 4, armorPen: 0.62, fireDelay: 105, auto: true,
    mag: 12, reserve: 12, reloadTime: 2600, spread: 0.015, recoil: 0.72,
    range: 38, falloffStart: 15, falloffEnd: 35, speed: 0.99, killReward: 300,
    pellets: 1, zoom: 1, viewModel: 'pistol', sound: 'pistol', icon: '🔫',
moveSpread: 2.1, recoilYaw: 0.42, recoilRecovery: 7.4
  },
  'five-seven': {
    id: 'five-seven', name: 'Five-SeveN', type: 'pistol', slot: 2, price: 500,
    dmg: 32, headMult: 4, armorPen: 0.72, fireDelay: 150, auto: false,
    mag: 20, reserve: 100, reloadTime: 2200, spread: 0.010, recoil: 0.6,
    range: 44, falloffStart: 20, falloffEnd: 42, speed: 1.01, killReward: 300,
    pellets: 1, zoom: 1, viewModel: 'pistol', sound: 'pistol', icon: '🔫',
moveSpread: 1.7, recoilYaw: 0.28, recoilRecovery: 8
  },
  mp9: {
    id: 'mp9', name: 'MP9', type: 'smg', slot: 1, price: 1250,
    dmg: 26, headMult: 4, armorPen: 0.6, fireDelay: 82, auto: true,
    mag: 30, reserve: 120, reloadTime: 2100, spread: 0.016, recoil: 0.72,
    range: 42, falloffStart: 14, falloffEnd: 36, speed: 0.98, killReward: 600,
    pellets: 1, zoom: 1, viewModel: 'smg', sound: 'smg', icon: '🔫',
moveSpread: 1.25, airSpread: 4, recoilYaw: 0.42, recoilRecovery: 8.5
  },
  mac10: {
    id: 'mac10', name: 'MAC-10', type: 'smg', slot: 1, price: 1050,
    dmg: 29, headMult: 4, armorPen: 0.58, fireDelay: 78, auto: true,
    mag: 30, reserve: 100, reloadTime: 2400, spread: 0.022, recoil: 0.88,
    range: 36, falloffStart: 12, falloffEnd: 32, speed: 0.97, killReward: 600,
    pellets: 1, zoom: 1, viewModel: 'smg', sound: 'smg', icon: '🔫',
moveSpread: 1.1, airSpread: 4, recoilYaw: 0.55, recoilRecovery: 8
  },
  ump45: {
    id: 'ump45', name: 'UMP-45', type: 'smg', slot: 1, price: 1200,
    dmg: 34, headMult: 4, armorPen: 0.65, fireDelay: 105, auto: true,
    mag: 25, reserve: 100, reloadTime: 2500, spread: 0.014, recoil: 0.8,
    range: 44, falloffStart: 16, falloffEnd: 38, speed: 0.96, killReward: 600,
    pellets: 1, zoom: 1, viewModel: 'smg', sound: 'smg', icon: '🔫',
moveSpread: 1.25, recoilYaw: 0.36, recoilRecovery: 7.8
  },
  mp7: {
    id: 'mp7', name: 'MP7', type: 'smg', slot: 1, price: 1500,
    dmg: 29, headMult: 4, armorPen: 0.62, fireDelay: 80, auto: true,
    mag: 30, reserve: 120, reloadTime: 2200, spread: 0.014, recoil: 0.74,
    range: 44, falloffStart: 16, falloffEnd: 38, speed: 0.99, killReward: 600,
    pellets: 1, zoom: 1, viewModel: 'smg', sound: 'smg', icon: '🔫',
moveSpread: 1.2, airSpread: 4.2, recoilYaw: 0.38, recoilRecovery: 8.6
  },
  bizon: {
    id: 'bizon', name: 'PP-Bizon', type: 'smg', slot: 1, price: 1400,
    dmg: 27, headMult: 4, armorPen: 0.60, fireDelay: 85, auto: true,
    mag: 64, reserve: 120, reloadTime: 2500, spread: 0.021, recoil: 0.70,
    range: 38, falloffStart: 12, falloffEnd: 34, speed: 1.0, killReward: 600,
    pellets: 1, zoom: 1, viewModel: 'smg', sound: 'smg', icon: '🔫',
moveSpread: 1.15, airSpread: 4, recoilYaw: 0.44, recoilRecovery: 8.4
  },
  mp5sd: {
    id: 'mp5sd', name: 'MP5-SD', type: 'smg', slot: 1, price: 1500,
    dmg: 30, headMult: 4, armorPen: 0.63, fireDelay: 92, auto: true,
    mag: 30, reserve: 120, reloadTime: 2400, spread: 0.013, recoil: 0.68,
    range: 46, falloffStart: 18, falloffEnd: 40, speed: 0.98, killReward: 600,
    pellets: 1, zoom: 1, viewModel: 'smg', sound: 'smg_sil', icon: '🔫',
moveSpread: 1.15, airSpread: 4, recoilYaw: 0.26, recoilRecovery: 8.8
  },
  ak47: {
    id: 'ak47', name: 'AK-47', type: 'rifle', slot: 1, price: 2700,
    dmg: 36, headMult: 4, armorPen: 0.775, fireDelay: 100, auto: true,
    mag: 30, reserve: 90, reloadTime: 2500, spread: 0.018, recoil: 1.05,
    range: 65, falloffStart: 22, falloffEnd: 60, speed: 0.92, killReward: 300,
    pellets: 1, zoom: 1, viewModel: 'rifle_ak', sound: 'ak', icon: '🔫',
moveSpread: 3.4, recoilYaw: 0.62, recoilRecovery: 6.2, aimSpread: 0.62
  },
  m4a1: {
    id: 'm4a1', name: 'M4A1-S', type: 'rifle', slot: 1, price: 3100,
    dmg: 33, headMult: 4, armorPen: 0.7, fireDelay: 90, auto: true,
    mag: 25, reserve: 90, reloadTime: 3100, spread: 0.012, recoil: 0.7,
    range: 65, falloffStart: 24, falloffEnd: 60, speed: 0.92, killReward: 300,
    pellets: 1, zoom: 1, viewModel: 'rifle_m4', sound: 'm4_sil', icon: '🔫',
moveSpread: 2.7, recoilYaw: 0.28, recoilRecovery: 8, aimSpread: 0.5
  },
  m4a4: {
    id: 'm4a4', name: 'M4A4', type: 'rifle', slot: 1, price: 3100,
    dmg: 33, headMult: 4, armorPen: 0.7, fireDelay: 90, auto: true,
    mag: 30, reserve: 90, reloadTime: 3000, spread: 0.015, recoil: 0.85,
    range: 65, falloffStart: 22, falloffEnd: 60, speed: 0.92, killReward: 300,
    pellets: 1, zoom: 1, viewModel: 'rifle_m4', sound: 'm4', icon: '🔫',
moveSpread: 2.9, recoilYaw: 0.34, recoilRecovery: 7.4
  },
  galil: {
    id: 'galil', name: 'Galil AR', type: 'rifle', slot: 1, price: 1800,
    dmg: 30, headMult: 4, armorPen: 0.775, fireDelay: 95, auto: true,
    mag: 35, reserve: 90, reloadTime: 3000, spread: 0.022, recoil: 1.15,
    range: 60, falloffStart: 18, falloffEnd: 54, speed: 0.93, killReward: 300,
    pellets: 1, zoom: 1, viewModel: 'rifle_ak', sound: 'ak', icon: '🔫',
moveSpread: 3.6, recoilYaw: 0.7, recoilRecovery: 6
  },
  famas: {
    id: 'famas', name: 'FAMAS', type: 'rifle', slot: 1, price: 2050,
    dmg: 30, headMult: 4, armorPen: 0.7, fireDelay: 92, auto: true,
    mag: 25, reserve: 90, reloadTime: 2900, spread: 0.016, recoil: 0.9,
    range: 60, falloffStart: 20, falloffEnd: 55, speed: 0.94, killReward: 300,
    pellets: 1, zoom: 1, viewModel: 'rifle_m4', sound: 'm4', icon: '🔫',
moveSpread: 3, recoilYaw: 0.4, recoilRecovery: 7.6
  },
  sg553: {
    id: 'sg553', name: 'SG 553', type: 'rifle', slot: 1, price: 3000,
    dmg: 35, headMult: 4, armorPen: 0.8, fireDelay: 100, auto: true,
    mag: 30, reserve: 90, reloadTime: 3100, spread: 0.019, recoil: 1.0,
    range: 70, falloffStart: 24, falloffEnd: 64, speed: 0.9, killReward: 300,
    pellets: 1, zoom: 2, viewModel: 'rifle_ak', sound: 'ak', icon: '🎯',
moveSpread: 3.2, recoilYaw: 0.5, recoilRecovery: 6.6, aimSpread: 0.28
  },
  aug: {
    id: 'aug', name: 'AUG', type: 'rifle', slot: 1, price: 3300,
    dmg: 32, headMult: 4, armorPen: 0.75, fireDelay: 95, auto: true,
    mag: 30, reserve: 90, reloadTime: 3200, spread: 0.014, recoil: 0.82,
    range: 70, falloffStart: 26, falloffEnd: 64, speed: 0.9, killReward: 300,
    pellets: 1, zoom: 2, viewModel: 'rifle_m4', sound: 'm4', icon: '🎯',
moveSpread: 2.8, recoilYaw: 0.3, recoilRecovery: 7.8, aimSpread: 0.26
  },
  awp: {
    id: 'awp', name: 'AWP', type: 'sniper', slot: 1, price: 4750,
    dmg: 115, headMult: 1.6, armorPen: 0.975, fireDelay: 1450, auto: false,
    mag: 10, reserve: 30, reloadTime: 3600, spread: 0.020, recoil: 3.5,
    range: 120, falloffStart: 90, falloffEnd: 120, speed: 0.75, killReward: 100,
    pellets: 1, zoom: 4, viewModel: 'sniper', sound: 'awp', icon: '🎯',
moveSpread: 8, airSpread: 14, recoilYaw: 1.0, recoilRecovery: 4,
    firstShotSpread: 0.05, aimSpread: 0.01, inspectTime: 2.2
  },
  ssg08: {
    id: 'ssg08', name: 'SSG 08', type: 'sniper', slot: 1, price: 1700,
    dmg: 88, headMult: 2.5, armorPen: 0.85, fireDelay: 1250, auto: false,
    mag: 10, reserve: 90, reloadTime: 3700, spread: 0.018, recoil: 2.8,
    range: 110, falloffStart: 80, falloffEnd: 110, speed: 0.85, killReward: 300,
    pellets: 1, zoom: 3, viewModel: 'sniper', sound: 'ssg', icon: '🎯',
moveSpread: 7, airSpread: 12, recoilYaw: 0.8, recoilRecovery: 4.6,
    firstShotSpread: 0.06, aimSpread: 0.012, inspectTime: 2.0
  },
  g3sg1: {
    id: 'g3sg1', name: 'G3SG1', type: 'sniper', slot: 1, price: 5000,
    dmg: 80, headMult: 2.5, armorPen: 0.85, fireDelay: 250, auto: false,
    mag: 20, reserve: 90, reloadTime: 3800, spread: 0.012, recoil: 2.4,
    range: 110, falloffStart: 80, falloffEnd: 110, speed: 0.8, killReward: 300,
    pellets: 1, zoom: 3, viewModel: 'sniper', sound: 'ssg', icon: '🎯',
moveSpread: 6.5, airSpread: 11, recoilYaw: 0.72, recoilRecovery: 4.4,
    firstShotSpread: 0.055, aimSpread: 0.014, inspectTime: 2.0
  },
  scar20: {
    id: 'scar20', name: 'SCAR-20', type: 'sniper', slot: 1, price: 5000,
    dmg: 80, headMult: 2.5, armorPen: 0.85, fireDelay: 255, auto: false,
    mag: 20, reserve: 90, reloadTime: 3700, spread: 0.010, recoil: 2.2,
    range: 115, falloffStart: 82, falloffEnd: 115, speed: 0.8, killReward: 300,
    pellets: 1, zoom: 3, viewModel: 'sniper', sound: 'ssg', icon: '🎯',
moveSpread: 6, airSpread: 10.5, recoilYaw: 0.62, recoilRecovery: 4.8,
    firstShotSpread: 0.05, aimSpread: 0.012, inspectTime: 2.0
  },
  negev: {
    id: 'negev', name: 'Negev', type: 'lmg', slot: 1, price: 5700,
    dmg: 35, headMult: 4, armorPen: 0.75, fireDelay: 70, auto: true,
    mag: 150, reserve: 200, reloadTime: 5500, spread: 0.040, recoil: 1.6,
    range: 55, falloffStart: 20, falloffEnd: 52, speed: 0.8, killReward: 300,
    pellets: 1, zoom: 1, viewModel: 'lmg', sound: 'lmg', icon: '🔫',
moveSpread: 5, recoilYaw: 0.9, recoilRecovery: 5, aimSpread: 0.7
  },
  m249: {
    id: 'm249', name: 'M249', type: 'lmg', slot: 1, price: 5200,
    dmg: 32, headMult: 4, armorPen: 0.75, fireDelay: 80, auto: true,
    mag: 100, reserve: 200, reloadTime: 5500, spread: 0.035, recoil: 1.4,
    range: 55, falloffStart: 20, falloffEnd: 52, speed: 0.8, killReward: 300,
    pellets: 1, zoom: 1, viewModel: 'lmg', sound: 'lmg', icon: '🔫',
moveSpread: 4.6, recoilYaw: 0.75, recoilRecovery: 5.4, aimSpread: 0.66
  },
  nova: {
    id: 'nova', name: 'Nova', type: 'shotgun', slot: 1, price: 1050,
    dmg: 26, headMult: 2, armorPen: 0.5, fireDelay: 900, auto: false,
    mag: 8, reserve: 32, reloadTime: 3600, spread: 0.06, recoil: 1.5,
    range: 22, falloffStart: 6, falloffEnd: 20, falloff: 0.7, speed: 0.95,
    killReward: 900, pellets: 9, zoom: 1, viewModel: 'shotgun', sound: 'shotgun', icon: '🔫',
moveSpread: 2.2, firstShotSpread: 1, recoilYaw: 0.5, recoilRecovery: 6
  },
  xm1014: {
    id: 'xm1014', name: 'XM1014', type: 'shotgun', slot: 1, price: 2000,
    dmg: 23, headMult: 2, armorPen: 0.5, fireDelay: 300, auto: false,
    mag: 7, reserve: 32, reloadTime: 4000, spread: 0.07, recoil: 1.4,
    range: 22, falloffStart: 5, falloffEnd: 19, falloff: 0.72, speed: 0.92,
    killReward: 900, pellets: 6, zoom: 1, viewModel: 'shotgun', sound: 'shotgun', icon: '🔫',
moveSpread: 2.1, firstShotSpread: 1, recoilYaw: 0.46, recoilRecovery: 6.2
  },
  mag7: {
    id: 'mag7', name: 'MAG-7', type: 'shotgun', slot: 1, price: 1800,
    dmg: 30, headMult: 1.8, armorPen: 0.55, fireDelay: 850, auto: false,
    mag: 5, reserve: 32, reloadTime: 3000, spread: 0.055, recoil: 1.5,
    range: 24, falloffStart: 7, falloffEnd: 21, falloff: 0.7, speed: 0.96,
    killReward: 900, pellets: 8, zoom: 1, viewModel: 'shotgun_semi', sound: 'shotgun', icon: '🔫',
moveSpread: 2.0, firstShotSpread: 1, recoilYaw: 0.5, recoilRecovery: 6
  },
  p2000: {
    id: 'p2000', name: 'P2000', type: 'pistol', slot: 2, price: 200,
    dmg: 32, headMult: 4, armorPen: 0.5, fireDelay: 165, auto: false,
    mag: 13, reserve: 52, reloadTime: 2100, spread: 0.009, recoil: 0.58,
    range: 42, falloffStart: 19, falloffEnd: 40, speed: 1, killReward: 300,
    pellets: 1, zoom: 1, viewModel: 'pistol', sound: 'pistol', icon: '🔫',
    moveSpread: 1.8, recoilYaw: 0.28
  },
  tec9: {
    id: 'tec9', name: 'TEC-9', type: 'pistol', slot: 2, price: 500,
    dmg: 33, headMult: 4, armorPen: 0.62, fireDelay: 115, auto: true,
    mag: 18, reserve: 90, reloadTime: 2400, spread: 0.018, recoil: 0.9,
    range: 38, falloffStart: 14, falloffEnd: 35, speed: 0.99, killReward: 300,
    pellets: 1, zoom: 1, viewModel: 'pistol', sound: 'pistol', icon: '🔫',
    moveSpread: 2.2, recoilYaw: 0.52, recoilRecovery: 7
  },
  r8: {
    id: 'r8', name: 'R8 Revolver', type: 'pistol', slot: 2, price: 700,
    dmg: 86, headMult: 3.4, armorPen: 0.93, fireDelay: 500, auto: false,
    mag: 8, reserve: 24, reloadTime: 3000, spread: 0.017, recoil: 2.4,
    range: 52, falloffStart: 26, falloffEnd: 50, speed: 0.97, killReward: 300,
    pellets: 1, zoom: 1, viewModel: 'pistol_big', sound: 'deagle', icon: '🎯',
    moveSpread: 2.9, recoilYaw: 0.85, recoilRecovery: 4.8, firstShotSpread: 0.26
  },
  uzi: {
    id: 'uzi', name: 'Uzi', type: 'smg', slot: 1, price: 1100,
    dmg: 28, headMult: 4, armorPen: 0.58, fireDelay: 86, auto: true,
    mag: 32, reserve: 100, reloadTime: 2300, spread: 0.021, recoil: 0.84,
    range: 36, falloffStart: 13, falloffEnd: 33, speed: 0.98, killReward: 600,
    pellets: 1, zoom: 1, viewModel: 'smg', sound: 'smg', icon: '🔫',
    moveSpread: 1.3, airSpread: 4.1, recoilYaw: 0.5, recoilRecovery: 8.2
  },
  p90: {
    id: 'p90', name: 'P90', type: 'smg', slot: 1, price: 2350,
    dmg: 28, headMult: 4, armorPen: 0.66, fireDelay: 76, auto: true,
    mag: 50, reserve: 100, reloadTime: 2700, spread: 0.017, recoil: 0.76,
    range: 42, falloffStart: 16, falloffEnd: 38, speed: 0.99, killReward: 600,
    pellets: 1, zoom: 1, viewModel: 'smg', sound: 'smg', icon: '🔫',
    moveSpread: 1.18, airSpread: 3.8, recoilYaw: 0.34, recoilRecovery: 8.7
  },
  vector: {
    id: 'vector', name: 'Vector .45', type: 'smg', slot: 1, price: 1900,
    dmg: 27, headMult: 4, armorPen: 0.64, fireDelay: 68, auto: true,
    mag: 25, reserve: 100, reloadTime: 2500, spread: 0.013, recoil: 0.62,
    range: 40, falloffStart: 15, falloffEnd: 36, speed: 0.98, killReward: 600,
    pellets: 1, zoom: 1, viewModel: 'smg', sound: 'smg', icon: '🔫',
    moveSpread: 1.08, airSpread: 3.8, recoilYaw: 0.22, recoilRecovery: 9
  },
  g36: {
    id: 'g36', name: 'G36C', type: 'rifle', slot: 1, price: 2500,
    dmg: 31, headMult: 4, armorPen: 0.72, fireDelay: 92, auto: true,
    mag: 30, reserve: 90, reloadTime: 2900, spread: 0.016, recoil: 0.86,
    range: 62, falloffStart: 21, falloffEnd: 57, speed: 0.92, killReward: 300,
    pellets: 1, zoom: 1, viewModel: 'rifle_m4', sound: 'm4', icon: '🔫',
    moveSpread: 2.9, recoilYaw: 0.36, recoilRecovery: 7.5
  },
  val: {
    id: 'val', name: 'AS VAL', type: 'rifle', slot: 1, price: 3000,
    dmg: 34, headMult: 4, armorPen: 0.74, fireDelay: 95, auto: true,
    mag: 20, reserve: 80, reloadTime: 2800, spread: 0.013, recoil: 0.72,
    range: 58, falloffStart: 20, falloffEnd: 54, speed: 0.93, killReward: 300,
    pellets: 1, zoom: 1, viewModel: 'rifle_ak', sound: 'm4_sil', icon: '🎯',
    moveSpread: 2.6, recoilYaw: 0.24, recoilRecovery: 8.3, aimSpread: 0.48
  },
  barrett: {
    id: 'barrett', name: 'Barrett M82', type: 'sniper', slot: 1, price: 5500,
    dmg: 130, headMult: 1.8, armorPen: 0.985, fireDelay: 1600, auto: false,
    mag: 5, reserve: 25, reloadTime: 4200, spread: 0.014, recoil: 4.2,
    range: 135, falloffStart: 100, falloffEnd: 135, speed: 0.72, killReward: 100,
    pellets: 1, zoom: 5, viewModel: 'sniper', sound: 'awp', icon: '🎯',
    moveSpread: 9, airSpread: 15, recoilYaw: 1.2, recoilRecovery: 3.6,
    firstShotSpread: 0.04, aimSpread: 0.008, inspectTime: 2.4
  },
  sawedoff: {
    id: 'sawedoff', name: 'Sawed-Off', type: 'shotgun', slot: 1, price: 1100,
    dmg: 32, headMult: 1.8, armorPen: 0.5, fireDelay: 900, auto: false,
    mag: 2, reserve: 30, reloadTime: 2600, spread: 0.085, recoil: 2.0,
    range: 16, falloffStart: 4, falloffEnd: 15, falloff: 0.76, speed: 1.0,
    killReward: 900, pellets: 10, zoom: 1, viewModel: 'shotgun', sound: 'shotgun', icon: '🔫',
moveSpread: 1.8, firstShotSpread: 1, recoilYaw: 0.58, recoilRecovery: 5.8
  }
};

export const GRENADES = {
  he:      { id:'he', name:'Осколочная', price:300, color:0x4a5a3a, icon:'💣', kind:'he',       radius:5.5, dmg:57, fuse:1.6 },
  flash:   { id:'flash', name:'Светошумовая', price:200, color:0xb0b0b0, icon:'⚡', kind:'flash', radius:7.0, blind:3.0, fuse:1.5 },
  smoke:   { id:'smoke', name:'Дымовая', price:300, color:0x7a8088, icon:'🌫️', kind:'smoke', radius:4.2, duration:16, fuse:1.2 },
  molotov: { id:'molotov', name:'Молотов', price:400, color:0xc86a2a, icon:'🔥', kind:'fire',  radius:4.0, duration:7, dps:16, fuse:1.4 }
};

export const BUY_CATEGORIES = [
  { id:'pistols', name:'Пистолеты', items:['p2000','glock','usp','p250','tec9','cz75','five-seven','deagle','r8'] },
  { id:'smgs',    name:'Пистолеты-пулемёты', items:['mac10','uzi','mp9','ump45','mp7','bizon','mp5sd','vector','p90'] },
  { id:'rifles',  name:'Винтовки',  items:['galil','famas','ak47','g36','m4a4','m4a1','sg553','aug','val'] },
  { id:'snipers', name:'Снайперские', items:['ssg08','g3sg1','scar20','awp','barrett'] },
  { id:'heavy',   name:'Тяжёлое', items:['nova','sawedoff','mag7','xm1014','m249','negev'] },
  { id:'gear',    name:'Снаряжение', items:['armor','helmet'] },
  { id:'grenades',name:'Гранаты', items:['he','flash','smoke','molotov'] }
];

export const GEAR = {
  armor:  { id:'armor', name:'Бронежилет', price:650, icon:'🛡️' },
  helmet: { id:'helmet', name:'Шлем', price:1000, icon:'⛑️' }
};

// ---------- skins (procedural, no external assets) ----------
// The actual finish catalog lives in skins.js; this re-export keeps the old
// SKIN_STYLES API stable for existing screens and tests.
export const SKIN_STYLES = {};
for(const key in SKIN_VARIANTS) SKIN_STYLES[key] = SKIN_VARIANTS[key];

export { RARITIES, RARITY_ORDER, buildSkinCatalog, pickWeighted, oddsFor };

export function getSkin(weaponId, skinId){
  const w = WEAPONS[weaponId];
  if(!w) return null;
  const key = skinId || (weaponId + ':stock');
  const parts = key.split(':');
  const styleKey = parts[1] || 'stock';
  const style = SKIN_VARIANTS[styleKey] || SKIN_VARIANTS.stock;
  const rarity = RARITIES[style.rarity] || RARITIES.common;
  return { key, styleKey, ...style, rarity: style.rarity, rarityInfo: rarity, weaponId, weaponName: w.name };
}

export function skinIdFor(weaponId, styleKey){ return weaponId + ':' + styleKey; }

export function skinExists(weaponId, skinId){
  if(!WEAPONS[weaponId] || !skinId) return false;
  const styleKey = String(skinId).split(':')[1] || 'stock';
  return !!SKIN_VARIANTS[styleKey];
}

// Old saves only owned a few hand-picked skins. New profiles get a wider
// starter collection, including knives, so the inventory is never empty.
export function defaultSkins(){
  const owned = [];
  const styles = Object.keys(SKIN_VARIANTS).filter(k => k !== 'stock');
  let n = 0;
  for(const id in WEAPONS){
    owned.push(skinIdFor(id, 'stock'));
    owned.push(skinIdFor(id, styles[n % styles.length]));
    owned.push(skinIdFor(id, styles[(n*7 + 3) % styles.length]));
    n++;
  }
  const curated = {
    ak47:['crimson','tiger','ember','nocturne'],
    m4a4:['forest','hex','ivory'],
    m4a1:['hyper','cobalt','circuit'],
    awp:['frost','blood','galaxy'],
    glock:['neon','urban','sakura'],
    usp:['carbon','obsidian','marble'],
    deagle:['gold','royal','copper'],
    mp9:['carbon','venom','scales'],
    ssg08:['blood','glacier','aurora'],
    aug:['aqua','cobalt','plasma'],
    sg553:['ash','static','jade'],
    ump45:['sunset','sandstorm','tribal'],
    knife:['crimson','gold','blood','galaxy','nocturne','emerald'],
    p90:['neon','plasma','aurora'],
    barrett:['obsidian','magma','nocturne']
  };
  for(const wid in curated){
    if(!WEAPONS[wid]) continue;
    for(const styleKey of curated[wid]){
      if(SKIN_VARIANTS[styleKey]) owned.push(skinIdFor(wid, styleKey));
    }
  }
  // 'emerald' is an alias kept for old curated lists; map it to jade.
  const cleaned = owned.map(id => id.endsWith(':emerald') ? id.replace(':emerald', ':jade') : id);
  return [...new Set(cleaned)];
}

export function weaponById(id){ return WEAPONS[id] || null; }

export const PRIMARY_IDS = Object.keys(WEAPONS).filter(id => WEAPONS[id].slot === 1);
export const PISTOL_IDS = Object.keys(WEAPONS).filter(id => WEAPONS[id].slot === 2);
