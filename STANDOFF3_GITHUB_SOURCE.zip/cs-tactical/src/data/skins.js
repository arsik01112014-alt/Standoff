// Cosmetic finish catalog: palettes, procedural patterns, rarities and drops.
// This module intentionally has no imports so both weapons.js and the crate
// system can use it without circular dependencies.

export const RARITIES = {
  common:    { id:'common',    name:'Обычный',     short:'ОБЫЧНЫЙ',    color:'#9aa4ad', glow:'#6e7780', order:0, weight:100 },
  uncommon:  { id:'uncommon',  name:'Необычный',   short:'НЕОБЫЧНЫЙ',  color:'#57c96a', glow:'#2f8a42', order:1, weight:56 },
  rare:      { id:'rare',      name:'Редкий',      short:'РЕДКИЙ',     color:'#4b93ff', glow:'#245fbf', order:2, weight:24 },
  epic:      { id:'epic',      name:'Эпический',   short:'ЭПИЧЕСКИЙ',  color:'#a86bff', glow:'#6633bb', order:3, weight:8.5 },
  legendary: { id:'legendary', name:'Легендарный', short:'ЛЕГЕНДАРНЫЙ',color:'#ff5252', glow:'#a31d1d', order:4, weight:2.6 },
  secret:    { id:'secret',    name:'Тайный',      short:'ТАЙНЫЙ',     color:'#ffcc4d', glow:'#a97800', order:5, weight:0.55 }
};

export const RARITY_ORDER = ['common','uncommon','rare','epic','legendary','secret'];

function v(key, name, rarity, pattern, body, accent, metal, extra){
  return Object.assign({ key, name, rarity, pattern, body, accent, metal: metal || '#171a1f' }, extra || {});
}

// a/b/c/ink are the four tones used by the canvas painter. body/accent/metal
// drive the PBR palette. Patterns are painted procedurally in guns.js.
export const SKIN_VARIANTS = {
  stock:     v('stock','Стандарт','common','stock', null, null, '#22262c', { a:'#15181c', b:'#252a30', c:'#343b44', ink:'#0a0c0f' }),
  crimson:   v('crimson','Багровый','rare','web', '#7a1515', '#c0392b', '#1a1a1a', { a:'#3d090b', b:'#8f1a1d', c:'#c53a33', ink:'#160406' }),
  gold:      v('gold','Золото','legendary','gold', '#b8860b', '#ffd700', '#3a2c00', { a:'#6b4a0c', b:'#c99a2a', c:'#f3d06a', ink:'#2a1c04' }),
  neon:      v('neon','Неон','epic','circuit', '#0c3b4a', '#00e5ff', '#0a0a12', { a:'#06141f', b:'#0a3145', c:'#0f5a73', ink:'#02070c', emissive:'#00e5ff' }),
  forest:    v('forest','Лес','uncommon','camo', '#2e4724', '#6b8e23', '#1b1b16', { a:'#16250f', b:'#2d451f', c:'#486630', ink:'#0a1206' }),
  frost:     v('frost','Иней','rare','marble', '#5f7d99', '#cfe8ff', '#20262c', { a:'#26384a', b:'#5b7c99', c:'#9cc4df', ink:'#101a24' }),
  carbon:    v('carbon','Карбон','common','carbon', '#15181c', '#3d444c', '#0c0e11', { a:'#0b0d10', b:'#16191e', c:'#222831', ink:'#050608' }),
  blood:     v('blood','Кровь','epic','blood', '#3b0d0d', '#9b1b1b', '#1a1212', { a:'#1e0505', b:'#4a0b0b', c:'#7a1414', ink:'#0d0202' }),
  aqua:      v('aqua','Аква','rare','aqua', '#0b3b3f', '#37e0d8', '#0d1a1c', { a:'#042326', b:'#0a4c50', c:'#127a7c', ink:'#010d0e', emissive:'#37e0d8' }),
  sunset:    v('sunset','Закат','uncommon','stripes', '#6b2e1e', '#ff9d3c', '#241612', { a:'#2c0f12', b:'#7a2418', c:'#c65a22', ink:'#17070a' }),
  tiger:     v('tiger','Тигр','legendary','tiger', '#8a4a12', '#ffb03a', '#2a1a08', { a:'#3a1c04', b:'#b75e13', c:'#e59a2f', ink:'#120801' }),
  hyper:     v('hyper','Гипер','epic','circuit', '#3a1360', '#ff4ad8', '#160a28', { a:'#160a28', b:'#3a1360', c:'#6a2196', ink:'#08030f', emissive:'#ff4ad8' }),
  ash:       v('ash','Пепел','common','static', '#3d4145', '#b9c1c9', '#1a1c1f', { a:'#26282b', b:'#45484c', c:'#6a6f75', ink:'#111214' }),
  royal:     v('royal','Роял','epic','royal', '#35205e', '#e0b64a', '#170b2e', { a:'#170b2e', b:'#35205e', c:'#5b3b96', ink:'#080413' }),

  ember:     v('ember','Уголь','uncommon','ember', '#5a2410', '#ff7a2a', '#211008', { a:'#2a0d05', b:'#6b2a10', c:'#b64a18', ink:'#140601' }),
  glacier:   v('glacier','Ледник','rare','frost', '#3d6f8c', '#a9ecff', '#17252e', { a:'#12303f', b:'#3d6f8c', c:'#78b9d6', ink:'#081820' }),
  venom:     v('venom','Яд','epic','venom', '#243d0f', '#9aff3d', '#101a08', { a:'#101f06', b:'#2c4d12', c:'#4f7d1e', ink:'#060d02' }),
  plasma:    v('plasma','Плазма','legendary','circuit', '#3d0f45', '#ff6af0', '#190620', { a:'#1c0622', b:'#45104f', c:'#7a1f88', ink:'#0b0210', emissive:'#ff6af0' }),
  sandstorm: v('sandstorm','Песчаная буря','uncommon','camo', '#8a6a38', '#e0b76a', '#2a2014', { a:'#4a3620', b:'#8a6a38', c:'#b99755', ink:'#221a10' }),
  urban:     v('urban','Урбан','uncommon','urban', '#3c4650', '#8fa6b8', '#171c21', { a:'#20262c', b:'#3c4650', c:'#5b6874', ink:'#0e1114' }),
  ivory:     v('ivory','Слоновая кость','rare','marble', '#b8a98a', '#f4e8cc', '#2e2a22', { a:'#6f6552', b:'#b8a98a', c:'#ded1b4', ink:'#2e2a22' }),
  obsidian:  v('obsidian','Обсидиан','rare','carbon', '#101216', '#6b7280', '#050607', { a:'#07080a', b:'#15171b', c:'#25282e', ink:'#020303' }),
  copper:    v('copper','Медь','uncommon','copper', '#8a4a24', '#e08a48', '#2a140a', { a:'#40200f', b:'#8a4a24', c:'#c2703a', ink:'#1a0a04' }),
  cobalt:    v('cobalt','Кобальт','rare','frost', '#1f3f8a', '#6aa8ff', '#0b1630', { a:'#0d1f4a', b:'#1f3f8a', c:'#3d63c4', ink:'#050d20' }),
  jade:      v('jade','Нефрит','epic','jade', '#1c5a44', '#6dffc0', '#0a2418', { a:'#0b2a1e', b:'#1c5a44', c:'#2f8a68', ink:'#03120c' }),
  sakura:    v('sakura','Сакура','epic','sakura', '#7a2f52', '#ffb8d8', '#2a0f1c', { a:'#3d1428', b:'#7a2f52', c:'#b8517f', ink:'#1a0710' }),
  hex:       v('hex','Гексагон','rare','hex', '#2a3b4a', '#5cd0ff', '#101820', { a:'#121c24', b:'#2a3b4a', c:'#405a70', ink:'#081016' }),
  circuit:   v('circuit','Цепь','epic','circuit', '#123a2a', '#4dffa0', '#071710', { a:'#061a12', b:'#123a2a', c:'#1f6a4a', ink:'#020a06', emissive:'#4dffa0' }),
  marble:    v('marble','Мрамор','rare','marble', '#6d6f78', '#e8ecf4', '#1c1e22', { a:'#383a40', b:'#6d6f78', c:'#a4a8b2', ink:'#17181c' }),
  tribal:    v('tribal','Племя','uncommon','tribal', '#4a3a2a', '#e0b45c', '#18120c', { a:'#241a12', b:'#4a3a2a', c:'#76603f', ink:'#100a06' }),
  scales:    v('scales','Чешуя','rare','scales', '#174a5a', '#54e0e8', '#081c22', { a:'#08242c', b:'#174a5a', c:'#277386', ink:'#031014' }),
  galaxy:    v('galaxy','Галактика','legendary','galaxy', '#1a1040', '#c08aff', '#080416', { a:'#0b0620', b:'#1a1040', c:'#3a2278', ink:'#04020c', emissive:'#8a5cff' }),
  static:    v('static','Шум','common','static', '#2a2e33', '#c8d2dc', '#101214', { a:'#1a1d21', b:'#2a2e33', c:'#464c54', ink:'#0a0c0e' }),
  camo:      v('camo','Камуфляж','uncommon','camo', '#3d4a2a', '#7d9a4c', '#161c10', { a:'#222a18', b:'#3d4a2a', c:'#5a6e3a', ink:'#0f140a' }),
  magma:     v('magma','Магма','legendary','magma', '#5a1408', '#ff5222', '#1a0804', { a:'#2a0702', b:'#6b1808', c:'#b82a10', ink:'#120301', emissive:'#ff5222' }),
  aurora:    v('aurora','Аврора','legendary','aurora', '#12304a', '#66ffd0', '#081420', { a:'#06182a', b:'#12304a', c:'#2a5a7a', ink:'#020a12', emissive:'#66ffd0' }),
  nocturne:  v('nocturne','Ноктюрн','secret','night', '#241a10', '#ffd36a', '#0c0804', { a:'#0e0a06', b:'#241a10', c:'#4a3218', ink:'#050302', emissive:'#ffd36a' })
};

export const VARIANT_KEYS = Object.keys(SKIN_VARIANTS);

export function variantOf(key){ return SKIN_VARIANTS[key] || SKIN_VARIANTS.stock; }
export function rarityOf(key){ return RARITIES[variantOf(key).rarity] || RARITIES.common; }

export function skinLabel(weaponName, variant){ return `${weaponName} | ${variant.name}`; }

// A deterministic but broad catalog: every weapon supports every finish, so
// the collection has hundreds of legitimate cosmetic combinations.
export function buildSkinCatalog(weapons){
  const list = [];
  for(const wid in weapons){
    const w = weapons[wid];
    for(const vk of VARIANT_KEYS){
      const vr = SKIN_VARIANTS[vk];
      if(vk === 'stock'){
        list.push({ id: wid + ':' + vk, weaponId: wid, weaponName: w.name, variantKey: vk, name: w.name + ' | ' + vr.name, rarity: vr.rarity, rarityInfo: RARITIES[vr.rarity], pattern: vr.pattern, body: vr.body, accent: vr.accent, metal: vr.metal });
        continue;
      }
      list.push({ id: wid + ':' + vk, weaponId: wid, weaponName: w.name, variantKey: vk, name: w.name + ' | ' + vr.name, rarity: vr.rarity, rarityInfo: RARITIES[vr.rarity], pattern: vr.pattern, body: vr.body, accent: vr.accent, metal: vr.metal });
    }
  }
  return list;
}

// Weighted pick used by crates and the daily free drop. Weights are honest:
// the UI prints the exact percentages derived from these numbers.
export function pickWeighted(entries, rng = Math.random){
  const total = entries.reduce((s, e) => s + (RARITIES[e.rarity] ? RARITIES[e.rarity].weight : 1), 0);
  let roll = rng() * total;
  for(const e of entries){
    const w = RARITIES[e.rarity] ? RARITIES[e.rarity].weight : 1;
    if(roll < w) return e;
    roll -= w;
  }
  return entries[entries.length - 1] || null;
}

export function oddsFor(entries){
  const total = entries.reduce((s, e) => s + (RARITIES[e.rarity] ? RARITIES[e.rarity].weight : 1), 0) || 1;
  const out = {};
  for(const id of RARITY_ORDER){
    const w = entries.filter(e => e.rarity === id).reduce((s, e) => s + RARITIES[id].weight, 0);
    if(w > 0) out[id] = Math.round(w / total * 10000) / 100;
  }
  return out;
}
