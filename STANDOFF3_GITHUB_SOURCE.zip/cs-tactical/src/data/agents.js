// Playable agents and procedural outfit variants.
export const TEAM_AGENTS = {
  CT: [
    {
      id:'aegis', name:'AEGIS', role:'Штурм', tag:'URBAN',
      desc:'Тяжёлый бронежилет, полнолицевой шлем и компактный радио-модуль.',
      palette:{
        cloth:'#26354a', cloth2:'#1d2a3d', vest:'#182534', helmet:'#31485f',
        accent:'#4fa3ff', skin:'#b98d6a', mask:'#1e2a36', boots:'#121820',
        glove:'#161e28', pack:'#223349', visor:'#6cc4ff', strap:'#0f1720'
      },
      features:{ helmet:'full', visor:true, mask:'balaclava', pack:'radio', sleeves:'long' }
    },
    {
      id:'vanguard', name:'VANGUARD', role:'Поддержка', tag:'DESERT',
      desc:'Пустынная форма, тактические очки и разгрузка с дополнительными магазинами.',
      palette:{
        cloth:'#6d6754', cloth2:'#595340', vest:'#3e3d31', helmet:'#6d6856',
        accent:'#62b8ff', skin:'#c79a70', mask:'#2d2b22', boots:'#211e17',
        glove:'#26231b', pack:'#4b4838', visor:'#82d4ff', strap:'#191812'
      },
      features:{ helmet:'cap', visor:true, mask:'scarf', pack:'assault', sleeves:'rolled' }
    },
    {
      id:'specter', name:'SPECTER', role:'Разведка', tag:'NIGHT',
      desc:'Лёгкий шлем с гарнитурой, тёмная форма и минимум лишнего снаряжения.',
      palette:{
        cloth:'#202a33', cloth2:'#182129', vest:'#141e27', helmet:'#293b48',
        accent:'#45d6d0', skin:'#a87955', mask:'#111a21', boots:'#0e1419',
        glove:'#121a20', pack:'#1d2a33', visor:'#5ce4e0', strap:'#0b1116'
      },
      features:{ helmet:'bump', visor:true, mask:'balaclava', pack:'small', sleeves:'long' }
    }
  ],
  T: [
    {
      id:'scorpion', name:'SCORPION', role:'Штурм', tag:'URBAN',
      desc:'Бронежилет с нагрудными подсумками, тактическая маска и оранжевые метки.',
      palette:{
        cloth:'#5b5138', cloth2:'#48402c', vest:'#373226', helmet:'#453d2a',
        accent:'#ff9d3d', skin:'#b98154', mask:'#25221a', boots:'#1b1811',
        glove:'#211d14', pack:'#403a29', visor:'#ffb45c', strap:'#17140e'
      },
      features:{ helmet:'none', visor:false, mask:'shemagh', pack:'assault', sleeves:'rolled' }
    },
    {
      id:'nomad', name:'NOMAD', role:'Снайпер', tag:'DESERT',
      desc:'Песочный капюшон, платок на лице и лёгкая разгрузка для долгих засад.',
      palette:{
        cloth:'#84745a', cloth2:'#6c5f49', vest:'#514936', helmet:'#756550',
        accent:'#ffad45', skin:'#c39060', mask:'#332d21', boots:'#262118',
        glove:'#2b261c', pack:'#5b513d', visor:'#ffc46e', strap:'#1e1a13'
      },
      features:{ helmet:'hood', visor:false, mask:'shemagh', pack:'small', sleeves:'rolled' }
    },
    {
      id:'cinder', name:'CINDER', role:'Саботаж', tag:'INDUSTRIAL',
      desc:'Тёмная рабочая куртка, респиратор и индустриальные защитные элементы.',
      palette:{
        cloth:'#3f3a32', cloth2:'#302c26', vest:'#29251f', helmet:'#3e362b',
        accent:'#ff7a38', skin:'#a9714b', mask:'#171512', boots:'#17130f',
        glove:'#1b1712', pack:'#35302a', visor:'#ff9254', strap:'#100e0b'
      },
      features:{ helmet:'respirator', visor:false, mask:'respirator', pack:'radio', sleeves:'long' }
    }
  ]
};

export const AGENT_ORDER = { CT: TEAM_AGENTS.CT.map(a=>a.id), T: TEAM_AGENTS.T.map(a=>a.id) };

export function getAgent(team, id){
  const list = TEAM_AGENTS[team] || TEAM_AGENTS.CT;
  return list.find(a=>a.id === id) || list[0];
}

export function agentAt(team, index){
  const list = TEAM_AGENTS[team] || TEAM_AGENTS.CT;
  return list[((index % list.length) + list.length) % list.length];
}
