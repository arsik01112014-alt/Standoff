// Crate collections. Drops are free: crate tokens come from matches and
// training tasks, and one daily crate is always free. No real-money systems.
import { WEAPONS } from './weapons.js';
import { buildSkinCatalog, pickWeighted, oddsFor, RARITIES } from './skins.js';

let _catalog = null;
function catalog(){
  if(!_catalog) _catalog = buildSkinCatalog(WEAPONS);
  return _catalog;
}

export const CRATES = [
  {
    id:'starter', name:'Стартовый арсенал', tag:'FREE',
    desc:'Базовые finishes для пистолетов и ПП. Бесплатный кейс новичка.',
    price:0, free:true, color:'#57c96a', icon:'▣',
    weapons:['glock','usp','p2000','p250','tec9','cz75','five-seven','deagle','r8','mp9','mac10','uzi','ump45','mp7','bizon','mp5sd','vector','p90'],
    variants:['crimson','gold','neon','forest','frost','carbon','blood','aqua','sunset','tiger','hyper','ash','royal','ember','urban','static','camo','copper','sandstorm','tribal','hex','scales']
  },
  {
    id:'urban', name:'Городской контракт', tag:'CITY',
    desc:'Коллекция улиц Рейна: винтовки, ПП и пистолеты с городскими узорами.',
    price:2, color:'#4b93ff', icon:'▤',
    weapons:['glock','usp','p250','five-seven','mp9','mp7','ump45','p90','vector','ak47','m4a4','m4a1','galil','famas','g36','aug','sg553','val'],
    variants:['urban','hex','circuit','cobalt','ivory','marble','obsidian','static','ash','carbon','copper','emerald','jade','sakura','royal','hyper','neon','venom']
  },
  {
    id:'harbor', name:'Порт «Норд»', tag:'HARBOR',
    desc:'Морская коллекция: снайперские винтовки, дробовики и тяжёлое оружие.',
    price:2, color:'#37e0d8', icon:'◈',
    weapons:['ssg08','g3sg1','scar20','awp','barrett','nova','xm1014','mag7','sawedoff','m249','negev','mp5sd','bizon','p90','deagle'],
    variants:['aqua','glacier','frost','scales','venom','jade','cobalt','galaxy','aurora','marble','carbon','obsidian','plasma','neon','blood']
  },
  {
    id:'elite', name:'Элитный протокол', tag:'ELITE',
    desc:'Расширенный пул с повышенным шансом эпических и легендарных предметов.',
    price:3, color:'#a86bff', icon:'✦',
    weapons:['ak47','m4a4','m4a1','awp','barrett','deagle','r8','knife','p90','vector','sg553','aug','ssg08','mag7','mp7'],
    variants:['plasma','galaxy','magma','aurora','nocturne','sakura','jade','venom','royal','hyper','tiger','gold','circuit','hex','blood','ember']
  },
  {
    id:'secret', name:'Тайный архив', tag:'SECRET',
    desc:'Максимальный шанс тайных и легендарных finishes. Награда за серию матчей.',
    price:4, color:'#ffcc4d', icon:'✧',
    weapons:['ak47','m4a4','m4a1','awp','barrett','deagle','knife','p90','vector','usp','glock','ssg08','mag7','negev'],
    variants:['nocturne','galaxy','magma','aurora','plasma','gold','tiger','jade','sakura','royal','hyper','circuit','venom','ember'],
    secretBoost:true
  }
];

const _pools = new Map();
export function cratePool(crateId){
  if(_pools.has(crateId)) return _pools.get(crateId);
  const crate = CRATES.find(c => c.id === crateId);
  if(!crate) return [];
  const weapons = new Set(crate.weapons || []);
  const variants = new Set(crate.variants || []);
  let pool = catalog().filter(item => weapons.has(item.weaponId) && variants.has(item.variantKey));
  if(crate.secretBoost){
    // Duplicate the top rarities inside this crate so the stated odds reflect
    // the elite nature of the collection without lying about the formula.
    const boosted = pool.filter(i => i.rarity === 'legendary' || i.rarity === 'secret');
    pool = pool.concat(boosted);
  }
  _pools.set(crateId, pool);
  return pool;
}

export function crateOdds(crateId){ return oddsFor(cratePool(crateId)); }

export function crateRarityList(crateId){
  const pool = cratePool(crateId);
  const ids = [...new Set(pool.map(i => i.rarity))];
  const order = ['common','uncommon','rare','epic','legendary','secret'];
  return ids.sort((a,b)=>order.indexOf(a)-order.indexOf(b)).map(id=>({ id, ...RARITIES[id], count:pool.filter(i=>i.rarity===id).length }));
}

export function openCrate(crateId, rng = Math.random){
  const pool = cratePool(crateId);
  if(!pool.length) return null;
  return pickWeighted(pool, rng);
}

export function crateById(id){ return CRATES.find(c => c.id === id) || null; }

// A deterministic roll used for the visual reel. It does not affect the drop:
// the result is picked first, then the reel is arranged around it.
export function buildReel(crateId, winnerId, count = 38, rng = Math.random){
  const pool = cratePool(crateId);
  const out = [];
  for(let i=0;i<count;i++) out.push(pool[Math.floor(rng()*pool.length)]);
  const mid = Math.floor(count/2);
  if(winnerId){
    const idx = pool.findIndex(i => i.id === winnerId);
    if(idx >= 0) out[mid] = pool[idx];
  }
  return { items: out, index: mid };
}
