// Procedural sound engine (no audio files). All sounds synthesised with WebAudio.
// A compressor/limiter keeps layered gunfire from clipping on phone speakers.
import { getState } from './state.js';

class AudioEngine {
  constructor(){
    this.ctx = null;
    this.master = null;
    this.limiter = null;
    this.noise = null;
    this._lastFoot = 0;
  }

  init(){
    if(this.ctx) return;
    try{
      const AC = window.AudioContext || window.webkitAudioContext;
      this.ctx = new AC();
      this.master = this.ctx.createGain();
      this.master.gain.value = getState().settings.volume;
      this.limiter = this.ctx.createDynamicsCompressor();
      this.limiter.threshold.value = -12;
      this.limiter.knee.value = 18;
      this.limiter.ratio.value = 8;
      this.limiter.attack.value = 0.003;
      this.limiter.release.value = 0.18;
      this.master.connect(this.limiter);
      this.limiter.connect(this.ctx.destination);
      this._buildNoise();
    }catch(e){ this.ctx = null; }
  }

  resume(){ if(this.ctx && this.ctx.state === 'suspended') this.ctx.resume(); }
  setVolume(v){ if(this.master) this.master.gain.value = Math.max(0, Math.min(1, v)); }

  _buildNoise(){
    const len = this.ctx.sampleRate * 0.6;
    const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const data = buf.getChannelData(0);
    for(let i=0;i<len;i++) data[i] = Math.random()*2-1;
    this.noise = buf;
  }

  _bus(pan=0){
    if(!this.ctx) return null;
    const g = this.ctx.createGain();
    if(this.ctx.createStereoPanner){
      const p = this.ctx.createStereoPanner();
      p.pan.value = Math.max(-1, Math.min(1, pan));
      g.connect(p); p.connect(this.master);
    } else {
      g.connect(this.master);
    }
    return g;
  }

  _noiseBurst(dur, vol, filterFreq, q=1, type='lowpass', delay=0, pan=0){
    if(!this.ctx) return;
    const t = this.ctx.currentTime + delay;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noise;
    src.playbackRate.value = 0.85 + Math.random()*0.3;
    const f = this.ctx.createBiquadFilter();
    f.type = type; f.frequency.value = filterFreq; f.Q.value = q;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(Math.max(0.0001, vol), t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(f); f.connect(g);
    const bus = this._bus(pan);
    if(bus) g.connect(bus); else g.connect(this.master);
    src.start(t); src.stop(t + dur + 0.03);
  }

  _tone(freq, dur, vol, type='sine', slideTo=null, delay=0, pan=0){
    if(!this.ctx) return;
    const t = this.ctx.currentTime + delay;
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    if(slideTo) o.frequency.exponentialRampToValueAtTime(Math.max(20, slideTo), t + dur);
    g.gain.setValueAtTime(Math.max(0.0001, vol), t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g);
    const bus = this._bus(pan);
    if(bus) g.connect(bus); else g.connect(this.master);
    o.start(t); o.stop(t + dur + 0.03);
  }

  // op is optional {pan, dist} for positional shots.
  shot(kind, op){
    if(!this.ctx) return;
    const dist = op && op.dist ? op.dist : 0;
    const pan = op && op.pan ? op.pan : 0;
    const att = 1 / (1 + dist * 0.055);
    const v = (x) => Math.max(0.001, x * att);
    const low = dist > 25 ? 0.7 : 1;
    switch(kind){
      case 'ak':
        this._noiseBurst(0.15, v(0.55), 1400*low, 0.7, 'lowpass', 0, pan);
        this._noiseBurst(0.035, v(0.35), 4200, 1.4, 'highpass', 0, pan);
        this._tone(92, 0.11, v(0.34), 'sawtooth', 38, 0, pan);
        break;
      case 'm4':
        this._noiseBurst(0.11, v(0.42), 2100*low, 0.8, 'lowpass', 0, pan);
        this._noiseBurst(0.028, v(0.28), 5200, 1.2, 'highpass', 0, pan);
        this._tone(125, 0.075, v(0.24), 'square', 58, 0, pan);
        break;
      case 'm4_sil':
        this._noiseBurst(0.07, v(0.22), 2600, 1.2, 'lowpass', 0, pan);
        this._tone(190, 0.05, v(0.12), 'sine', 90, 0, pan);
        break;
      case 'smg':
        this._noiseBurst(0.075, v(0.34), 2600*low, 1, 'lowpass', 0, pan);
        this._noiseBurst(0.02, v(0.2), 6000, 1.4, 'highpass', 0, pan);
        this._tone(165, 0.05, v(0.16), 'square', 80, 0, pan);
        break;
      case 'pistol':
        this._noiseBurst(0.09, v(0.36), 2200, 1, 'lowpass', 0, pan);
        this._noiseBurst(0.02, v(0.2), 5000, 1.2, 'highpass', 0, pan);
        this._tone(150, 0.06, v(0.18), 'square', 70, 0, pan);
        break;
      case 'pistol_sil':
        this._noiseBurst(0.055, v(0.17), 3000, 1.4, 'lowpass', 0, pan);
        this._tone(220, 0.04, v(0.08), 'sine', 120, 0, pan);
        break;
      case 'deagle':
        this._noiseBurst(0.19, v(0.62), 1100, 0.6, 'lowpass', 0, pan);
        this._noiseBurst(0.04, v(0.32), 3800, 1, 'highpass', 0, pan);
        this._tone(72, 0.17, v(0.42), 'sawtooth', 28, 0, pan);
        break;
      case 'awp':
        this._noiseBurst(0.3, v(0.72), 900, 0.5, 'lowpass', 0, pan);
        this._noiseBurst(0.07, v(0.3), 3000, 0.8, 'highpass', 0, pan);
        this._tone(58, 0.28, v(0.48), 'sawtooth', 22, 0, pan);
        this._noiseBurst(0.5, v(0.12), 500, 0.4, 'lowpass', 0.06, pan);
        break;
      case 'ssg':
        this._noiseBurst(0.19, v(0.52), 1300, 0.6, 'lowpass', 0, pan);
        this._tone(86, 0.16, v(0.32), 'sawtooth', 32, 0, pan);
        break;
      case 'lmg':
        this._noiseBurst(0.1, v(0.5), 1200, 0.6, 'lowpass', 0, pan);
        this._tone(78, 0.09, v(0.32), 'sawtooth', 38, 0, pan);
        break;
      case 'shotgun':
        this._noiseBurst(0.23, v(0.66), 800, 0.5, 'lowpass', 0, pan);
        this._noiseBurst(0.06, v(0.3), 2600, 0.9, 'highpass', 0, pan);
        this._tone(64, 0.19, v(0.42), 'sawtooth', 26, 0, pan);
        break;
      case 'knife':
        this._noiseBurst(0.055, v(0.2), 4200, 2, 'highpass', 0, pan);
        this._tone(2100, 0.04, v(0.04), 'sine', 900, 0, pan);
        break;
      default:
        this._noiseBurst(0.1, v(0.4), 1800, 0.8, 'lowpass', 0, pan);
    }
  }

  shotAt(kind, dx, dz, yaw){
    const dist = Math.hypot(dx, dz);
    const rx = Math.cos(yaw), rz = -Math.sin(yaw);
    const pan = dist > 0.01 ? (dx*rx + dz*rz) / dist : 0;
    this.shot(kind, { dist, pan: Math.max(-0.85, Math.min(0.85, pan)) });
  }

  reload(){
    this._tone(900,0.035,0.07,'square');
    setTimeout(()=>this._tone(500,0.05,0.07,'square'),130);
    setTimeout(()=>this._noiseBurst(0.04,0.08,2200,2,'bandpass'),230);
    setTimeout(()=>this._tone(700,0.03,0.05,'square'),320);
  }
  reloadAt(dist, pan=0){
    const att = 1/(1+(dist||0)*0.14);
    if(att < 0.08) return;
    this._tone(700,0.035,0.05*att,'square',null,0,pan);
    this._tone(420,0.045,0.045*att,'square',null,0.14,pan);
  }
  hit(head){
    this._tone(head?1500:950, head?0.07:0.05, 0.11, 'square', head?1000:650);
    if(head) this._tone(2400, 0.12, 0.05, 'sine', 1400, 0.02);
  }
  hitArmor(){ this._tone(520, 0.045, 0.08, 'triangle', 380); }
  death(){ this._noiseBurst(0.28, 0.3, 500, 0.6); this._tone(120,0.28,0.14,'sawtooth',50); }
  explosion(){ this._noiseBurst(0.75, 0.8, 480, 0.4); this._tone(52, 0.65, 0.5, 'sawtooth', 18); this._noiseBurst(0.9, 0.2, 260, 0.5, 'lowpass', 0.05); }
  footstep(vol=1){
    const now = this.ctx ? this.ctx.currentTime : 0;
    if(now - this._lastFoot < 0.06) return;
    this._lastFoot = now;
    this._noiseBurst(0.06, 0.11*vol, 620, 1.2);
    this._tone(110, 0.035, 0.04*vol, 'sine', 70);
  }
  footstepAt(dist, pan, vol=1){
    const att = 1/(1+dist*0.12);
    if(att < 0.05) return;
    this._noiseBurst(0.055, 0.13*vol*att, 700, 1.1, 'lowpass', 0, pan);
  }
  whiz(pan=0){
    this._noiseBurst(0.07, 0.12, 2400, 2.5, 'bandpass', 0, pan);
    this._tone(1200, 0.06, 0.04, 'sine', 2400, 0, pan);
  }
  click(){ this._tone(700, 0.03, 0.06, 'square', 500); }
  uiHover(){ this._tone(520, 0.02, 0.025, 'sine', 640); }
  roundStart(){ this._tone(440,0.15,0.11,'triangle'); setTimeout(()=>this._tone(660,0.2,0.11,'triangle'),160); }
  win(){ [523,659,784,1047].forEach((f,i)=>setTimeout(()=>this._tone(f,0.25,0.11,'triangle'),i*130)); }
  lose(){ [400,330,260].forEach((f,i)=>setTimeout(()=>this._tone(f,0.3,0.11,'sawtooth'),i*160)); }
  flashRing(){ this._tone(3000, 1.2, 0.07, 'sine', 1200); }
  pickup(){ this._tone(600,0.08,0.09,'square',900); }
  beep(freq=880, vol=0.05){ this._tone(freq, 0.055, vol, 'sine'); }
  bombBeep(fast){ this._tone(fast?1500:1000, 0.05, 0.06, 'square'); }
  dryFire(){ this._noiseBurst(0.03, 0.07, 3200, 2, 'highpass'); }
  inspect(){ this._tone(340,0.05,0.04,'triangle',260); setTimeout(()=>this._tone(220,0.06,0.03,'triangle',180),90); }
  countdown(final){ this._tone(final?880:520, final?0.18:0.09, 0.09, 'triangle'); }
}

export const audio = new AudioEngine();
