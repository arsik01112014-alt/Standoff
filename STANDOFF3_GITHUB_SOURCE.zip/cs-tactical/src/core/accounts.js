// Local account system with PBKDF2 password hashing and persisted sessions.
// The game runs fully offline; accounts are device-local, but registration,
// validation, lockout and session restore are real rather than cosmetic.
import { getState, snapshotState, applySnapshot, saveState, onStateSaved } from './state.js';

const ACCOUNTS_KEY = 'steel_front_accounts_v3';
const SESSION_KEY = 'steel_front_session_v3';
const ITERATIONS = 120000;
const SESSION_TTL = 1000 * 60 * 60 * 24 * 14; // 14 days
const MAX_ATTEMPTS = 5;
const LOCK_MS = 1000 * 60 * 3;

function readAccounts(){
  try{
    const raw = localStorage.getItem(ACCOUNTS_KEY);
    const list = raw ? JSON.parse(raw) : [];
    return Array.isArray(list) ? list : [];
  }catch(e){ return []; }
}
function writeAccounts(list){
  try{ localStorage.setItem(ACCOUNTS_KEY, JSON.stringify(list)); }catch(e){}
}
function readSession(){
  try{
    const raw = localStorage.getItem(SESSION_KEY);
    return raw ? JSON.parse(raw) : null;
  }catch(e){ return null; }
}
function writeSession(s){
  try{
    if(s) localStorage.setItem(SESSION_KEY, JSON.stringify(s));
    else localStorage.removeItem(SESSION_KEY);
  }catch(e){}
}

function bytesToHex(bytes){
  let out = '';
  for(let i=0;i<bytes.length;i++) out += bytes[i].toString(16).padStart(2,'0');
  return out;
}
function hexToBytes(hex){
  const out = new Uint8Array(hex.length/2);
  for(let i=0;i<out.length;i++) out[i] = parseInt(hex.substr(i*2,2),16);
  return out;
}
function randomHex(len=16){
  const b = new Uint8Array(len);
  const c = globalThis.crypto;
  if(c && c.getRandomValues) c.getRandomValues(b);
  else for(let i=0;i<len;i++) b[i] = Math.floor(Math.random()*256);
  return bytesToHex(b);
}

// Compact SHA-256 + PBKDF2 fallback for WebViews where crypto.subtle is not
// exposed (older Android WebView builds). The iteration count is stored with
// the account, so hashes remain verifiable on all devices.
const K256 = new Uint32Array([
  0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
  0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
  0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
  0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
  0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
  0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
  0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
  0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
]);
function sha256(bytes){
  const len = bytes.length;
  const padded = new Uint8Array(((len + 9 + 63) >> 6) << 6);
  padded.set(bytes);
  padded[len] = 0x80;
  const bitLen = len * 8;
  for(let i=0;i<4;i++) padded[padded.length-1-i] = (bitLen >>> (i*8)) & 0xff;
  const H = new Uint32Array([0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19]);
  const w = new Uint32Array(64);
  const rotr = (x,n)=>(x>>>n)|(x<<(32-n));
  for(let off=0; off<padded.length; off+=64){
    for(let i=0;i<16;i++){
      const j=off+i*4;
      w[i] = (padded[j]<<24)|(padded[j+1]<<16)|(padded[j+2]<<8)|padded[j+3];
    }
    for(let i=16;i<64;i++){
      const s0 = rotr(w[i-15],7)^rotr(w[i-15],18)^(w[i-15]>>>3);
      const s1 = rotr(w[i-2],17)^rotr(w[i-2],19)^(w[i-2]>>>10);
      w[i] = (w[i-16]+s0+w[i-7]+s1)>>>0;
    }
    let [a,b,c,d,e,f,g,h] = H;
    for(let i=0;i<64;i++){
      const S1 = rotr(e,6)^rotr(e,11)^rotr(e,25);
      const ch = (e&f)^((~e)&g);
      const t1 = (h+S1+ch+K256[i]+w[i])>>>0;
      const S0 = rotr(a,2)^rotr(a,13)^rotr(a,22);
      const maj = (a&b)^(a&c)^(b&c);
      const t2 = (S0+maj)>>>0;
      h=g; g=f; f=e; e=(d+t1)>>>0;
      d=c; c=b; b=a; a=(t1+t2)>>>0;
    }
    H[0]=(H[0]+a)>>>0; H[1]=(H[1]+b)>>>0; H[2]=(H[2]+c)>>>0; H[3]=(H[3]+d)>>>0;
    H[4]=(H[4]+e)>>>0; H[5]=(H[5]+f)>>>0; H[6]=(H[6]+g)>>>0; H[7]=(H[7]+h)>>>0;
  }
  const out = new Uint8Array(32);
  for(let i=0;i<8;i++){
    out[i*4] = H[i]>>>24; out[i*4+1] = (H[i]>>>16)&0xff;
    out[i*4+2] = (H[i]>>>8)&0xff; out[i*4+3] = H[i]&0xff;
  }
  return out;
}
function hmacSha256(keyBytes, msgBytes){
  let key = keyBytes.length > 64 ? sha256(keyBytes) : keyBytes;
  const pad = new Uint8Array(64);
  pad.set(key);
  const ipad = new Uint8Array(64 + msgBytes.length);
  const opad = new Uint8Array(64 + 32);
  for(let i=0;i<64;i++){ ipad[i] = pad[i] ^ 0x36; opad[i] = pad[i] ^ 0x5c; }
  ipad.set(msgBytes, 64);
  opad.set(sha256(ipad), 64);
  return sha256(opad);
}
function pbkdf2Fallback(password, saltHex, iterations){
  const enc = new TextEncoder();
  const pw = enc.encode(password);
  const salt = hexToBytes(saltHex);
  const msg = new Uint8Array(salt.length + 4);
  msg.set(salt);
  msg[salt.length] = 0; msg[salt.length+1] = 0; msg[salt.length+2] = 0; msg[salt.length+3] = 1;
  let u = hmacSha256(pw, msg);
  const out = new Uint8Array(u);
  for(let i=1;i<iterations;i++){
    u = hmacSha256(pw, u);
    for(let k=0;k<32;k++) out[k] ^= u[k];
  }
  return bytesToHex(out);
}

async function derive(password, saltHex, iterations=ITERATIONS){
  const subtle = globalThis.crypto && globalThis.crypto.subtle;
  if(!subtle) return pbkdf2Fallback(password, saltHex, Math.min(iterations, 30000));
  const enc = new TextEncoder();
  const key = await subtle.importKey('raw', enc.encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await subtle.deriveBits({
    name:'PBKDF2', salt:hexToBytes(saltHex), iterations, hash:'SHA-256'
  }, key, 256);
  return bytesToHex(new Uint8Array(bits));
}

function normalizeUsername(v){ return String(v || '').trim().toLowerCase(); }

export function validateUsername(v){
  const s = String(v || '').trim();
  if(s.length < 3 || s.length > 18) return 'Логин: от 3 до 18 символов';
  if(!/^[A-Za-z0-9_\-\u0400-\u04FF]+$/.test(s)) return 'Логин: буквы, цифры, _ и -';
  return null;
}
export function validatePassword(v){
  const s = String(v || '');
  if(s.length < 6) return 'Пароль: минимум 6 символов';
  if(s.length > 128) return 'Пароль слишком длинный';
  if(!/[A-Za-z\u0400-\u04FF]/.test(s) || !/[0-9]/.test(s)) return 'Пароль должен содержать буквы и цифры';
  return null;
}

export function publicAccount(acc){
  if(!acc) return null;
  return {
    id: acc.id,
    username: acc.username,
    displayName: acc.displayName,
    createdAt: acc.createdAt,
    lastLogin: acc.lastLogin,
    matches: acc.state && acc.state.profile ? acc.state.profile.matches : 0,
    wins: acc.state && acc.state.profile ? acc.state.profile.wins : 0
  };
}

export function currentSession(){
  const s = readSession();
  if(!s || !s.accountId || !s.token || !s.exp) return null;
  if(Date.now() > s.exp){ writeSession(null); return null; }
  const acc = readAccounts().find(a => a.id === s.accountId);
  if(!acc || acc.sessionToken !== s.token){ writeSession(null); return null; }
  return { account: publicAccount(acc), record: acc, session: s };
}

export function restoreSession(){
  const s = currentSession();
  if(!s) return null;
  // Pull the latest profile snapshot so every device-local login is consistent.
  if(s.record.state) applySnapshot(s.record.state);
  return s.account;
}

export function logout(){
  const s = readSession();
  if(s){
    const list = readAccounts();
    const acc = list.find(a => a.id === s.accountId);
    if(acc){ acc.sessionToken = null; acc.sessionExpires = 0; writeAccounts(list); }
  }
  writeSession(null);
}

function makeSession(acc, list){
  const token = randomHex(32);
  const exp = Date.now() + SESSION_TTL;
  acc.sessionToken = token;
  acc.sessionExpires = exp;
  acc.lastLogin = Date.now();
  writeAccounts(list);
  writeSession({ accountId: acc.id, token, exp });
  return acc;
}

export async function register({ username, password, confirm, displayName }){
  const uErr = validateUsername(username);
  if(uErr) return { ok:false, error:uErr };
  const pErr = validatePassword(password);
  if(pErr) return { ok:false, error:pErr };
  if(confirm !== undefined && password !== confirm) return { ok:false, error:'Пароли не совпадают' };
  const name = String(displayName || username).trim().slice(0,16);
  if(name.length < 2) return { ok:false, error:'Имя игрока: минимум 2 символа' };

  const list = readAccounts();
  const key = normalizeUsername(username);
  if(list.some(a => a.usernameLower === key)) return { ok:false, error:'Этот логин уже занят' };

  const salt = randomHex(16);
  let hash;
  try{ hash = await derive(password, salt); }
  catch(e){ return { ok:false, error:e.message }; }

  const acc = {
    id: 'acc_' + randomHex(8),
    username: String(username).trim(),
    usernameLower: key,
    displayName: name,
    salt, hash, iterations: (globalThis.crypto && globalThis.crypto.subtle) ? ITERATIONS : 30000,
    createdAt: Date.now(),
    lastLogin: Date.now(),
    failed: 0, lockedUntil: 0,
    state: snapshotState()
  };
  if(acc.state.profile) acc.state.profile.name = name;
  list.push(acc);
  writeAccounts(list);
  saveSessionAndState(acc, list);
  return { ok:true, account:publicAccount(acc) };
}

export async function login({ username, password }){
  const list = readAccounts();
  const key = normalizeUsername(username);
  const acc = list.find(a => a.usernameLower === key);
  if(!acc) return { ok:false, error:'Аккаунт не найден' };
  if(acc.lockedUntil && acc.lockedUntil > Date.now()){
    const sec = Math.ceil((acc.lockedUntil - Date.now())/1000);
    return { ok:false, error:`Слишком много попыток. Подождите ${sec} с.` };
  }
  let hash;
  try{ hash = await derive(password, acc.salt, acc.iterations || ITERATIONS); }
  catch(e){ return { ok:false, error:e.message }; }
  if(hash !== acc.hash){
    acc.failed = (acc.failed || 0) + 1;
    if(acc.failed >= MAX_ATTEMPTS){ acc.lockedUntil = Date.now() + LOCK_MS; acc.failed = 0; }
    writeAccounts(list);
    return { ok:false, error:'Неверный логин или пароль', attemptsLeft: Math.max(0, MAX_ATTEMPTS - acc.failed) };
  }
  acc.failed = 0; acc.lockedUntil = 0;
  writeAccounts(list);
  saveSessionAndState(acc, list);
  return { ok:true, account:publicAccount(acc) };
}

function saveSessionAndState(acc, list){
  makeSession(acc, list);
  if(acc.state) applySnapshot(acc.state);
  else {
    const st = getState();
    if(st.profile) st.profile.name = acc.displayName;
    saveState();
  }
}

// Writes the current profile into the active account after every saveState().
export function bindAccountSync(){
  onStateSaved(st => {
    const s = readSession();
    if(!s) return;
    const list = readAccounts();
    const acc = list.find(a => a.id === s.accountId);
    if(!acc) return;
    acc.state = JSON.parse(JSON.stringify(st));
    acc.displayName = st.profile ? st.profile.name : acc.displayName;
    acc.updatedAt = Date.now();
    writeAccounts(list);
  });
}

export function renameAccount(displayName){
  const s = currentSession();
  if(!s) return { ok:false, error:'Нет активной сессии' };
  const name = String(displayName || '').trim().slice(0,16);
  if(name.length < 2) return { ok:false, error:'Имя игрока: минимум 2 символа' };
  const list = readAccounts();
  const acc = list.find(a => a.id === s.account.id);
  if(!acc) return { ok:false, error:'Аккаунт не найден' };
  acc.displayName = name;
  getState().profile.name = name;
  acc.state = snapshotState();
  writeAccounts(list);
  saveState();
  return { ok:true, account:publicAccount(acc) };
}
