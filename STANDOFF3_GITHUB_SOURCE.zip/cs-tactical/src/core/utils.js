// Small shared helpers.

export const clamp = (v, a, b) => v < a ? a : (v > b ? b : v);
export const lerp = (a, b, t) => a + (b - a) * t;
export const dist2 = (ax, az, bx, bz) => Math.hypot(ax - bx, az - bz);
export const deg2rad = d => d * Math.PI / 180;
export const rad2deg = r => r * 180 / Math.PI;

export function formatTime(sec){
  sec = Math.max(0, Math.ceil(sec));
  const m = Math.floor(sec / 60), s = sec % 60;
  return m + ':' + String(s).padStart(2, '0');
}

// Mulberry32 seeded RNG
export function makeRNG(seed){
  let a = seed >>> 0;
  return function(){
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
export const randRange = (rng, a, b) => a + rng() * (b - a);
export const pick = (rng, arr) => arr[Math.floor(rng() * arr.length) % arr.length];

// shortest signed angle difference
export function angleDiff(a, b){
  let d = (b - a) % (Math.PI * 2);
  if(d > Math.PI) d -= Math.PI * 2;
  if(d < -Math.PI) d += Math.PI * 2;
  return d;
}
export function angleLerp(a, b, t){
  return a + angleDiff(a, b) * t;
}

export function nowMs(){ return performance.now(); }

export function uid(prefix='id'){
  return prefix + '_' + Math.random().toString(36).slice(2, 9);
}
