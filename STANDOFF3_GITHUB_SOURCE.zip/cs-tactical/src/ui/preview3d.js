// Standalone 3D showcase used by the inventory, arsenal and agent screens.
// It owns its renderer and camera so the menu background scene is untouched.
import * as THREE from '../../vendor/three.module.js';
import { makeGunMesh } from '../world/guns.js';
import { getSkin, WEAPONS } from '../data/weapons.js';
import { createCharacter } from '../world/characters.js';
import { getAgent } from '../data/agents.js';

export class ModelPreview {
  constructor(){
    this.overlay = null;
    this.open = false;
    this.autoRotate = true;
    this.yaw = 0.6;
    this.pitch = 0.18;
    this.dist = 4.2;
    this.targetDist = 4.2;
    this._raf = 0;
    this._last = 0;
    this._drag = null;
    this._pinch = null;
    this._fallback = false;
  }

  showWeapon(weaponId, skinId, opts = {}){
    const w = WEAPONS[weaponId];
    if(!w) return;
    const skin = getSkin(weaponId, skinId) || getSkin(weaponId, weaponId + ':stock');
    const title = opts.title || (skin.weaponName + ' | ' + skin.name);
    const subtitle = opts.subtitle || `${w.type.toUpperCase()} · $${w.price} · ${w.dmg} урона`;
    const rarity = opts.rarityInfo || skin.rarityInfo;
    this._open({
      title,
      subtitle,
      rarity,
      kind: 'weapon',
      make: () => makeGunMesh(weaponId, skinId, 'high'),
      info: opts.info || `${w.name}: магазин ${w.mag === Infinity ? '∞' : w.mag}, темп ${Math.round(1000 / w.fireDelay)}/с, дальность ${w.range} м.`
    });
  }

  showAgent(team, agentId, opts = {}){
    const agent = getAgent(team, agentId);
    this._open({
      title: opts.title || agent.name,
      subtitle: opts.subtitle || `${team === 'CT' ? 'СПЕЦНАЗ' : 'ТЕРРОРИСТЫ'} · ${agent.role} · ${agent.tag}`,
      rarity: opts.rarityInfo || null,
      kind: 'agent',
      make: () => createCharacter(team, team === 'CT' ? 'm4a1' : 'ak47', null, agentId).root,
      info: opts.info || agent.desc
    });
  }

  _open(opts){
    if(typeof document === 'undefined') return;
    this.close();
    const host = document.createElement('div');
    host.className = 'previewOverlay';
    host.innerHTML = `
      <div class="previewPanel">
        <div class="previewHead">
          <div class="previewTitles">
            <div class="previewRarity" style="--rc:${opts.rarity ? opts.rarity.color : '#7d8b99'}">${opts.rarity ? opts.rarity.name.toUpperCase() : 'ПРЕДПРОСМОТР'}</div>
            <h3>${esc(opts.title)}</h3>
            <span>${esc(opts.subtitle || '')}</span>
          </div>
          <button class="previewClose" id="previewClose" aria-label="Закрыть">✕</button>
        </div>
        <div class="previewStage"><canvas id="previewCanvas"></canvas><div class="previewBadge">3D</div><div class="previewFallback hidden" id="previewFallback">3D-предпросмотр недоступен в этом браузере</div></div>
        <div class="previewFoot">
          <div class="previewInfo">${esc(opts.info || '')}</div>
          <div class="previewTools">
            <button class="pbtn" id="previewAuto" title="Автовращение">⟳ АВТО</button>
            <button class="pbtn" id="previewReset" title="Сброс камеры">СБРОС</button>
            <span class="previewHint">Перетащите — вращение · колесо/щипок — масштаб</span>
          </div>
        </div>
      </div>`;
    document.body.appendChild(host);
    this.overlay = host;
    this.open = true;
    this.autoRotate = true;
    this.yaw = opts.kind === 'agent' ? 0.15 : 0.65;
    this.pitch = 0.16;
    const canvas = host.querySelector('#previewCanvas');
    try{
      const renderer = new THREE.WebGLRenderer({ canvas, antialias:true, alpha:true, powerPreference:'high-performance' });
      renderer.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
      renderer.setSize(canvas.clientWidth || 640, canvas.clientHeight || 420, false);
      renderer.outputColorSpace = THREE.SRGBColorSpace;
      renderer.toneMapping = THREE.ACESFilmicToneMapping;
      renderer.toneMappingExposure = 1.12;
      this.renderer = renderer;
    }catch(e){
      this._fallback = true;
      host.querySelector('#previewFallback').classList.remove('hidden');
    }

    const scene = new THREE.Scene();
    scene.background = null;
    this.scene = scene;
    this.camera = new THREE.PerspectiveCamera(36, 1, 0.03, 80);

    const hemi = new THREE.HemisphereLight(0x9dc4ff, 0x10151c, 1.1);
    scene.add(hemi);
    const key = new THREE.DirectionalLight(0xffe7c4, 2.2); key.position.set(3.5, 5.5, 4); scene.add(key);
    const rim = new THREE.DirectionalLight(0x5fa8ff, 1.7); rim.position.set(-4, 2.6, -3.5); scene.add(rim);
    const fill = new THREE.PointLight(0xff9a4a, 5, 12, 2); fill.position.set(-2.6, 1.5, 2.4); scene.add(fill);
    this.lights = [hemi, key, rim, fill];

    const floor = new THREE.Mesh(
      new THREE.CircleGeometry(3.4, 48),
      new THREE.MeshStandardMaterial({ color:0x0d141c, roughness:0.38, metalness:0.72, transparent:true, opacity:0.94 })
    );
    floor.rotation.x = -Math.PI/2; floor.position.y = -0.02; scene.add(floor);
    const ring = new THREE.Mesh(
      new THREE.RingGeometry(2.15, 2.28, 64),
      new THREE.MeshBasicMaterial({ color: opts.rarity ? opts.rarity.color : 0x4f7fa8, transparent:true, opacity:0.45, side:THREE.DoubleSide })
    );
    ring.rotation.x = -Math.PI/2; ring.position.y = 0.005; scene.add(ring);
    this.floor = floor; this.ring = ring;

    let model = null;
    try{ model = opts.make(); }catch(e){ model = null; }
    this.model = model;
    if(model){
      scene.add(model);
      model.updateMatrixWorld(true);
      const box = new THREE.Box3().setFromObject(model);
      const size = box.getSize(new THREE.Vector3());
      const center = box.getCenter(new THREE.Vector3());
      model.position.sub(center);
      const maxDim = Math.max(size.x, size.y, size.z) || 1;
      const fit = (opts.kind === 'agent' ? 2.55 : 2.25) / maxDim;
      model.scale.multiplyScalar(fit);
      model.position.y += opts.kind === 'agent' ? 0.35 : 0.05;
      // A subtly different pose makes rifles and pistols read better.
      model.rotation.set(0, 0, 0);
      this.baseScale = model.scale.clone();
      this.radius = Math.max(1.2, (maxDim * fit) * 0.72);
      this.modelHeight = size.y * fit;
    } else {
      this.radius = 1.3;
    }
    this._fitCamera();

    this._bind(host, canvas);
    this._last = performance.now();
    const loop = (now) => {
      if(!this.open) return;
      const dt = Math.min(0.05, (now - this._last) / 1000 || 0.016);
      this._last = now;
      this.update(dt);
      this._raf = requestAnimationFrame(loop);
    };
    this._raf = requestAnimationFrame(loop);
  }

  _fitCamera(){
    const aspect = this.overlay ? Math.max(0.4, (this.overlay.querySelector('#previewCanvas').clientWidth || 640) / (this.overlay.querySelector('#previewCanvas').clientHeight || 420)) : 1;
    this.camera.aspect = aspect;
    this.camera.updateProjectionMatrix();
    this.dist = Math.max(1.5, this.radius * 2.25);
    this.targetDist = this.dist;
  }

  _bind(host, canvas){
    host.querySelector('#previewClose').onclick = () => this.close();
    host.addEventListener('pointerdown', e => { if(e.target === host) this.close(); });
    const auto = host.querySelector('#previewAuto');
    auto.onclick = () => { this.autoRotate = !this.autoRotate; auto.classList.toggle('on', this.autoRotate); };
    auto.classList.toggle('on', this.autoRotate);
    host.querySelector('#previewReset').onclick = () => {
      this.yaw = 0.65; this.pitch = 0.16; this._fitCamera();
    };

    let drag = null;
    const down = (e) => {
      drag = { x:e.clientX, y:e.clientY, id:e.pointerId };
      if(canvas.setPointerCapture){ try{ canvas.setPointerCapture(e.pointerId); }catch(err){} }
      this.autoRotate = false;
      auto.classList.remove('on');
    };
    const move = (e) => {
      if(!drag || e.pointerId !== drag.id) return;
      this.yaw -= (e.clientX - drag.x) * 0.008;
      this.pitch = clamp(this.pitch + (e.clientY - drag.y) * 0.006, -0.6, 1.1);
      drag.x = e.clientX; drag.y = e.clientY;
    };
    const up = (e) => { if(drag && e.pointerId === drag.id) drag = null; };
    canvas.addEventListener('pointerdown', down);
    canvas.addEventListener('pointermove', move);
    canvas.addEventListener('pointerup', up);
    canvas.addEventListener('pointercancel', up);
    canvas.addEventListener('pointerleave', up);
    canvas.addEventListener('wheel', (e) => {
      e.preventDefault();
      this.targetDist = clamp(this.targetDist + Math.sign(e.deltaY) * 0.25, this.radius * 1.05, this.radius * 5);
    }, { passive:false });
    const touches = new Map();
    canvas.addEventListener('touchstart', (e) => {
      for(const t of e.changedTouches) touches.set(t.identifier, { x:t.clientX, y:t.clientY });
      if(touches.size === 2){
        const [a,b] = [...touches.values()];
        this._pinch = { dist: Math.hypot(a.x-b.x, a.y-b.y), start: this.targetDist };
      }
    }, { passive:true });
    canvas.addEventListener('touchmove', (e) => {
      for(const t of e.changedTouches) if(touches.has(t.identifier)) touches.set(t.identifier, { x:t.clientX, y:t.clientY });
      if(touches.size === 2 && this._pinch){
        const [a,b] = [...touches.values()];
        const d = Math.hypot(a.x-b.x, a.y-b.y);
        this.targetDist = clamp(this._pinch.start * (this._pinch.dist / Math.max(1, d)), this.radius * 1.05, this.radius * 5);
        e.preventDefault();
      }
    }, { passive:false });
    const tend = (e) => { for(const t of e.changedTouches) touches.delete(t.identifier); if(touches.size < 2) this._pinch = null; };
    canvas.addEventListener('touchend', tend); canvas.addEventListener('touchcancel', tend);

    const ro = () => {
      if(!this.overlay) return;
      const cv = this.overlay.querySelector('#previewCanvas');
      const w = cv.clientWidth, h = cv.clientHeight;
      if(w && h && this.renderer){
        this.renderer.setSize(w, h, false);
        this.camera.aspect = w/h;
        this.camera.updateProjectionMatrix();
      }
    };
    window.addEventListener('resize', ro);
    this._onResize = ro;
    setTimeout(ro, 30);
  }

  update(dt){
    if(!this.open || !this.renderer) return;
    if(this.autoRotate) this.yaw += dt * 0.55;
    this.dist += (this.targetDist - this.dist) * Math.min(1, dt * 8);
    const cy = Math.cos(this.pitch);
    this.camera.position.set(
      Math.sin(this.yaw) * this.dist * cy,
      Math.sin(this.pitch) * this.dist + (this.modelHeight || 0) * 0.35,
      Math.cos(this.yaw) * this.dist * cy
    );
    this.camera.lookAt(0, (this.modelHeight || 0) * 0.18, 0);
    if(this.model && this.model.userData && this.model.userData.parts && this.model.userData.parts.mag){
      // idle micro-motion keeps the model feeling alive without breaking the silhouette
    }
    this.renderer.render(this.scene, this.camera);
  }

  close(){
    this.open = false;
    if(this._raf){ cancelAnimationFrame(this._raf); this._raf = 0; }
    if(this._onResize){ window.removeEventListener('resize', this._onResize); this._onResize = null; }
    if(this.renderer){
      try{ this.renderer.dispose(); }catch(e){}
      this.renderer = null;
    }
    if(this.overlay){ this.overlay.remove(); this.overlay = null; }
    if(this.model){
      this.model.traverse(o => { if(o.isMesh && o.material && o.material.dispose && !o.material.__shared) { /* gun cache materials are shared */ } });
      this.model = null;
    }
    this.scene = null;
    this.camera = null;
  }
}

function clamp(v, a, b){ return v < a ? a : (v > b ? b : v); }
function esc(s){
  return String(s == null ? '' : s).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
}
