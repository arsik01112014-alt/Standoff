// First-person player entity: movement, camera, recoil, loadout, health.
import * as THREE from '../../vendor/three.module.js';
import { WEAPONS } from '../data/weapons.js';
import { clamp } from '../core/utils.js';
import { hitSpheresAt } from '../game/combat.js';

const EYE_STAND = 1.62;
const EYE_CROUCH = 1.08;

export class Player {
  constructor(team, camera, name='YOU'){
    this.team = team;
    this.camera = camera;
    this.name = name;
    this.isPlayer = true;
    this.maxHealth = 100;
    this.onFootstep = null;
    this.onLand = null;
    this.cheatFly = false;
    this.cheatNoclip = false;
    this.godMode = false;
    this.cheatSpeed = 1;
    this.cheatJump = 1;
    this.reset(new THREE.Vector3(0,0,0), 0);
  }

  reset(pos, ang=0){
    this.x = pos.x; this.z = pos.z; this.y = 0;
    this.yaw = ang; this.pitch = 0; this.viewKick = 0;
    this.recoilPitch = 0; this.recoilYaw = 0;
    this.recoilVP = 0; this.recoilVY = 0;
    this.vy = 0; this.onGround = true; this.airborne = false;
    this.moveVelX = 0; this.moveVelZ = 0;
    this.crouch = false; this.walking = false;
    this.eyeH = EYE_STAND;
    this.alive = true;
    this.health = this.maxHealth;
    this.armor = 0;
    this.helmet = false;
    this.money = 800;
    this.kills = 0; this.deaths = 0; this.headshots = 0;
    this.loadout = { 1:null, 2:null, 3:{ id:'knife', ammo:Infinity, reserve:Infinity } };
    this.currentSlot = 3;
    this.grenades = { he:0, flash:0, smoke:0, molotov:0 };
    this.currentGrenade = 'he';
    this.pos = new THREE.Vector3();
    this.velocity = new THREE.Vector2();
    this._stepDist = 0;
    this._jumpCooldown = 0;
    this._landDip = 0;
    this._bobPhase = 0;
    this.frozen = false;
    this.aiming = false;
    this.running = false;
    this.sens = 1;
    this.invertY = false;
    this.deathT = 0;
    this.lastDamageDir = 0;
    this.damageFlash = 0;
  }

  getActiveWeapon(){
    if(this.currentSlot === 4){
      const kind = this.currentGrenade;
      if(this.grenades[kind] > 0){
        return { id:'grenade', grenade:kind, ammo:this.grenades[kind], reserve:0, def:null };
      }
      return null;
    }
    const slot = this.loadout[this.currentSlot];
    if(!slot) return null;
    const def = WEAPONS[slot.id];
    return { id: slot.id, def, ammo: slot.ammo, reserve: slot.reserve, slot: this.currentSlot };
  }

  hasSlot(slot){
    if(slot === 3) return true;
    if(slot === 4) return Object.values(this.grenades).some(v=>v>0);
    return !!this.loadout[slot];
  }

  switchSlot(slot){
    if(!this.alive) return false;
    if(slot === 4 && !this.hasSlot(4)) return false;
    if(slot !== 3 && slot !== 4 && !this.loadout[slot]) return false;
    this.currentSlot = slot;
    return true;
  }

  equipSlot(slot){
    const w = this.getActiveWeapon();
    if(w) this.currentSlot = slot;
  }

  giveWeapon(id){
    const def = WEAPONS[id];
    if(!def) return;
    if(def.type === 'grenade'){ this.grenades[id] = (this.grenades[id]||0) + 1; this.currentSlot = 4; this.currentGrenade = id; return; }
    const slot = def.slot;
    this.loadout[slot] = { id, ammo: def.mag, reserve: def.reserve };
    this.currentSlot = slot;
  }

  giveGrenade(kind, count=1){
    this.grenades[kind] = Math.min(4, (this.grenades[kind]||0) + count);
    this.currentSlot = 4;
    this.currentGrenade = kind;
  }

  refillAmmo(){
    for(const s of [1,2]){
      const slot = this.loadout[s];
      if(!slot) continue;
      const def = WEAPONS[slot.id];
      slot.ammo = def.mag;
      slot.reserve = def.reserve;
    }
  }

  applyLook(dx, dy, sens, zoomMul=1){
    const s = sens * 0.0022 * zoomMul;
    this.yaw -= dx * s;
    this.pitch -= dy * s * (this.invertY ? -1 : 1);
    this.pitch = clamp(this.pitch, -1.45, 1.45);
  }

  addRecoil(pitch, yaw){
    this.recoilVP += pitch * 34;
    this.recoilVY += yaw * 26;
    this.recoilPitch += pitch;
    this.recoilYaw += yaw;
    this.recoilPitch = clamp(this.recoilPitch, -0.5, 0.9);
    this.recoilYaw = clamp(this.recoilYaw, -0.5, 0.5);
  }

  getLookDir(out){
    const p = this.pitch + this.recoilPitch + this.viewKick;
    const y = this.yaw + this.recoilYaw;
    const cp = Math.cos(p);
    const v = out || new THREE.Vector3();
    v.set(-Math.sin(y)*cp, Math.sin(p), -Math.cos(y)*cp);
    return v;
  }

  getEyePos(out){
    const v = out || new THREE.Vector3();
    v.set(this.x, this.y + this.eyeH, this.z);
    return v;
  }

  getHitSpheres(){
    const drop = this.crouch ? -0.33 : 0;
    const scale = this.crouch ? 0.96 : 1;
    return hitSpheresAt(this.x, this.y + drop, this.z, scale);
  }

  update(dt, input, level){
    this.pos.set(this.x, this.y, this.z);
    if(!this.alive){
      this.velocity.set(0,0);
      this.deathT = Math.min(1, this.deathT + dt * 2.2);
      const eye = EYE_STAND - this.deathT * 1.15;
      this.camera.position.set(this.x, Math.max(0.28, this.y + eye), this.z);
      this.camera.rotation.order = 'YXZ';
      this.camera.rotation.y = this.yaw;
      this.camera.rotation.x = this.pitch + this.deathT * 0.28;
      this.camera.rotation.z = this.deathT * 0.35;
      return;
    }
    this.deathT = 0;
    if(input) this.applyLook(input.look.dx, input.look.dy, this.sens || 1);
    this.crouch = !!(input && input.crouch);

    // recoil recovery (fractional, frame-rate independent)
    const recover = Math.min(1, dt * 7.5);
    this.recoilVP *= Math.exp(-dt * 9);
    this.recoilVY *= Math.exp(-dt * 9);
    this.recoilPitch -= this.recoilPitch * recover;
    this.recoilYaw -= this.recoilYaw * recover;
    if(Math.abs(this.recoilPitch) < 0.0004) this.recoilPitch = 0;
    if(Math.abs(this.recoilYaw) < 0.0004) this.recoilYaw = 0;

    this.viewKick *= Math.exp(-dt*7);
    this._landDip *= Math.exp(-dt * 10);
    if(this.viewKick < 0.0005) this.viewKick = 0;

    const targetEye = this.crouch ? EYE_CROUCH : EYE_STAND;
    this.eyeH += (targetEye - this.eyeH) * Math.min(1, dt*13);

    // movement input, camera relative
    let ix = 0, iz = 0;
    if(input && !this.frozen){ ix = input.move.x; iz = input.move.y; }
    const mag = Math.hypot(ix, iz);
    if(mag > 1){ ix/=mag; iz/=mag; }
    const running = input && input.run && !this.crouch && mag > 0.1 && !this.frozen;
    const baseSpeed = this.crouch ? 2.65 : (running ? 7.25 : 5.25);
    const wpn = this.getActiveWeapon();
    let speedMul = (wpn && wpn.def) ? (wpn.def.speed || 1) : (this.currentSlot === 3 ? 1.1 : 1);
    if(this.aiming) speedMul *= 0.78;
    const speed = baseSpeed * speedMul * (this.cheatSpeed || 1);

    const cs = Math.cos(this.yaw), sn = Math.sin(this.yaw);
    const fwd = -iz, str = ix;
    let vx = (-sn)*fwd + (cs)*str;
    let vz = (-cs)*fwd + (-sn)*str;
    const vlen = Math.hypot(vx, vz);
    if(vlen > 1){ vx/=vlen; vz/=vlen; }
    vx *= speed; vz *= speed;

    const accel = this.onGround ? (mag > 0.01 ? 16 : 21) : 3.2;
    const k = Math.min(1, dt * accel);
    this.moveVelX += (vx - this.moveVelX) * k;
    this.moveVelZ += (vz - this.moveVelZ) * k;
    if(mag < 0.01 && this.onGround){
      this.moveVelX *= Math.exp(-dt*12);
      this.moveVelZ *= Math.exp(-dt*12);
    }

    const nx = this.x + this.moveVelX*dt;
    const nz = this.z + this.moveVelZ*dt;
    const r = 0.33;
    if(this.cheatFly || this.cheatNoclip){
      this.x = nx; this.z = nz;
      const ws = level.worldSize ? level.worldSize() : null;
      if(ws){ this.x = clamp(this.x, 0.5, ws.w - 0.5); this.z = clamp(this.z, 0.5, ws.h - 0.5); }
    } else {
      if(!level.isBlocked(nx, this.z, r)) this.x = nx; else this.moveVelX = 0;
      if(!level.isBlocked(this.x, nz, r)) this.z = nz; else this.moveVelZ = 0;
    }
    this.velocity.set(this.moveVelX, this.moveVelZ);

    // footsteps + bob
    const planarSpeed = Math.hypot(this.moveVelX, this.moveVelZ);
    if(this.onGround && planarSpeed > 0.4){
      this._bobPhase += dt * (running ? 13 : 9.5);
      const moved = planarSpeed * dt;
      this._stepDist += moved;
      const stride = running ? 2.05 : (this.crouch ? 3.4 : 2.7);
      if(this._stepDist > stride){
        this._stepDist = 0;
        if(this.onFootstep) this.onFootstep(running ? 1 : (this.crouch ? 0.28 : 0.6));
      }
    } else {
      this._bobPhase += dt * 1.4;
    }

    // jump / gravity (fly cheat replaces it with free vertical movement)
    this._jumpCooldown = Math.max(0, this._jumpCooldown - dt);
    if(this.cheatFly){
      const up = input && (input.jumpHeld || input.jumpPressed) ? 1 : 0;
      const down = this.crouch ? 1 : 0;
      this.y += (up - down) * 7.5 * dt;
      this.y = clamp(this.y, 0, 42);
      this.vy = 0;
      this.onGround = this.y <= 0.001;
    } else {
      if(input && input.jumpPressed && !this.frozen && this.onGround && !this.crouch && this._jumpCooldown <= 0){
        this.vy = 5.2 * (this.cheatJump || 1); this.onGround = false; this._jumpCooldown = 0.26;
      }
      this.vy -= 17*dt;
      this.y += this.vy*dt;
      if(this.y <= 0){
        if(!this.onGround && this.vy < -4.3){
          this._landDip = Math.min(0.085, -this.vy * 0.008);
          if(this.onLand) this.onLand(-this.vy);
        }
        this.y = 0; this.vy = 0; this.onGround = true;
      } else {
        this.onGround = false;
      }
    }
    this.airborne = !this.onGround;

    // camera: eye height + subtle walk bob, recoil and landing dip
    const bobAmt = this.onGround ? Math.min(1, planarSpeed / 6) : 0;
    const bobY = Math.abs(Math.sin(this._bobPhase)) * 0.035 * bobAmt;
    const bobX = Math.sin(this._bobPhase * 0.5) * 0.018 * bobAmt;
    this.camera.position.set(this.x + bobX, this.y + this.eyeH + bobY - this._landDip, this.z);
    this.camera.rotation.order = 'YXZ';
    this.camera.rotation.y = this.yaw + this.recoilYaw * 0.85;
    this.camera.rotation.x = this.pitch + this.recoilPitch + this.viewKick - this._landDip * 0.5;
    this.camera.rotation.z = 0;
    this.walking = planarSpeed > 0.5;
    this.running = running;
  }

  // armorLoss is produced by combat.computeDamage. When omitted (legacy/explosion)
  // a small amount of armor is consumed directly.
  takeDamage(amount, isHead, attacker, armorLoss, zone){
    if(!this.alive) return { killed:false, dmg:0, zone };
    if(this.godMode) return { killed:false, dmg:0, zone };
    const dmg = Math.max(0, amount);
    if(armorLoss === undefined){
      if(this.armor > 0){ this.armor = Math.max(0, this.armor - dmg * 0.35); }
    } else {
      this.armor = Math.max(0, this.armor - armorLoss);
    }
    this.health -= dmg;
    this.damageFlash = Math.min(1, this.damageFlash + dmg / 45);
    if(attacker && attacker !== this){
      const ax = attacker.pos ? attacker.pos.x : attacker.x;
      const az = attacker.pos ? attacker.pos.z : attacker.z;
      this.lastDamageDir = Math.atan2(ax - this.x, az - this.z);
      this.lastAttacker = attacker;
    }
    const killed = this.health <= 0;
    if(killed){
      this.alive = false;
      this.health = 0;
      this.deaths++;
      this.deathT = 0;
    }
    return { killed, dmg, zone };
  }
}
