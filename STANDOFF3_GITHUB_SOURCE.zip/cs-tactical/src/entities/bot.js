// Tactical bot AI with human-ish perception, memory, cover and teamwork.
// Design rules: bots only react to things they can see or hear, their first
// shots are deliberately inaccurate, and every difficulty has real weaknesses.
import * as THREE from '../../vendor/three.module.js';
import { createCharacter } from '../world/characters.js';
import { WEAPONS } from '../data/weapons.js';
import { getDifficulty } from '../data/difficulty.js';
import { findPath } from '../game/pathfinding.js';
import { clamp, angleDiff } from '../core/utils.js';
import { hitSpheresAt } from '../game/combat.js';

const BOT_NAMES = ['Viper','Ghost','Rook','Falcon','Nomad','Snake','Wolf','Raven','Tango','Echo','Reaper','Sable','Mako','Onyx','Vandal','Wraith','Havoc','Zulu','Bravo','Kilo'];
const ROLES = ['entry','support','anchor','lurker'];

export class Bot {
  constructor(opts){
    this.team = opts.team;
    this.name = opts.name || BOT_NAMES[Math.floor(Math.random()*BOT_NAMES.length)];
    this.level = opts.level;
    this.match = opts.match;
    this.profile = getDifficulty(opts.difficulty || (opts.match && opts.match.difficulty) || 'normal');
    this.skill = opts.skill !== undefined ? opts.skill : this.profile.skill;
    this.radius = 0.36;
    this.eye = 1.6;
    this.maxHealth = 100;
    this.alive = true;
    this.isPlayer = false;
    this.role = ROLES[Math.floor(Math.random()*ROLES.length)];

    this.agentId = opts.agentId || null;
    const ch = createCharacter(this.team, opts.weaponId || 'ak47', null, this.agentId);
    this.agentId = ch.agentId;
    this.char = ch;
    this.root = ch.root;
    this.level.scene.add(this.root);

    this.pos = new THREE.Vector3();
    this.yaw = 0; this.aimYaw = 0; this.aimPitch = 0;
    this.health = 100; this.armor = 0; this.helmet = false;
    this.money = 800;
    this.kills = 0; this.deaths = 0; this.headshots = 0;

    this.state = 'advance';
    this.target = null;
    this.lastKnown = null;
    this.lastSeenAge = 99;
    this.reactionTimer = 0;
    this.acquire = 0;
    this.alertX = 0; this.alertZ = 0; this.alertAge = 99;
    this.path = [];
    this.pathIndex = 0;
    this.repathTimer = 0;
    this.thinkTimer = Math.random()*0.2;
    this.shootTimer = 0;
    this.burstLeft = 0;
    this.burstTimer = 0;
    this.reloadTimer = 0;
    this.reloading = false;
    this.strafeDir = Math.random() < 0.5 ? 1 : -1;
    this.strafeTimer = 0;
    this.objective = null;
    this.coverPoint = null;
    this.coverTimer = 0;
    this.deadT = 0;
    this.blind = 0;
    this.melee = false;
    this._lastPos = new THREE.Vector2();
    this._stuckCheck = 0;
    this._stuckCount = 0;
    this._aimOffX = 0; this._aimOffY = 0;
    this._thinkInterval = 0.24 - this.profile.skill * 0.09;
    this._stepDist = 0;
    this._scanTimer = 0;
    this._scanBase = null;
    this._scanTime = 0;
    this._scanPhase = Math.random()*6.283;
    this._routeTarget = null;
    this._routeRound = -1;
    this._lastShotAge = 99;
    this._lostShots = 0;
    this._calloutTimer = 0;
    this._prevAnimYaw = 0;
    this.crouching = false;
    this.suppressed = 0;

    this.weaponId = opts.weaponId || 'ak47';
    this.setWeapon(this.weaponId);
  }

  setWeapon(id){
    this.weaponId = id;
    const def = WEAPONS[id] || WEAPONS.ak47;
    this.weapon = def;
    this.ammo = def.mag;
    this.reserve = def.reserve;
    this.reloading = false;
    this.reloadTimer = 0;
    this.burstLeft = 0;
    if(this.char) this.char.setWeapon(id, this.match ? this.match.botSkin(id) : null);
  }

  spawnAt(x, z, ang=0){
    this.pos.set(x, 0, z);
    this.yaw = ang; this.aimYaw = ang; this.aimPitch = 0;
    this.health = this.maxHealth;
    this.alive = true;
    this.blind = 0;
    this.state = 'advance';
    this.target = null;
    this.lastKnown = null;
    this.lastSeenAge = 99;
    this.alertAge = 99;
    this.path = []; this.pathIndex = 0;
    this.deathDone = false;
    this.deadT = 0;
    this.repathTimer = 0;
    this.reactionTimer = 0;
    this.reloading = false;
    this.coverPoint = null;
    this.coverTimer = 0;
    this.burstLeft = 0;
    this.burstTimer = 0;
    this.ammo = this.weapon.mag;
    this.reserve = this.weapon.reserve;
    this._stuckCount = 0;
    this._stuckCheck = 0;
    this._lastPos.set(x, z);
    this.root.visible = true;
    this.root.position.set(x, 0, z);
    this.root.rotation.set(0, ang, 0);
    this.root.rotation.order = 'YXZ';
    this.char.root.rotation.z = 0;
    this.char.root.position.y = 0;
    this.char.animate(0, 0, 0, false);
  }

  getEyePos(out){
    const v = out || new THREE.Vector3();
    v.set(this.pos.x, this.pos.y + this.eye - (this.crouching ? 0.4 : 0), this.pos.z);
    return v;
  }

  getHitSpheres(){
    return hitSpheresAt(this.pos.x, this.pos.y, this.pos.z, 1, this.crouching ? 0.74 : 1);
  }

  takeDamage(amount, isHead, attacker, armorLoss, zone){
    if(!this.alive) return { killed:false, dmg:0, zone };
    const dmg = Math.max(0, amount);
    if(armorLoss === undefined){
      if(this.armor > 0) this.armor = Math.max(0, this.armor - dmg * 0.4);
    } else {
      this.armor = Math.max(0, this.armor - armorLoss);
    }
    this.health -= dmg;
    this.suppressed = Math.max(this.suppressed || 0, 2.4);
    // Being hit gives a rough direction, not perfect knowledge.
    if(attacker && attacker !== this && Math.random() < 0.55 + this.profile.skill * 0.45){
      const ax = attacker.pos ? attacker.pos.x : attacker.x;
      const az = attacker.pos ? attacker.pos.z : attacker.z;
      this.alertX = ax; this.alertZ = az; this.alertAge = 0;
      if(this.state !== 'combat') this.state = 'search';
      this.reactionTimer = Math.min(this.reactionTimer, this.profile.reaction[0] * 0.8);
      this._aimOffX += (Math.random()-0.5) * this.profile.aimError * 2;
    }
    const killed = this.health <= 0;
    if(killed){
      this.alive = false; this.health = 0;
      this.state = 'dead';
      this.deadT = 0;
      this.deaths++;
      this.target = null;
    }
    return { killed, dmg, zone };
  }

  update(dt, world){
    if(!this.alive){
      this.deadT += dt;
      this.char.animate(dt, 0, 0, true);
      this.root.position.set(this.pos.x, 0, this.pos.z);
      return;
    }
    if(this.frozen){
      this.char.animate(dt, 0, 0, false);
      this.root.position.set(this.pos.x, 0, this.pos.z);
      this.root.rotation.y = this.yaw;
      return;
    }
    if(this.blind > 0){
      this.blind = Math.max(0, this.blind - dt);
      if(this.blind > 0.05){
        this.target = null;
        this.state = 'search';
      }
    }

    this.thinkTimer -= dt;
    this.shootTimer -= dt;
    this.burstTimer -= dt;
    this.repathTimer -= dt;
    this.reactionTimer -= dt;
    this.strafeTimer -= dt;
    this.coverTimer -= dt;
    this.lastSeenAge += dt;
    this.alertAge += dt;
    this._lastShotAge += dt;
    this._calloutTimer -= dt;
    this.suppressed = Math.max(0, this.suppressed - dt);

    if(this.reloading){
      this.reloadTimer -= dt;
      if(this.reloadTimer <= 0){
        const need = this.weapon.mag - this.ammo;
        const take = Math.min(need, this.reserve);
        this.ammo += take;
        this.reserve -= take;
        this.reloading = false;
        if(this.state === 'reload') this.state = this.target ? 'combat' : 'advance';
      }
    }

    if(this.thinkTimer <= 0){
      this.thinkTimer = this._thinkInterval + Math.random()*0.08;
      this._think(world);
    }

    this.crouching = false;

    this._move(dt, world);
    this._aim(dt);
    this._updateShooting(dt, world);

    const spd = Math.hypot(this.velX || 0, this.velZ || 0);
    let dist = 999;
    if(world.player) dist = Math.hypot(this.pos.x - world.player.x, this.pos.z - world.player.z);
    const turn = dt > 0 ? clamp(angleDiff(this._prevAnimYaw, this.yaw) / (dt * 6), -1, 1) : 0;
    this._prevAnimYaw = this.yaw;
    this.char.animate(dt, spd, this.aimPitch, false, dist, {
      crouch: this.crouching,
      air: this.pos.y > 0.12,
      turn
    });
    this.root.position.set(this.pos.x, this.pos.y, this.pos.z);
    this.root.rotation.y = this.yaw;

    // footsteps give the player a fair audio cue
    if(spd > 0.5 && this.onGround !== false){
      this._stepDist += spd * dt;
      if(this._stepDist > 2.6){
        this._stepDist = 0;
        if(world.onBotFootstep) world.onBotFootstep(this, spd > 5.5);
      }
    }
  }

  // ---------------- perception ----------------
  _think(world){
    if(this.blind > 0.05) { this.target = null; return; }
    const enemies = world.getEnemies(this);
    let best = null, bestScore = Infinity;
    const eye = this.getEyePos(new THREE.Vector3());
    const halfFov = Math.cos((this.profile.fov * Math.PI / 180) / 2);

    for(const e of enemies){
      if(!e.alive) continue;
      if(!e.pos && e.x === undefined) continue;
      const ex = e.pos ? e.pos.x : e.x;
      const ez = e.pos ? e.pos.z : e.z;
      const d = Math.hypot(ex - this.pos.x, ez - this.pos.z);
      if(d > this.profile.sightRange) continue;
      const dx = ex - this.pos.x, dz = ez - this.pos.z;
      const len = Math.hypot(dx,dz) || 1;
      const facing = (-Math.sin(this.yaw) * dx + -Math.cos(this.yaw) * dz) / len;
      const isTarget = e === this.target;
      if(facing < halfFov && !isTarget) continue;
      if(!this._canSee(e, world)) continue;
      // closer targets are prioritized; current target gets sticky bias
      let score = d;
      if(isTarget) score -= 6;
      if(e.isPlayer) score -= 1.5;
      if(score < bestScore){ bestScore = score; best = e; }
    }

    if(best){
      if(best !== this.target){
        this.reactionTimer = this.profile.reaction[0] + Math.random()*(this.profile.reaction[1]-this.profile.reaction[0]);
        this.acquire = 0;
        this._aimOffX = (Math.random()-0.5) * this.profile.aimError * 2.4;
        this._aimOffY = (Math.random()-0.5) * this.profile.aimError * 1.6;
      }
      this.target = best;
      this.lastKnown = { x: best.pos ? best.pos.x : best.x, z: best.pos ? best.pos.z : best.z, t: 0, enemy: best };
      this.lastSeenAge = 0;
      this.state = 'combat';
      this._scanBase = null;
      this.acquire = Math.min(1, this.acquire + this._thinkInterval * (1.4 + this.profile.skill));
      this._maybeCallout(world, best);
    } else {
      if(this.target && this.lastSeenAge > this.profile.memory * 0.55){
        this.target = null;
        this.state = 'search';
      }
      if(this.state === 'combat' && this.lastSeenAge > this.profile.memory){
        this.state = this.lastKnown ? 'search' : 'advance';
      }
    }
  }

  _maybeCallout(world, enemy){
    if(!world.alertTeam) return;
    if(this._calloutTimer > 0) return;
    if(Math.random() > this.profile.teamwork) return;
    this._calloutTimer = 2.2;
    const ex = enemy.pos ? enemy.pos.x : enemy.x;
    const ez = enemy.pos ? enemy.pos.z : enemy.z;
    world.alertTeam(this, ex, ez);
  }

  _canSee(e, world){
    const a = this.getEyePos(new THREE.Vector3());
    const b = e.getEyePos ? e.getEyePos(new THREE.Vector3()) : new THREE.Vector3(e.pos ? e.pos.x : e.x, 1.55, e.pos ? e.pos.z : e.z);
    if(!world.level.lineOfSight(a.x,a.y,a.z,b.x,b.y,b.z)) return false;
    if(world.effects && world.effects.isSmokeBlocked(a.x,a.z,b.x,b.z)) return false;
    return true;
  }

  hearGunshot(x, z, loudness=1){
    if(!this.alive) return;
    const d = Math.hypot(x - this.pos.x, z - this.pos.z);
    if(d > this.profile.hearing * loudness) return;
    // Hearing gives a general area, never an exact lock.
    const jitter = d * 0.18;
    this.alertX = x + (Math.random()-0.5)*jitter;
    this.alertZ = z + (Math.random()-0.5)*jitter;
    this.alertAge = 0;
    if(!this.target && this.state !== 'reload'){
      this.state = 'search';
      this.repathTimer = 0;
    }
  }

  // ---------------- movement ----------------
  _move(dt, world){
    const level = world.level;
    this.velX = 0; this.velZ = 0;
    const prof = this.profile;
    let speed = (this.weapon.type === 'sniper' ? 3.15 : 4.2) * prof.moveSpeed * (this.reloading ? 0.82 : 1);
    const combat = this.state === 'combat' && this.target && this.target.alive;

    if(combat){
      const tp = this.target.pos || { x:this.target.x, z:this.target.z };
      const dx = tp.x - this.pos.x, dz = tp.z - this.pos.z;
      const d = Math.hypot(dx,dz) || 0.001;
      const pref = this.weapon.type === 'sniper' ? 15 : (this.weapon.type === 'shotgun' ? 4.5 : (this.weapon.type === 'smg' ? 9 : 11));
      let mx = 0, mz = 0;
      if(d > pref + 3.5){ mx = dx/d; mz = dz/d; }
      else if(d < pref - 3){ mx = -dx/d; mz = -dz/d; }

      // seek cover when hurt, suppressed or reloading
      if((this.health < 58 || this.reloading || this.suppressed > 0) && this.coverTimer <= 0 && prof.coverUse > 0.2 && world.findCover){
        this.coverPoint = world.findCover(this, this.target);
        this.coverTimer = 2.4 + Math.random()*2;
      }
      if(this.coverPoint && (this.health < 70 || this.reloading || this.suppressed > 0)){
        const cx = this.coverPoint.x - this.pos.x, cz = this.coverPoint.z - this.pos.z;
        const cd = Math.hypot(cx,cz);
        if(cd < 0.6){ this.coverPoint = null; }
        else { mx = cx/cd; mz = cz/cd; }
      } else if(this.coverPoint){
        this.coverPoint = null;
      }

      // crouch behind cover or while reloading in a firefight; stand up when
      // the threat or cover situation changes.
      const coverDist = this.coverPoint ? Math.hypot(this.coverPoint.x - this.pos.x, this.coverPoint.z - this.pos.z) : 999;
      this.crouching = coverDist < 2.2 || (this.reloading && this._lastShotAge < 2.2);
      if(this.crouching) speed *= 0.58;

      // strafing, scaled by difficulty
      if(this.strafeTimer <= 0){
        this.strafeDir *= Math.random() < 0.72 ? -1 : 1;
        this.strafeTimer = 0.5 + Math.random() * (1.5 - prof.strafe);
      }
      mx += (-dz/d) * this.strafeDir * prof.strafe;
      mz += (dx/d) * this.strafeDir * prof.strafe;
      const ml = Math.hypot(mx,mz) || 1;
      this._tryMove(level, (mx/ml)*speed*0.86*dt, (mz/ml)*speed*0.86*dt, world, dt);
      this._stuckTick(dt);
      return;
    }

    // pick an objective / investigate point
    let goal = null;
    if(this.state === 'search'){
      if(this.lastKnown && this.lastSeenAge < prof.memory * 2.6){
        goal = { x:this.lastKnown.x, z:this.lastKnown.z };
      } else if(this.alertAge < 4.5){
        goal = { x:this.alertX, z:this.alertZ };
      } else {
        this.state = 'advance';
        this.lastKnown = null;
      }
    }
    if(!goal){
      if(!this.objective) this.objective = world.getObjective(this);
      if(this.objective && Math.hypot(this.objective.x-this.pos.x, this.objective.z-this.pos.z) < 2.2){
        // hold the angle, scan, then rotate a little
        this.state = 'hold';
        this.objective = null;
        this.repathTimer = 2.5 + Math.random()*2;
      }
      if(this.state === 'hold' && this.repathTimer <= 0){
        this.objective = world.getObjective(this);
        this.state = 'advance';
      }
      goal = this.objective;
    }
    if(goal){
      if(this.repathTimer <= 0 || this.path.length === 0){
        this.repathTimer = 1.05 + Math.random()*0.75;
        const p = findPath(level.map, this.pos.x, this.pos.z, goal.x, goal.z);
        if(p.length){ this.path = p; this.pathIndex = 0; }
        else { this.path = []; }
      }
      if(this.path.length && this.pathIndex < this.path.length){
        const wp = this.path[this.pathIndex];
        const dx = wp.x - this.pos.x, dz = wp.z - this.pos.z;
        const d = Math.hypot(dx,dz);
        if(d < 1.15){ this.pathIndex++; }
        else {
          this._tryMove(level, (dx/d)*speed*dt, (dz/d)*speed*dt, world, dt);
        }
      }
    }

    this._stuckTick(dt);
  }

  _stuckTick(dt){
    this._stuckCheck += dt;
    if(this._stuckCheck < 0.9) return;
    const moved = Math.hypot(this.pos.x - this._lastPos.x, this.pos.z - this._lastPos.y);
    if(moved < 0.22 && (this.path.length || this.state === 'combat')){
      this._stuckCount++;
      this.path = [];
      this.repathTimer = 0;
      this.strafeDir *= -1;
      this.strafeTimer = 0.35;
      // sidestep out of corners
      this.pos.x += (Math.random()-0.5)*0.05;
      this.pos.z += (Math.random()-0.5)*0.05;
    } else {
      this._stuckCount = 0;
    }
    this._lastPos.set(this.pos.x, this.pos.z);
    this._stuckCheck = 0;
  }

  _tryMove(level, dx, dz, world, dt){
    const step = Math.max(dt || 0.016, 0.0001);
    const r = this.radius;
    // separation from allies so the team doesn't clump
    if(world && world.getAllies){
      const allies = world.getAllies(this);
      for(const a of allies){
        if(a === this || !a.alive) continue;
        const ax = a.pos.x - this.pos.x, az = a.pos.z - this.pos.z;
        const d = Math.hypot(ax,az);
        if(d > 0.001 && d < 1.05){
          dx -= ax/d * (1.05-d) * 0.55;
          dz -= az/d * (1.05-d) * 0.55;
        }
      }
    }
    const ox = this.pos.x, oz = this.pos.z;
    if(!level.isBlocked(this.pos.x + dx, this.pos.z, r)) this.pos.x += dx;
    if(!level.isBlocked(this.pos.x, this.pos.z + dz, r)) this.pos.z += dz;
    this.velX = (this.pos.x - ox) / step;
    this.velZ = (this.pos.z - oz) / step;
    const ws = level.worldSize();
    this.pos.x = clamp(this.pos.x, 0.5, ws.w-0.5);
    this.pos.z = clamp(this.pos.z, 0.5, ws.h-0.5);
  }

  // ---------------- aiming + shooting ----------------
  _aim(dt){
    const target = this.target;
    if(target && target.alive){
      const tEye = target.getEyePos ? target.getEyePos(new THREE.Vector3()) : new THREE.Vector3(target.pos ? target.pos.x : target.x, 1.55, target.pos ? target.pos.z : target.z);
      const dx = tEye.x - this.pos.x, dz = tEye.z - this.pos.z;
      const hd = Math.hypot(dx,dz) || 0.001;
      const desiredYaw = Math.atan2(-dx, -dz);
      // aim at chest by default; better bots occasionally snap to the head
      const headBias = this.profile.headBias * (target.isPlayer ? 1.0 : 0.8);
      const aimY = tEye.y - (Math.random() < headBias ? 0 : 0.25);
      const desiredPitch = Math.atan2(aimY - (this.pos.y + this.eye), hd);

      // error shrinks the longer the target is tracked and grows with range
      const settle = 1 - Math.min(0.82, this.acquire * (0.55 + this.profile.skill*0.45));
      const distMul = 1 + Math.min(0.9, hd / 55);
      const moveMul = this.velX || this.velZ ? 1.22 : 1;
      const err = this.profile.aimError * settle * distMul * moveMul;
      this._aimOffX += (Math.random()-0.5) * err * 0.55;
      this._aimOffY += (Math.random()-0.5) * err * 0.4;
      this._aimOffX = clamp(this._aimOffX, -err*1.6, err*1.6);
      this._aimOffY = clamp(this._aimOffY, -err*1.2, err*1.2);

      const turn = Math.min(1, dt * (4.5 + this.profile.skill * 14));
      this.aimYaw += angleDiff(this.aimYaw, desiredYaw + this._aimOffX) * turn;
      this.aimPitch += (desiredPitch + this._aimOffY - this.aimPitch) * turn;
      this.yaw = this.aimYaw;
    } else {
      this.aimPitch += (0 - this.aimPitch) * Math.min(1, dt*3);
      const moving = Math.hypot(this.velX || 0, this.velZ || 0) > 0.45;
      if(moving){
        // Keep the body/head pointed where the bot is actually walking.
        // Previously advance/search used to leave the old combat yaw frozen,
        // so bots appeared to walk sideways or stare at random walls.
        const desiredYaw = Math.atan2(-(this.velX || 0), -(this.velZ || 0));
        this.aimYaw += angleDiff(this.aimYaw, desiredYaw) * Math.min(1, dt*3.4);
        this.yaw = this.aimYaw;
        this._scanBase = null;
      } else if(this.state === 'hold'){
        if(this._scanBase === null) this._scanBase = this.yaw;
        this._scanTime += dt;
        const scan = this._scanBase + Math.sin(this._scanTime*0.72 + this._scanPhase) * 0.62;
        this.aimYaw += angleDiff(this.aimYaw, scan) * Math.min(1, dt*2.4);
        this.yaw = this.aimYaw;
      } else {
        this.yaw = this.aimYaw;
      }
    }
  }

  _updateShooting(dt, world){
    const target = this.target;
    if(!target || !target.alive){
      this._lostShots = 0;
      return;
    }
    if(this.blind > 0.05) return;
    if(this.reactionTimer > 0) return;
    if(this.reloading) return;
    if(this.ammo <= 0){ this._startReload(world); return; }
    if(this.burstTimer > 0) return;

    // never fire through geometry or smoke
    if(!this._canSee(target, world)) return;

    const tEye = target.getEyePos ? target.getEyePos(new THREE.Vector3()) : new THREE.Vector3(target.pos ? target.pos.x : target.x, 1.55, target.pos ? target.pos.z : target.z);
    const dx = tEye.x - this.pos.x, dy = tEye.y - (this.pos.y + this.eye), dz = tEye.z - this.pos.z;
    const hd = Math.hypot(dx,dz) || 0.001;
    const dist = hd;
    if(dist > (this.weapon.range || 60) * 1.05) return;

    if(this.shootTimer <= 0){
      const def = this.weapon;
      const semi = !def.auto;
      const burstSize = semi ? 1 : (this.profile.burst[0] + Math.floor(Math.random()*(this.profile.burst[1]-this.profile.burst[0]+1)));
      if(this.burstLeft <= 0) this.burstLeft = burstSize;

      // Aim error at the moment of the shot. It is intentionally bounded so
      // even expert bots can miss moving targets.
      const errScale = this.profile.aimError * this.profile.spreadMul * (1 + dist * 0.012) * (1 + (this.velX||this.velZ ? 0.35 : 0));
      const yawErr = (Math.random()-0.5) * errScale * 2 + this._aimOffX * 0.35;
      const pitchErr = (Math.random()-0.5) * errScale * 1.5 + this._aimOffY * 0.3;
      const yaw = Math.atan2(-dx, -dz) + yawErr;
      const pitch = Math.atan2(dy, hd) + pitchErr;
      const dir = new THREE.Vector3(-Math.sin(yaw)*Math.cos(pitch), Math.sin(pitch), -Math.cos(yaw)*Math.cos(pitch)).normalize();
      const origin = this.getEyePos(new THREE.Vector3());
      // small muzzle offset so tracers do not start inside the head
      origin.addScaledVector(dir, 0.15);

      this.ammo--;
      this.shootTimer = def.fireDelay/1000 * (0.92 + Math.random()*0.18);
      this.burstLeft--;
      this._lastShotAge = 0;
      world.botShoot(this, origin, dir, def, { damageMul: this.profile.damageMul, difficulty: this.profile.id });
      if(world.onBotShot) world.onBotShot(this);

      if(semi){
        this.burstTimer = this.profile.burstPause[0] * (0.7 + Math.random()*0.6);
      } else if(this.burstLeft <= 0){
        this.burstTimer = this.profile.burstPause[0] + Math.random()*(this.profile.burstPause[1]-this.profile.burstPause[0]);
        this.burstLeft = 0;
        // small reposition between bursts on higher difficulty
        if(this.profile.peek > 0.5 && Math.random() < 0.4){
          this.strafeDir *= -1;
          this.strafeTimer = 0.3 + Math.random()*0.4;
        }
      }
      if(this.ammo <= 0 && this.reserve > 0) this._startReload(world);
    }
  }

  _startReload(world){
    if(this.reloading) return;
    if(this.reserve <= 0) return;
    this.reloading = true;
    this.reloadTimer = this.weapon.reloadTime/1000 * (0.94 + Math.random()*0.12);
    if(this.state === 'combat') this.state = 'reload';
    if(this.coverTimer <= 0 && this.profile.coverUse > 0.3 && world.findCover && this.target){
      this.coverPoint = world.findCover(this, this.target);
      this.coverTimer = 3;
    }
    if(world.onReload) world.onReload(this);
  }
}
