// Builds the 3D level from procedural map data, plus environment + helpers.
import * as THREE from '../../vendor/three.module.js';
import { isSolid } from '../data/maps.js';
import { raycastWorld, lineOfSight } from './raycast.js';

function canvasTex(size, draw, repeat){
  const c = document.createElement('canvas');
  c.width = size; c.height = size;
  const g = c.getContext('2d');
  draw(g, size);
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  if(repeat) tex.repeat.set(repeat, repeat);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  return tex;
}

function groundTexture(theme){
  const base = { city:'#4a4d50', industrial:'#3a3d40', desert:'#b08850', harbor:'#39444a', office:'#434a51', dust:'#a47c4c', metro:'#2b3238', villa:'#4c5048' }[theme] || '#444';
  return canvasTex(256, (g,s)=>{
    g.fillStyle = base; g.fillRect(0,0,s,s);
    // large tonal patches
    for(let i=0;i<26;i++){
      const v = 20 + Math.random()*60;
      g.fillStyle = `rgba(${v},${v},${v},${0.04+Math.random()*0.07})`;
      const w = 18+Math.random()*70, h = 18+Math.random()*70;
      g.fillRect(Math.random()*s, Math.random()*s, w, h);
    }
    // fine grain
    for(let i=0;i<1500;i++){
      const v = 30 + Math.random()*50;
      g.fillStyle = `rgba(${v},${v},${v},${0.04+Math.random()*0.09})`;
      const r = 1+Math.random()*3;
      g.fillRect(Math.random()*s, Math.random()*s, r, r);
    }
    if(theme === 'city'){
      g.strokeStyle = 'rgba(210,210,210,.20)'; g.lineWidth = 3;
      g.strokeRect(0,0,s,s);
      g.beginPath(); g.moveTo(0,s/2); g.lineTo(s,s/2); g.stroke();
      g.strokeStyle = 'rgba(255,220,120,.16)'; g.lineWidth = 2;
      g.beginPath(); g.moveTo(0,s/2-6); g.lineTo(s,s/2-6); g.stroke();
      // cracks
      g.strokeStyle = 'rgba(0,0,0,.22)'; g.lineWidth = 1;
      for(let i=0;i<7;i++){
        let x=Math.random()*s, y=Math.random()*s;
        g.beginPath(); g.moveTo(x,y);
        for(let k=0;k<5;k++){ x+=(Math.random()-0.5)*22; y+=(Math.random()-0.5)*22; g.lineTo(x,y); }
        g.stroke();
      }
    } else if(theme === 'harbor'){
      g.strokeStyle = 'rgba(20,26,30,.42)'; g.lineWidth = 3;
      for(let i=0;i<6;i++){ g.beginPath(); g.moveTo(0,i*44); g.lineTo(s,i*44); g.stroke(); }
      g.fillStyle = 'rgba(40,150,170,.10)';
      for(let i=0;i<12;i++){ g.beginPath(); g.ellipse(Math.random()*s, Math.random()*s, 10+Math.random()*30, 4+Math.random()*12, Math.random()*3, 0, 6.283); g.fill(); }
      g.fillStyle = 'rgba(220,180,70,.18)';
      for(let i=0;i<8;i++) g.fillRect(Math.random()*s, Math.random()*s, 24+Math.random()*40, 4);
    } else if(theme === 'office'){
      g.strokeStyle = 'rgba(0,0,0,.16)'; g.lineWidth = 1;
      for(let i=0;i<8;i++){ g.beginPath(); g.moveTo(0,i*32); g.lineTo(s,i*32); g.moveTo(i*32,0); g.lineTo(i*32,s); g.stroke(); }
      g.fillStyle = 'rgba(120,150,160,.08)';
      for(let i=0;i<10;i++) g.fillRect(Math.random()*s, Math.random()*s, 20+Math.random()*50, 12+Math.random()*30);
    } else if(theme === 'industrial'){
      g.strokeStyle = 'rgba(20,20,20,.38)'; g.lineWidth = 2;
      for(let i=0;i<4;i++){ g.beginPath(); g.moveTo(0,i*64); g.lineTo(s,i*64); g.stroke(); }
      g.fillStyle = 'rgba(200,140,40,.10)';
      for(let i=0;i<6;i++) g.fillRect(Math.random()*s, Math.random()*s, 30+Math.random()*50, 6+Math.random()*10);
      g.fillStyle = 'rgba(0,0,0,.18)';
      for(let i=0;i<12;i++){ g.beginPath(); g.ellipse(Math.random()*s, Math.random()*s, 8+Math.random()*20, 4+Math.random()*10, Math.random()*3, 0, 6.283); g.fill(); }
    } else {
      g.fillStyle = 'rgba(120,90,50,.14)';
      for(let i=0;i<24;i++){ g.beginPath(); g.arc(Math.random()*s, Math.random()*s, 5+Math.random()*22, 0, 6.283); g.fill(); }
      // wind ripples
      g.strokeStyle = 'rgba(255,235,190,.10)'; g.lineWidth = 2;
      for(let i=0;i<8;i++){
        const y = Math.random()*s;
        g.beginPath(); g.moveTo(0,y);
        for(let x=0;x<=s;x+=8) g.lineTo(x, y + Math.sin(x*0.08+i)*4);
        g.stroke();
      }
    }
  }, 8);
}

function wallTexture(theme){
  return canvasTex(128, (g,s)=>{
    const col = { city:'#8b8f93', industrial:'#6c7278', desert:'#c8a878', harbor:'#68747c', office:'#9aa4ae', dust:'#c0a070', metro:'#5c6a72', villa:'#d8cfb8' }[theme] || '#888';
    g.fillStyle = col; g.fillRect(0,0,s,s);
    if(theme === 'desert' || theme === 'dust'){
      for(let y=0;y<s;y+=16){
        for(let x=0;x<s;x+=24){
          const off = (y/16)%2 ? 12 : 0;
          g.fillStyle = `rgba(90,60,30,${0.08+Math.random()*0.06})`;
          g.fillRect(x+off, y, 22, 14);
        }
      }
      g.fillStyle = 'rgba(60,40,20,.25)';
      for(let i=0;i<40;i++) g.fillRect(Math.random()*s, Math.random()*s, 2+Math.random()*4, 2);
      // small windows + shutters
      for(let i=0;i<2;i++){
        const x = 14 + i*62, y = 34;
        g.fillStyle = 'rgba(25,18,10,.75)'; g.fillRect(x, y, 22, 28);
        g.fillStyle = 'rgba(120,80,40,.9)'; g.fillRect(x-4, y, 5, 28); g.fillRect(x+21, y, 5, 28);
      }
    } else if(theme === 'harbor'){
      g.strokeStyle = 'rgba(20,26,30,.42)'; g.lineWidth = 3;
      for(let i=0;i<6;i++){ g.beginPath(); g.moveTo(0,i*44); g.lineTo(s,i*44); g.stroke(); }
      g.fillStyle = 'rgba(40,150,170,.10)';
      for(let i=0;i<12;i++){ g.beginPath(); g.ellipse(Math.random()*s, Math.random()*s, 10+Math.random()*30, 4+Math.random()*12, Math.random()*3, 0, 6.283); g.fill(); }
      g.fillStyle = 'rgba(220,180,70,.18)';
      for(let i=0;i<8;i++) g.fillRect(Math.random()*s, Math.random()*s, 24+Math.random()*40, 4);
    } else if(theme === 'office'){
      g.strokeStyle = 'rgba(0,0,0,.16)'; g.lineWidth = 1;
      for(let i=0;i<8;i++){ g.beginPath(); g.moveTo(0,i*32); g.lineTo(s,i*32); g.moveTo(i*32,0); g.lineTo(i*32,s); g.stroke(); }
      g.fillStyle = 'rgba(120,150,160,.08)';
      for(let i=0;i<10;i++) g.fillRect(Math.random()*s, Math.random()*s, 20+Math.random()*50, 12+Math.random()*30);
    } else if(theme === 'harbor'){
      for(let x=0;x<s;x+=14){
        g.fillStyle = x%28 ? 'rgba(255,255,255,.045)' : 'rgba(0,0,0,.16)';
        g.fillRect(x,0,7,s);
      }
      g.fillStyle = 'rgba(120,60,30,.18)';
      for(let i=0;i<9;i++){ g.beginPath(); g.ellipse(Math.random()*s, Math.random()*s, 4+Math.random()*14, 3+Math.random()*9, Math.random()*3, 0, 6.283); g.fill(); }
      g.fillStyle = 'rgba(30,40,46,.8)'; g.fillRect(22,30,84,20);
      g.strokeStyle = 'rgba(200,210,215,.42)'; g.lineWidth = 2; g.strokeRect(22,30,84,20);
      g.fillStyle = 'rgba(50,176,200,.85)'; g.fillRect(10,118,108,5);
    } else if(theme === 'office'){
      g.strokeStyle = 'rgba(0,0,0,.14)'; g.lineWidth = 1;
      for(let x=0;x<s;x+=32){ g.beginPath(); g.moveTo(x,0); g.lineTo(x,s); g.stroke(); }
      g.fillStyle = 'rgba(255,255,255,.07)'; g.fillRect(0,0,s,8);
      g.fillStyle = 'rgba(30,38,44,.62)'; g.fillRect(30,32,68,30);
      g.strokeStyle = 'rgba(200,215,225,.5)'; g.lineWidth = 2; g.strokeRect(30,32,68,30);
      g.fillStyle = 'rgba(124,255,196,.34)'; g.fillRect(36,36,56,5);
    } else if(theme === 'industrial'){
      // corrugated panels
      for(let x=0;x<s;x+=12){
        g.fillStyle = x%24 ? 'rgba(255,255,255,.05)' : 'rgba(0,0,0,.12)';
        g.fillRect(x,0,6,s);
      }
      g.fillStyle = 'rgba(0,0,0,.28)';
      for(let y=0;y<s;y+=32) g.fillRect(0,y+30,s,2);
      // rivets
      g.fillStyle = 'rgba(20,20,20,.35)';
      for(let y=6;y<s;y+=24) for(let x=6;x<s;x+=24) g.beginPath(), g.arc(x,y,1.8,0,6.283), g.fill();
      // hazard stripe + window
      g.fillStyle = 'rgba(220,160,30,.85)';
      for(let x=-16;x<s;x+=24){ g.beginPath(); g.moveTo(x,116); g.lineTo(x+12,116); g.lineTo(x+24,128); g.lineTo(x+12,128); g.closePath(); g.fill(); }
      g.fillStyle = 'rgba(20,24,28,.8)'; g.fillRect(38,26,52,26);
      g.strokeStyle = 'rgba(160,170,180,.5)'; g.lineWidth = 2; g.strokeRect(38,26,52,26);
    } else {
      // bricks
      for(let y=0;y<s;y+=16){
        for(let x=0;x<s;x+=32){
          const off = (y/16)%2 ? 16 : 0;
          g.fillStyle = 'rgba(0,0,0,.12)'; g.fillRect(x+off, y, 30, 14);
          g.fillStyle = 'rgba(255,255,255,.045)'; g.fillRect(x+off+2, y+2, 26, 3);
        }
      }
      // windows with glass and occasional warm light
      for(let i=0;i<2;i++){
        const x = 12 + i*60, y = 26, lit = Math.random() < 0.45;
        g.fillStyle = lit ? 'rgba(255,205,110,.92)' : 'rgba(30,42,54,.92)';
        g.fillRect(x, y, 28, 34);
        g.fillStyle = lit ? 'rgba(255,240,190,.65)' : 'rgba(110,150,180,.30)';
        g.fillRect(x+3, y+3, 9, 12);
        g.strokeStyle = 'rgba(40,44,48,.85)'; g.lineWidth = 2; g.strokeRect(x, y, 28, 34);
        g.beginPath(); g.moveTo(x+14,y); g.lineTo(x+14,y+34); g.moveTo(x,y+17); g.lineTo(x+28,y+17); g.stroke();
        g.fillStyle = 'rgba(30,30,30,.5)'; g.fillRect(x-3, y+34, 34, 4);
      }
    }
    g.fillStyle = 'rgba(0,0,0,.20)';
    for(let i=0;i<220;i++) g.fillRect(Math.random()*s, Math.random()*s, 2, 2);
  }, 1);
}

function crateTexture(){
  return canvasTex(128, (g,s)=>{
    g.fillStyle = '#8a6a3c'; g.fillRect(0,0,s,s);
    g.strokeStyle = '#5a3f1e'; g.lineWidth = 6; g.strokeRect(3,3,s-6,s-6);
    g.strokeStyle = '#6e512a'; g.lineWidth = 4;
    g.beginPath(); g.moveTo(6,6); g.lineTo(s-6,s-6); g.moveTo(s-6,6); g.lineTo(6,s-6); g.stroke();
    g.fillStyle = 'rgba(0,0,0,.15)';
    for(let i=0;i<80;i++) g.fillRect(Math.random()*s, Math.random()*s, 2, 2);
  }, 1);
}

function siteTexture(letter, color){
  return canvasTex(256, (g,s)=>{
    g.clearRect(0,0,s,s);
    g.strokeStyle = color; g.lineWidth = 12;
    g.beginPath(); g.arc(s/2,s/2,s*0.42,0,6.283); g.stroke();
    g.fillStyle = color;
    g.font = 'bold '+Math.floor(s*0.55)+'px Arial';
    g.textAlign = 'center'; g.textBaseline = 'middle';
    g.fillText(letter, s/2, s/2+6);
  }, 1);
}

const QUALITY = {
  verylow: { shadows:false, particles:false, shadowSize:512,  aniso:1, particlesN:0,   fog:90,  amb:0.5 },
  low:     { shadows:false, particles:false, shadowSize:1024, aniso:2, particlesN:0,   fog:125, amb:0.42 },
  medium:  { shadows:true,  particles:true,  shadowSize:1024, aniso:4, particlesN:260, fog:165, amb:0.28 },
  high:    { shadows:true,  particles:true,  shadowSize:2048, aniso:8, particlesN:520, fog:240, amb:0.25 },
  ultra:   { shadows:true,  particles:true,  shadowSize:4096, aniso:16,particlesN:760, fog:320, amb:0.22 }
};

export class Level {
  constructor(map, scene, quality='high', opts={}){
    this.map = map;
    this.scene = scene;
    this.quality = quality;
    this.opts = opts;
    this.q = QUALITY[quality] || QUALITY.high;
    this.useShadows = (opts.shadows !== false) && this.q.shadows;
    this.useParticles = (opts.particles !== false) && this.q.particles && this.q.particlesN > 0;
    this.viewDistance = Math.max(60, Number(opts.viewDistance) || this.q.fog);
    this.group = new THREE.Group();
    scene.add(this.group);
    this.textures = [];
    this.materials = [];
    this.geometries = [];
    this._buildEnvironment();
    this._buildSky();
    this._buildGeometry();
    this._buildDetails();
    this._buildProps();
    this._buildBackdrop();
    this._buildSites();
    if(this.useParticles) this._buildParticles();
    this._applyTextureQuality();
  }

  _applyTextureQuality(){
    const aniso = Math.min(16, this.q.aniso || 1);
    for(const t of this.textures){ if(t && 'anisotropy' in t) t.anisotropy = aniso; }
  }

  _buildEnvironment(){
    const m = this.map;
    const light = m.light || 'day';
    const lp = {
      day:  { sky:m.sky, fog:m.fog, hemi:1.02, sun:0xfff2d8, sunI:1.45, fill:0x9fc4ff, fillI:0.34, amb:this.q.amb, sunPos:[-38,62,32] },
      dusk: { sky:'#b97858', fog:'#a86a4e', hemi:0.78, sun:0xffb36b, sunI:1.18, fill:0x7f95cc, fillI:0.26, amb:Math.max(0.24,this.q.amb), sunPos:[-52,30,46] },
      night:{ sky:'#081322', fog:'#0b1828', hemi:0.42, sun:0xaac4ff, sunI:0.62, fill:0x5f7fbf, fillI:0.18, amb:Math.max(0.2,this.q.amb), sunPos:[24,48,-38] }
    }[light] || null;
    const pal = lp || { sky:m.sky, fog:m.fog, hemi:1.02, sun:0xfff2d8, sunI:1.45, fill:0x9fc4ff, fillI:0.34, amb:this.q.amb, sunPos:[-38,62,32] };
    this.scene.background = new THREE.Color(pal.sky);
    this.scene.fog = new THREE.Fog(new THREE.Color(pal.fog), 26, this.viewDistance);
    this.scene.fog.near = 26; this.scene.fog.far = this.viewDistance;

    const cx = m.w * m.tile * 0.5, cz = m.h * m.tile * 0.5;
    const hemi = new THREE.HemisphereLight(new THREE.Color(pal.sky), new THREE.Color(m.ground), pal.hemi);
    this.scene.add(hemi);
    this.hemi = hemi;

    // The sun target sits at the map centre. Without this the shadow frustum
    // was pinned to the world origin and the far half of every map could fall
    // outside it, producing large black patches.
    const sun = new THREE.DirectionalLight(pal.sun, pal.sunI);
    sun.position.set(cx + pal.sunPos[0], pal.sunPos[1], cz + pal.sunPos[2]);
    sun.target.position.set(cx, 0, cz);
    this.scene.add(sun.target);
    if(this.useShadows){
      sun.castShadow = true;
      sun.shadow.mapSize.set(this.q.shadowSize, this.q.shadowSize);
      const d = Math.max(m.w, m.h) * m.tile * 0.78;
      sun.shadow.camera.left = -d; sun.shadow.camera.right = d;
      sun.shadow.camera.top = d; sun.shadow.camera.bottom = -d;
      sun.shadow.camera.near = 1; sun.shadow.camera.far = 260;
      sun.shadow.bias = -0.00025;
      sun.shadow.normalBias = 0.055;
      sun.shadow.radius = 2.2;
    }
    this.scene.add(sun);
    this.sun = sun;

    // Opposite fill light keeps unlit facades readable instead of crushing
    // them to black; it does not cast shadows, so it is cheap.
    const fill = new THREE.DirectionalLight(pal.fill, pal.fillI);
    fill.position.set(cx + 45, 34, cz - 40);
    fill.target.position.set(cx, 0, cz);
    this.scene.add(fill.target);
    this.scene.add(fill);
    this.fill = fill;

    const amb = new THREE.AmbientLight(0xffffff, pal.amb);
    this.scene.add(amb);
    this.amb = amb;
  }

  _buildSky(){
    const m = this.map;
    const w = m.w*m.tile, h = m.h*m.tile;
    let top = { city:'#5b7fa6', industrial:'#4a5666', desert:'#5f86b8', harbor:'#4d7488', office:'#5d7288', dust:'#5379a6', metro:'#334452', villa:'#7d9ab0' }[m.theme] || '#6a8aa8';
    let hor = { city:'#c9d6df', industrial:'#9aa3ad', desert:'#f0d49a', harbor:'#a8c4cf', office:'#c4d0dc', dust:'#ecd09a', metro:'#26313a', villa:'#c8d6de' }[m.theme] || m.sky;
    if(m.light === 'dusk'){ top = '#3d4a6b'; hor = '#e0a06a'; }
    else if(m.light === 'night'){ top = '#040a14'; hor = '#142a44'; }
    const tex = canvasTex(256, (g,s)=>{
      try{
        const grd = g.createLinearGradient(0,0,0,s);
        if(grd && grd.addColorStop){
          grd.addColorStop(0, top);
          grd.addColorStop(0.55, m.sky);
          grd.addColorStop(1, hor);
          g.fillStyle = grd; g.fillRect(0,0,s,s);
        } else {
          g.fillStyle = m.sky; g.fillRect(0,0,s,s);
        }
      }catch(e){}
    }, 1);
    tex.wrapS = tex.wrapT = THREE.ClampToEdgeWrapping;
    const geo = new THREE.SphereGeometry(210, 24, 16);
    const mat = new THREE.MeshBasicMaterial({ map:tex, side:THREE.BackSide, fog:false, depthWrite:false });
    const dome = new THREE.Mesh(geo, mat);
    dome.position.set(w/2, -8, h/2);
    this.group.add(dome);
    this.textures.push(tex); this.geometries.push(geo); this.materials.push(mat);
    this.skyDome = dome;
  }

  _buildGeometry(){
    const m = this.map;
    const tile = m.tile;
    const worldW = m.w * tile, worldH = m.h * tile;

    // ground
    const gtex = groundTexture(m.theme);
    this.textures.push(gtex);
    const gmat = new THREE.MeshStandardMaterial({ map:gtex, roughness:0.95, metalness:0.02 });
    this.materials.push(gmat);
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(worldW, worldH), gmat);
    ground.rotation.x = -Math.PI/2;
    ground.position.set(worldW/2, 0, worldH/2);
    ground.receiveShadow = this.useShadows;
    this.group.add(ground);
    this.geometries.push(ground.geometry);

    // count instances
    let c1=0, c2=0, c3=0;
    for(let i=0;i<m.grid.length;i++){
      const t = m.grid[i];
      if(t===1) c1++; else if(t===2) c2++; else if(t===3) c3++;
    }

    const wallTex = wallTexture(m.theme); this.textures.push(wallTex);
    const wallMat = new THREE.MeshStandardMaterial({ map:wallTex, roughness:0.9, metalness:0.05 });
    this.materials.push(wallMat);
    const crateTex = crateTexture(); this.textures.push(crateTex);
    const crateMat = new THREE.MeshStandardMaterial({ map:crateTex, roughness:0.85, metalness:0.05 });
    this.materials.push(crateMat);
    const lowMat = new THREE.MeshStandardMaterial({ color:new THREE.Color(m.wall).multiplyScalar(0.75), roughness:0.95, metalness:0.05 });
    this.materials.push(lowMat);

    const geoWall = new THREE.BoxGeometry(tile, 1, tile); this.geometries.push(geoWall);
    const geoCrate = new THREE.BoxGeometry(tile*0.88, 1, tile*0.88); this.geometries.push(geoCrate);
    const geoLow = new THREE.BoxGeometry(tile, 1, tile*0.9); this.geometries.push(geoLow);

    const walls = new THREE.InstancedMesh(geoWall, wallMat, Math.max(1,c1));
    const crates = new THREE.InstancedMesh(geoCrate, crateMat, Math.max(1,c2));
    const lows = new THREE.InstancedMesh(geoLow, lowMat, Math.max(1,c3));
    walls.count = c1; crates.count = c2; lows.count = c3;
    const shadows = this.useShadows;
    walls.castShadow = crates.castShadow = lows.castShadow = shadows;
    walls.receiveShadow = crates.receiveShadow = lows.receiveShadow = shadows;
    walls.instanceMatrix.setUsage(THREE.DynamicDrawUsage);

    const mat4 = new THREE.Matrix4();
    const q = new THREE.Quaternion();
    const pos = new THREE.Vector3();
    const scl = new THREE.Vector3();
    const capGeo = new THREE.BoxGeometry(tile*1.04, 0.18, tile*1.04);
    const capMat = new THREE.MeshStandardMaterial({ color:new THREE.Color(m.wall).multiplyScalar(0.58), roughness:0.9, metalness:0.06 });
    this.geometries.push(capGeo); this.materials.push(capMat);
    const caps = new THREE.InstancedMesh(capGeo, capMat, Math.max(1,c1));
    caps.count = c1;
    const capMat4 = new THREE.Matrix4();
    let ic=0;
    let i1=0,i2=0,i3=0;
    for(let y=0;y<m.h;y++){
      for(let x=0;x<m.w;x++){
        const idx = y*m.w+x;
        const t = m.grid[idx];
        if(!t) continue;
        const h = m.heights[idx] || 1.2;
        const wx = x*tile + tile/2, wz = y*tile + tile/2;
        pos.set(wx, h/2, wz);
        scl.set(1, h, 1);
        mat4.compose(pos, q, scl);
        if(t===1){
          walls.setMatrixAt(i1++, mat4);
          capMat4.compose(new THREE.Vector3(wx, h+0.09, wz), q, new THREE.Vector3(1,1,1));
          caps.setMatrixAt(ic++, capMat4);
        }
        else if(t===2) crates.setMatrixAt(i2++, mat4);
        else lows.setMatrixAt(i3++, mat4);
      }
    }
    walls.instanceMatrix.needsUpdate = true;
    crates.instanceMatrix.needsUpdate = true;
    lows.instanceMatrix.needsUpdate = true;
    caps.instanceMatrix.needsUpdate = true;
    this.group.add(walls, crates, lows, caps);
    this.walls = walls; this.crates = crates; this.lows = lows; this.caps = caps;
  }

  _buildDetails(){
    const m = this.map;
    const tile = m.tile;
    const w = m.w*tile, h = m.h*tile;
    const shadows = this.useShadows;
    const mark = new THREE.Color(m.theme === 'desert' ? '#d8c08a' : '#c8b25a');

    // road / walkway markings: thin, non-colliding decals between building blocks
    const dashGeo = new THREE.PlaneGeometry(0.16, tile*0.62);
    const dashMat = new THREE.MeshBasicMaterial({ color:mark, transparent:true, opacity:m.theme==='desert'?0.18:0.30, depthWrite:false });
    this.geometries.push(dashGeo); this.materials.push(dashMat);
    const dashCount = 260;
    const dashes = new THREE.InstancedMesh(dashGeo, dashMat, dashCount);
    const dm = new THREE.Matrix4(), dq = new THREE.Quaternion().setFromEuler(new THREE.Euler(-Math.PI/2,0,0));
    const dp = new THREE.Vector3(), ds = new THREE.Vector3(1,1,1);
    let di=0;
    for(let y=2;y<m.h-2 && di<dashCount;y+=7){
      for(let x=2;x<m.w-2 && di<dashCount;x+=2){
        if(m.grid[y*m.w+x] !== 0) continue;
        if((x+y)%4 !== 0) continue;
        dp.set(x*tile + tile/2, 0.028, y*tile + tile/2);
        dm.compose(dp,dq,ds); dashes.setMatrixAt(di++,dm);
      }
    }
    dashes.count = di; dashes.instanceMatrix.needsUpdate = true;
    this.group.add(dashes);

    // dark base trim around buildings gives walls readable contact shadows
    const trimGeo = new THREE.BoxGeometry(tile*1.035, 0.16, tile*1.035);
    const trimMat = new THREE.MeshStandardMaterial({ color:new THREE.Color(m.wall).multiplyScalar(0.38), roughness:0.96, metalness:0.02 });
    this.geometries.push(trimGeo); this.materials.push(trimMat);
    const trims = new THREE.InstancedMesh(trimGeo, trimMat, Math.max(1, this.map.grid.reduce((n,t)=>n+(t===1?1:0),0)));
    let ti=0;
    for(let y=0;y<m.h;y++) for(let x=0;x<m.w;x++){
      if(m.grid[y*m.w+x] !== 1) continue;
      dp.set(x*tile+tile/2, 0.08, y*tile+tile/2);
      dm.compose(dp,dq.set(0,0,0,1),ds.set(1,1,1)); trims.setMatrixAt(ti++,dm);
    }
    trims.count = ti; trims.instanceMatrix.needsUpdate = true;
    trims.receiveShadow = shadows; trims.castShadow = false;
    this.group.add(trims);

    // rooftop vents / AC units break up the flat building silhouette
    const roofGeo = new THREE.BoxGeometry(tile*0.45, 0.42, tile*0.45);
    const roofMat = new THREE.MeshStandardMaterial({ color:new THREE.Color(m.wall).multiplyScalar(0.62), roughness:0.82, metalness:0.22 });
    this.geometries.push(roofGeo); this.materials.push(roofMat);
    const roofs = new THREE.InstancedMesh(roofGeo, roofMat, Math.max(1, Math.ceil(ti/3)));
    const rq = new THREE.Quaternion();
    let ri=0;
    for(let y=0;y<m.h;y++) for(let x=0;x<m.w;x++){
      if(m.grid[y*m.w+x] !== 1) continue;
      if((x*7+y*13)%5 !== 0) continue;
      const hh = m.heights[y*m.w+x] || 5;
      dp.set(x*tile+tile/2 + (Math.random()-0.5)*0.5, hh+0.21, y*tile+tile/2 + (Math.random()-0.5)*0.5);
      rq.setFromAxisAngle(new THREE.Vector3(0,1,0), Math.random()*0.6);
      dm.compose(dp,rq,ds.set(0.8+Math.random()*0.5,0.7+Math.random()*0.8,0.8+Math.random()*0.5));
      roofs.setMatrixAt(ri++,dm);
    }
    roofs.count = ri; roofs.instanceMatrix.needsUpdate = true;
    roofs.castShadow = shadows; roofs.receiveShadow = shadows;
    this.group.add(roofs);

    // soft colored ground pools near the sites (premium lighting feel without extra lights)
    for(const s of m.sites){
      const poolGeo = new THREE.CircleGeometry(tile*2.2, 28);
      const poolMat = new THREE.MeshBasicMaterial({ color:m.theme==='desert'?0xffdf9a:0x77b7ff, transparent:true, opacity:0.055, blending:THREE.AdditiveBlending, depthWrite:false });
      const pool = new THREE.Mesh(poolGeo, poolMat);
      pool.rotation.x = -Math.PI/2;
      pool.position.set(s.x, 0.04, s.z);
      this.group.add(pool);
      this.geometries.push(poolGeo); this.materials.push(poolMat);
    }
  }

  _buildProps(){
    const m = this.map;
    const tile = m.tile;
    const shadows = this.useShadows;
    const open = [];
    for(let y=2;y<m.h-2;y++) for(let x=2;x<m.w-2;x++){
      if(m.grid[y*m.w+x] === 0) open.push({x,y});
    }
    if(!open.length) return;

    // street lamps: warm emissive heads along the larger roads
    const poleGeo = new THREE.CylinderGeometry(0.045,0.06,3.6,6);
    const headGeo = new THREE.BoxGeometry(0.26,0.1,0.42);
    const poleMat = new THREE.MeshStandardMaterial({ color:'#252b31', roughness:0.55, metalness:0.7 });
    const headMat = new THREE.MeshStandardMaterial({ color:'#ffd79a', emissive:'#ffb347', emissiveIntensity:1.2, roughness:0.4, metalness:0.2 });
    this.geometries.push(poleGeo, headGeo); this.materials.push(poleMat, headMat);
    const lampCount = Math.min(28, Math.floor(open.length/14));
    const poles = new THREE.InstancedMesh(poleGeo, poleMat, lampCount);
    const heads = new THREE.InstancedMesh(headGeo, headMat, lampCount);
    const lm = new THREE.Matrix4(), lq = new THREE.Quaternion(), lp = new THREE.Vector3(), ls = new THREE.Vector3(1,1,1);
    let li = 0;
    for(let i=0;i<open.length && li<lampCount;i+=7){
      const c = open[(i*13 + 5) % open.length];
      if((c.x+c.y)%2) continue;
      const wx = c.x*tile + tile/2, wz = c.y*tile + tile/2;
      lp.set(wx, 1.8, wz); lq.set(0,0,0,1);
      lm.compose(lp,lq,ls); poles.setMatrixAt(li,lm);
      lp.set(wx, 3.62, wz + 0.14);
      lm.compose(lp,lq,ls); heads.setMatrixAt(li,lm);
      li++;
    }
    poles.count = heads.count = li;
    poles.instanceMatrix.needsUpdate = heads.instanceMatrix.needsUpdate = true;
    poles.castShadow = heads.castShadow = shadows;
    this.group.add(poles, heads);

  }

  _buildBackdrop(){
    const m = this.map;
    const w = m.w*m.tile, h = m.h*m.tile;
    const cx = w/2, cz = h/2;
    const count = 54;
    const geo = new THREE.BoxGeometry(1,1,1);
    const col = { city:'#2b3138', industrial:'#20262c', desert:'#7a5a38', harbor:'#243238', office:'#2c343c', dust:'#6f5538', metro:'#171d22', villa:'#3d423c' }[m.theme] || '#2a3036';
    const mat = new THREE.MeshStandardMaterial({ color:new THREE.Color(col), roughness:1, metalness:0 });
    const inst = new THREE.InstancedMesh(geo, mat, count);
    const mat4 = new THREE.Matrix4();
    const q = new THREE.Quaternion();
    const p = new THREE.Vector3();
    const sc = new THREE.Vector3();
    const desert = m.theme === 'desert' || m.theme === 'dust';
    for(let i=0;i<count;i++){
      const a = (i/count)*Math.PI*2 + Math.random()*0.10;
      const r = 56 + Math.random()*30;
      const bw = 5 + Math.random()*12;
      const bh = desert ? (2 + Math.random()*7) : (7 + Math.random()*24);
      const bd = 5 + Math.random()*12;
      p.set(cx + Math.cos(a)*r, bh/2, cz + Math.sin(a)*r);
      q.setFromAxisAngle(new THREE.Vector3(0,1,0), -a + Math.random()*0.6);
      sc.set(bw, bh, bd);
      mat4.compose(p, q, sc);
      inst.setMatrixAt(i, mat4);
    }
    inst.instanceMatrix.needsUpdate = true;
    inst.castShadow = false; inst.receiveShadow = false;
    this.group.add(inst);
    this.geometries.push(geo); this.materials.push(mat);
    this.backdrop = inst;
  }

  _buildSites(){
    const m = this.map;
    this.siteMeshes = [];
    for(const s of m.sites){
      const tex = siteTexture(s.name, (m.theme==='desert' || m.theme==='dust') ? '#e8e0c8' : '#ffcf5a');
      this.textures.push(tex);
      const mat = new THREE.MeshBasicMaterial({ map:tex, transparent:true, depthWrite:false, opacity:0.85 });
      this.materials.push(mat);
      const mesh = new THREE.Mesh(new THREE.PlaneGeometry(m.tile*3.2, m.tile*3.2), mat);
      mesh.rotation.x = -Math.PI/2;
      mesh.position.set(s.x, 0.06, s.z);
      this.group.add(mesh);
      this.siteMeshes.push(mesh);
      this.geometries.push(mesh.geometry);

      const beaconCol = (m.theme==='desert' || m.theme==='dust') ? 0xffe2a8 : 0xffcf5a;
      const bgeo = new THREE.CylinderGeometry(0.55, 0.12, 7.5, 10, 1, true);
      const bmat = new THREE.MeshBasicMaterial({ color:beaconCol, transparent:true, opacity:0.10, blending:THREE.AdditiveBlending, depthWrite:false, side:THREE.DoubleSide });
      const beacon = new THREE.Mesh(bgeo, bmat);
      beacon.position.set(s.x, 3.75, s.z);
      this.group.add(beacon);
      this.geometries.push(bgeo); this.materials.push(bmat);
      const light = new THREE.PointLight(beaconCol, 0.7, 16, 2);
      light.position.set(s.x, 3.2, s.z);
      this.scene.add(light);
      if(!this.siteLights) this.siteLights = [];
      this.siteLights.push(light);

      const ringGeo = new THREE.RingGeometry(m.tile*1.82, m.tile*1.94, 44);
      const ringMat = new THREE.MeshBasicMaterial({ color:beaconCol, transparent:true, opacity:0.30, side:THREE.DoubleSide, depthWrite:false });
      const ring = new THREE.Mesh(ringGeo, ringMat);
      ring.rotation.x = -Math.PI/2;
      ring.position.set(s.x, 0.055, s.z);
      this.group.add(ring);
      this.geometries.push(ringGeo); this.materials.push(ringMat);

      const postGeo = new THREE.CylinderGeometry(0.035, 0.05, 1.15, 6);
      const postMat = new THREE.MeshStandardMaterial({ color:'#14181c', emissive:beaconCol, emissiveIntensity:0.85, roughness:0.5, metalness:0.4 });
      this.geometries.push(postGeo); this.materials.push(postMat);
      for(const [dx,dz] of [[-1,-1],[1,-1],[-1,1],[1,1]]){
        const post = new THREE.Mesh(postGeo, postMat);
        post.position.set(s.x + dx*m.tile*1.78, 0.575, s.z + dz*m.tile*1.78);
        this.group.add(post);
      }
    }
  }

  _buildParticles(){
    const m = this.map;
    const n = this.q.particlesN || 260;
    const geo = new THREE.BufferGeometry();
    const arr = new Float32Array(n*3);
    for(let i=0;i<n;i++){
      arr[i*3] = Math.random()*m.w*m.tile;
      arr[i*3+1] = 0.5 + Math.random()*6;
      arr[i*3+2] = Math.random()*m.h*m.tile;
    }
    geo.setAttribute('position', new THREE.BufferAttribute(arr, 3));
    const pcol = { city:0xd6dee6, industrial:0xb8ad96, desert:0xecd6a8, harbor:0xb8d4dc, office:0xd8e2ea, dust:0xecd6a8, metro:0x8fd8de, villa:0xf0e6c8 }[m.theme] || 0xffffff;
    const mat = new THREE.PointsMaterial({ color:pcol, size:this.quality === 'ultra' ? 0.10 : (this.quality === 'high' ? 0.085 : 0.065), transparent:true, opacity:0.32, depthWrite:false });
    this.particles = new THREE.Points(geo, mat);
    this.group.add(this.particles);
    this.geometries.push(geo);
    this.materials.push(mat);
  }

  update(dt){
    if(this.particles){
      this.particles.rotation.y += dt * 0.01;
      this.particles.position.y = Math.sin(performance.now()*0.0003) * 0.15;
    }
  }

  isBlocked(x, z, r){
    const m = this.map;
    const pts = [
      [x-r, z], [x+r, z], [x, z-r], [x, z+r],
      [x-r, z-r], [x+r, z-r], [x-r, z+r], [x+r, z+r]
    ];
    for(const [px,pz] of pts){
      if(isSolid(m, Math.floor(px/m.tile), Math.floor(pz/m.tile))) return true;
    }
    return false;
  }

  raycast(ox, oy, oz, dx, dy, dz, maxT){
    return raycastWorld(this.map, ox, oy, oz, dx, dy, dz, maxT);
  }
  lineOfSight(ax,ay,az,bx,by,bz){ return lineOfSight(this.map, ax,ay,az,bx,by,bz); }

  spawnList(team){
    const list = this.map.spawns[team] || this.map.spawns.CT;
    return list.map(s=>({ x:s.x, z:s.z, ang:s.ang || 0 }));
  }
  getSpawn(team, index){
    const list = this.spawnList(team);
    const s = list[((index % list.length) + list.length) % list.length];
    return { x: s.x, z: s.z, ang: s.ang || 0 };
  }
  randomSpawn(team){
    const list = this.spawnList(team);
    const s = list[Math.floor(Math.random()*list.length)];
    return { x: s.x + (Math.random()-0.5)*1.2, z: s.z + (Math.random()-0.5)*1.2, ang: Math.random()*6.283 };
  }
  // Spawn point farthest from the given entities (used for respawns / FFA).
  safeSpawn(team, avoid=[]){
    const list = this.spawnList(team);
    const alive = avoid.filter(e=>e && e.alive !== false);
    let best = list[0], bestScore = -Infinity;
    for(const s of list){
      let nearest = 999;
      for(const e of alive){
        const ex = e.pos ? e.pos.x : e.x, ez = e.pos ? e.pos.z : e.z;
        nearest = Math.min(nearest, Math.hypot(ex - s.x, ez - s.z));
      }
      const score = nearest + Math.random()*1.5;
      if(score > bestScore){ bestScore = score; best = s; }
    }
    return { x: best.x, z: best.z, ang: best.ang || 0 };
  }
  randomOpenPoint(){
    const m = this.map;
    for(let i=0;i<200;i++){
      const cx = 1 + Math.floor(Math.random()*(m.w-2));
      const cy = 1 + Math.floor(Math.random()*(m.h-2));
      if(!isSolid(m, cx, cy)) return { x: cx*m.tile + m.tile/2, z: cy*m.tile + m.tile/2 };
    }
    return { x: m.w*m.tile/2, z: m.h*m.tile/2 };
  }
  openPointNear(x, z, radius=5){
    for(let i=0;i<24;i++){
      const a = Math.random()*Math.PI*2;
      const d = 1.2 + Math.random()*radius;
      const px = x + Math.cos(a)*d, pz = z + Math.sin(a)*d;
      if(!this.isBlocked(px, pz, 0.5)) return { x:px, z:pz };
    }
    return { x, z };
  }

  // Finds a nearby open tile that breaks line of sight from the threat.
  findCover(x, z, threatX, threatZ){
    const tile = this.map.tile;
    let best = null, bestCost = Infinity;
    for(let ring=1; ring<=7; ring++){
      const n = 8 + ring * 8;
      for(let i=0;i<n;i++){
        const a = (i / n) * Math.PI * 2 + Math.random()*0.16;
        const r = ring * tile * 0.82;
        const cx = x + Math.cos(a)*r, cz = z + Math.sin(a)*r;
        if(this.isBlocked(cx, cz, 0.38)) continue;
        const tooClose = Math.hypot(cx-threatX, cz-threatZ) < 3.2;
        if(tooClose) continue;
        if(this.lineOfSight(cx, 1.35, cz, threatX, 1.45, threatZ)) continue;
        const cost = Math.hypot(cx-x, cz-z) + Math.random()*0.6;
        if(cost < bestCost){ bestCost = cost; best = { x:cx, z:cz }; }
      }
      if(best && ring >= 2) break;
    }
    if(best) return best;
    // No hard cover: move to the nearest open point away from the threat.
    for(let i=0;i<24;i++){
      const a = Math.random()*Math.PI*2, r = 2.5 + Math.random()*5;
      const cx = x + Math.cos(a)*r, cz = z + Math.sin(a)*r;
      if(!this.isBlocked(cx, cz, 0.38)) return { x:cx, z:cz };
    }
    return this.randomOpenPoint();
  }

  worldSize(){ return { w: this.map.w * this.map.tile, h: this.map.h * this.map.tile }; }

  dispose(){
    this.scene.remove(this.group);
    this.group.traverse(o=>{ if(o.geometry && this.geometries.includes(o.geometry)) {} });
    for(const g of this.geometries) g.dispose();
    for(const m of this.materials) m.dispose();
    for(const t of this.textures) t.dispose();
    this.scene.remove(this.hemi); this.scene.remove(this.sun); this.scene.remove(this.amb); this.scene.remove(this.fill);
    this.scene.remove(this.sun.target); this.scene.remove(this.fill.target);
    if(this.siteLights) for(const l of this.siteLights) this.scene.remove(l);
  }
}
