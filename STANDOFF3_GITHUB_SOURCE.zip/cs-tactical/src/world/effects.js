// Visual effects: muzzle flashes, tracers, impacts, blood, explosions, smoke, fire.
import * as THREE from '../../vendor/three.module.js';

const tracerGeo = new THREE.CylinderGeometry(0.012, 0.012, 1, 5);
const sparkGeo = new THREE.BoxGeometry(0.04,0.04,0.04);
const sphereGeo = new THREE.SphereGeometry(1, 10, 8);
const casingGeo = new THREE.BoxGeometry(0.014,0.014,0.034);
const ringGeo = new THREE.RingGeometry(0.4, 0.55, 24);
const fireGeo = new THREE.ConeGeometry(0.35, 1.2, 6);
const casingMat = new THREE.MeshStandardMaterial({ color:0xc8a23a, metalness:0.9, roughness:0.25 });
const dustMat = new THREE.MeshBasicMaterial({ color:0xc4b8a4, transparent:true, opacity:0.5, depthWrite:false });

let flashTex = null;
export function getFlashTexture(){ return flashTexture(); }
function flashTexture(){
  if(flashTex) return flashTex;
  const c = document.createElement('canvas');
  c.width = c.height = 64;
  const g = c.getContext('2d');
  try{
    const grd = g.createRadialGradient(32,32,2,32,32,30);
    if(grd && grd.addColorStop){
      grd.addColorStop(0,'rgba(255,255,255,1)');
      grd.addColorStop(0.25,'rgba(255,235,180,0.95)');
      grd.addColorStop(0.6,'rgba(255,170,70,0.5)');
      grd.addColorStop(1,'rgba(255,120,20,0)');
      g.fillStyle = grd;
      g.fillRect(0,0,64,64);
      g.strokeStyle = 'rgba(255,240,200,0.85)';
      g.lineWidth = 3;
      for(let i=0;i<6;i++){
        const a = i/6*Math.PI*2;
        g.beginPath(); g.moveTo(32,32); g.lineTo(32+Math.cos(a)*30,32+Math.sin(a)*30); g.stroke();
      }
    }
  }catch(e){ /* headless / unsupported canvas */ }
  flashTex = new THREE.CanvasTexture(c);
  return flashTex;
}

export class Effects {
  constructor(scene){
    this.scene = scene;
    this.tracers = [];
    this.sparks = [];
    this.balls = [];
    this.smokes = [];
    this.fires = [];
    this.lights = [];
    this.flashes = [];
    this.puffs = [];
    this.casings = [];
    this.rings = [];
    this._tmp = new THREE.Vector3();
  }

  tracer(from, to, color=0xffd27a){
    const dir = this._tmp.subVectors(to, from);
    const len = dir.length();
    if(len < 0.05) return;
    const m = new THREE.Mesh(tracerGeo, new THREE.MeshBasicMaterial({ color, transparent:true, opacity:0.85, blending:THREE.AdditiveBlending, depthWrite:false }));
    m.position.copy(from).add(to).multiplyScalar(0.5);
    m.scale.set(1, len, 1);
    m.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0), dir.clone().normalize());
    this.scene.add(m);
    this.tracers.push({ m, life:0.07, max:0.07 });
  }

  muzzle(point, dir, scale=1, color=0xffcf7a){
    const mat = new THREE.SpriteMaterial({
      map: flashTexture(), color, transparent:true, opacity:0.95,
      blending:THREE.AdditiveBlending, depthWrite:false
    });
    const s = new THREE.Sprite(mat);
    s.position.copy(point);
    const base = 0.55 * scale;
    s.scale.setScalar(base);
    this.scene.add(s);
    const light = new THREE.PointLight(0xffb060, 3.5, 7);
    light.position.copy(point);
    this.scene.add(light);
    this.flashes.push({ s, light, life:0.055, max:0.055, base });
    // small smoke wisp
    if(Math.random() < 0.7) this.puff(point, 0x9a958c, 0.16*scale, 0.35, 0.6);
  }

  casing(point, dir){
    const m = new THREE.Mesh(casingGeo, casingMat);
    m.position.copy(point);
    m.rotation.set(Math.random()*3, Math.random()*3, Math.random()*3);
    m.userData.v = new THREE.Vector3(
      dir.x*1.2 + (Math.random()-0.5)*1.8,
      2.0 + Math.random()*1.4,
      dir.z*1.2 + (Math.random()-0.5)*1.8
    );
    m.userData.spin = new THREE.Vector3((Math.random()-0.5)*20, (Math.random()-0.5)*20, (Math.random()-0.5)*20);
    this.scene.add(m);
    this.casings.push({ m, life:1.3, max:1.3 });
  }

  puff(point, color=0xbfb6a6, size=0.3, life=0.6, rise=1.2){
    const mat = dustMat.clone();
    mat.color = new THREE.Color(color);
    const m = new THREE.Mesh(sphereGeo, mat);
    m.position.copy(point);
    m.scale.setScalar(size);
    m.userData.v = new THREE.Vector3((Math.random()-0.5)*0.9, rise*(0.4+Math.random()), (Math.random()-0.5)*0.9);
    this.scene.add(m);
    this.puffs.push({ m, life, max:life, from:size, to:size*2.6 });
  }

  impact(point, color=0xffcf7a){
    for(let i=0;i<7;i++){
      const s = new THREE.Mesh(sparkGeo, new THREE.MeshBasicMaterial({ color, transparent:true, blending:THREE.AdditiveBlending, depthWrite:false }));
      s.position.copy(point);
      const v = new THREE.Vector3((Math.random()-0.5)*5, Math.random()*3.5, (Math.random()-0.5)*5);
      s.userData.v = v;
      this.scene.add(s);
      this.sparks.push({ m:s, life:0.28, max:0.28 });
    }
    this.puff(point, 0xaaa08e, 0.10, 0.35, 0.9);
    if(Math.random() < 0.5) this.puff(point, 0x777069, 0.07, 0.5, 0.5);
  }

  blood(point){
    for(let i=0;i<8;i++){
      const s = new THREE.Mesh(sparkGeo, new THREE.MeshBasicMaterial({ color:0x8a1010, transparent:true, opacity:0.9, depthWrite:false }));
      s.position.copy(point);
      s.scale.setScalar(1.5 + Math.random());
      s.userData.v = new THREE.Vector3((Math.random()-0.5)*2.8, Math.random()*2.2, (Math.random()-0.5)*2.8);
      this.scene.add(s);
      this.sparks.push({ m:s, life:0.4, max:0.4 });
    }
    const mist = new THREE.Mesh(sphereGeo, new THREE.MeshBasicMaterial({ color:0x5a0808, transparent:true, opacity:0.45, depthWrite:false }));
    mist.position.copy(point);
    mist.scale.setScalar(0.16);
    mist.userData.v = new THREE.Vector3(0, 0.3, 0);
    this.scene.add(mist);
    this.puffs.push({ m:mist, life:0.3, max:0.3, from:0.16, to:0.85, mist:true });
  }

  explosion(point, radius=4){
    const mat = new THREE.MeshBasicMaterial({ color:0xffaa33, transparent:true, opacity:0.9, blending:THREE.AdditiveBlending, depthWrite:false });
    const m = new THREE.Mesh(sphereGeo, mat);
    m.position.copy(point);
    m.scale.setScalar(0.4);
    this.scene.add(m);
    this.balls.push({ m, life:0.5, max:0.5, from:0.4, to:radius*1.2 });

    const ring = new THREE.Mesh(ringGeo, new THREE.MeshBasicMaterial({ color:0xffd28a, transparent:true, opacity:0.8, blending:THREE.AdditiveBlending, depthWrite:false, side:THREE.DoubleSide }));
    ring.rotation.x = -Math.PI/2;
    ring.position.copy(point); ring.position.y = 0.08;
    ring.scale.setScalar(1);
    this.scene.add(ring);
    this.rings.push({ m:ring, life:0.55, max:0.55, to:radius*1.9 });

    const light = new THREE.PointLight(0xffaa44, 6, radius*4);
    light.position.copy(point); light.position.y += 0.6;
    this.scene.add(light);
    this.lights.push({ light, life:0.25, max:0.25, base:6 });

    for(let i=0;i<16;i++){
      const s = new THREE.Mesh(sparkGeo, new THREE.MeshBasicMaterial({ color:0xff8833, transparent:true, blending:THREE.AdditiveBlending, depthWrite:false }));
      s.position.copy(point);
      s.userData.v = new THREE.Vector3((Math.random()-0.5)*13, Math.random()*9, (Math.random()-0.5)*13);
      this.scene.add(s);
      this.sparks.push({ m:s, life:0.65, max:0.65 });
    }
    for(let i=0;i<6;i++){
      this.puff(point.clone().add(new THREE.Vector3((Math.random()-0.5)*radius, 0.4+Math.random()*1.4, (Math.random()-0.5)*radius)), 0x6a625a, 0.6, 1.4, 1.8);
    }
  }

  flashbang(point){
    const mat = new THREE.MeshBasicMaterial({ color:0xffffff, transparent:true, opacity:1, blending:THREE.AdditiveBlending, depthWrite:false });
    const m = new THREE.Mesh(sphereGeo, mat);
    m.position.copy(point); m.scale.setScalar(0.5);
    this.scene.add(m);
    this.balls.push({ m, life:0.25, max:0.25, from:0.5, to:3 });
    const light = new THREE.PointLight(0xffffff, 8, 20);
    light.position.copy(point); this.scene.add(light);
    this.lights.push({ light, life:0.15, max:0.15, base:8 });
  }

  deathPuff(point, color=0x8a1515){
    const p = point.clone ? point.clone() : new THREE.Vector3(point.x||0, point.y||0, point.z||0);
    for(let i=0;i<10;i++){
      const s = new THREE.Mesh(sparkGeo, new THREE.MeshBasicMaterial({ color:0x7a1010, transparent:true, opacity:0.85, depthWrite:false }));
      s.position.copy(p).add(new THREE.Vector3((Math.random()-0.5)*0.35, 0.25+Math.random()*0.8, (Math.random()-0.5)*0.35));
      s.scale.setScalar(1.2 + Math.random());
      s.userData.v = new THREE.Vector3((Math.random()-0.5)*2.2, 1.2+Math.random()*2.2, (Math.random()-0.5)*2.2);
      this.scene.add(s);
      this.sparks.push({ m:s, life:0.55, max:0.55 });
    }
    this.puff(p.clone().setY(0.7), color, 0.32, 0.9, 1.4);
    this.puff(p.clone().setY(0.35), 0x6a5a4a, 0.22, 1.1, 0.6);
  }

  spawnRing(point, color=0x6db6ff){
    const mat = new THREE.MeshBasicMaterial({ color, transparent:true, opacity:0.9, blending:THREE.AdditiveBlending, depthWrite:false, side:THREE.DoubleSide });
    const m = new THREE.Mesh(ringGeo, mat);
    m.rotation.x = -Math.PI/2;
    m.position.copy(point);
    m.scale.setScalar(0.6);
    this.scene.add(m);
    this.rings.push({ m, life:0.65, max:0.65, to:2.6 });
  }

  smoke(point, radius=4, duration=16){
    const group = new THREE.Group();
    group.position.copy(point);
    const puffs = [];
    for(let i=0;i<16;i++){
      const mat = new THREE.MeshStandardMaterial({ color:0x8d949c, transparent:true, opacity:0.0, roughness:1, metalness:0, depthWrite:false });
      const p = new THREE.Mesh(sphereGeo, mat);
      const a = Math.random()*Math.PI*2, r = Math.random()*radius*0.6;
      p.position.set(Math.cos(a)*r, 0.4 + Math.random()*1.8, Math.sin(a)*r);
      p.scale.setScalar(radius*(0.35+Math.random()*0.3));
      group.add(p); puffs.push(p);
    }
    this.scene.add(group);
    this.smokes.push({ group, puffs, life:duration, max:duration, radius, pos:point.clone(), grow:0 });
    return this.smokes[this.smokes.length-1];
  }

  fire(point, radius=4, duration=7){
    const group = new THREE.Group();
    group.position.copy(point);
    const mats = [0xff6a00,0xffa000,0xff3300].map(c=>new THREE.MeshBasicMaterial({ color:c, transparent:true, opacity:0.8, blending:THREE.AdditiveBlending, depthWrite:false }));
    const flames = [];
    for(let i=0;i<14;i++){
      const p = new THREE.Mesh(fireGeo, mats[i%3]);
      const a = Math.random()*Math.PI*2, r = Math.random()*radius*0.7;
      p.position.set(Math.cos(a)*r, 0.6, Math.sin(a)*r);
      group.add(p); flames.push({ m:p, ph: Math.random()*10 });
    }
    this.scene.add(group);
    this.fires.push({ group, flames, life:duration, max:duration, radius, pos:point.clone() });
    return this.fires[this.fires.length-1];
  }

  isSmokeBlocked(ax, az, bx, bz){
    for(const s of this.smokes){
      if(s.life <= 0 || s.grow < 0.4) continue;
      if(segCircle(ax,az,bx,bz, s.pos.x, s.pos.z, s.radius*0.85)) return true;
    }
    return false;
  }

  update(dt){
    for(let i=this.tracers.length-1;i>=0;i--){
      const t = this.tracers[i]; t.life -= dt;
      t.m.material.opacity = Math.max(0, t.life/t.max) * 0.85;
      if(t.life <= 0){ this.scene.remove(t.m); t.m.material.dispose(); this.tracers.splice(i,1); }
    }
    for(let i=this.sparks.length-1;i>=0;i--){
      const s = this.sparks[i]; s.life -= dt;
      s.m.position.addScaledVector(s.m.userData.v, dt);
      s.m.userData.v.y -= 9*dt;
      s.m.material.opacity = Math.max(0, s.life/s.max);
      if(s.life <= 0){ this.scene.remove(s.m); s.m.material.dispose(); this.sparks.splice(i,1); }
    }
    for(let i=this.balls.length-1;i>=0;i--){
      const b = this.balls[i]; b.life -= dt;
      const k = 1 - b.life/b.max;
      b.m.scale.setScalar(b.from + (b.to-b.from)*k);
      b.m.material.opacity = Math.max(0, b.life/b.max)*0.9;
      if(b.life <= 0){ this.scene.remove(b.m); b.m.material.dispose(); this.balls.splice(i,1); }
    }
    for(let i=this.lights.length-1;i>=0;i--){
      const l = this.lights[i]; l.life -= dt;
      l.light.intensity = l.base * Math.max(0, l.life/l.max);
      if(l.life <= 0){ this.scene.remove(l.light); this.lights.splice(i,1); }
    }
    // muzzle flashes
    for(let i=this.flashes.length-1;i>=0;i--){
      const f = this.flashes[i]; f.life -= dt;
      const k = Math.max(0, f.life/f.max);
      f.s.material.opacity = k*0.95;
      f.s.scale.setScalar(f.base*(1 + (1-k)*0.5));
      f.light.intensity = 3.5*k;
      if(f.life <= 0){
        this.scene.remove(f.s); f.s.material.dispose();
        this.scene.remove(f.light);
        this.flashes.splice(i,1);
      }
    }
    // dust / blood puffs
    for(let i=this.puffs.length-1;i>=0;i--){
      const p = this.puffs[i]; p.life -= dt;
      const k = 1 - p.life/p.max;
      p.m.scale.setScalar(p.from + (p.to-p.from)*k);
      p.m.position.addScaledVector(p.m.userData.v, dt);
      p.m.material.opacity = (p.max > 0 ? Math.max(0, p.life/p.max) : 0) * (p.mist ? 0.5 : 0.55);
      if(p.life <= 0){ this.scene.remove(p.m); p.m.material.dispose(); this.puffs.splice(i,1); }
    }
    // shell casings
    for(let i=this.casings.length-1;i>=0;i--){
      const c = this.casings[i]; c.life -= dt;
      c.m.position.addScaledVector(c.m.userData.v, dt);
      c.m.userData.v.y -= 15*dt;
      c.m.rotation.x += c.m.userData.spin.x*dt;
      c.m.rotation.y += c.m.userData.spin.y*dt;
      c.m.rotation.z += c.m.userData.spin.z*dt;
      if(c.m.position.y < 0.03){
        c.m.position.y = 0.03;
        c.m.userData.v.y = Math.abs(c.m.userData.v.y)*0.35;
        c.m.userData.v.x *= 0.6; c.m.userData.v.z *= 0.6;
      }
      if(c.life <= 0){ this.scene.remove(c.m); this.casings.splice(i,1); }
    }
    // shockwave rings
    for(let i=this.rings.length-1;i>=0;i--){
      const r = this.rings[i]; r.life -= dt;
      const k = 1 - r.life/r.max;
      const sc = 0.5 + k*r.to;
      r.m.scale.setScalar(sc);
      r.m.material.opacity = Math.max(0, r.life/r.max)*0.8;
      if(r.life <= 0){ this.scene.remove(r.m); r.m.material.dispose(); this.rings.splice(i,1); }
    }
    for(let i=this.smokes.length-1;i>=0;i--){
      const s = this.smokes[i]; s.life -= dt;
      s.grow = Math.min(1, s.grow + dt*0.8);
      const fadeIn = Math.min(1, s.grow*2);
      const fadeOut = Math.min(1, s.life/2);
      for(const p of s.puffs){
        p.material.opacity = 0.55 * fadeIn * fadeOut;
        p.rotation.x += dt*0.15; p.rotation.y += dt*0.1;
      }
      if(s.life <= 0){
        this.scene.remove(s.group);
        for(const p of s.puffs) p.material.dispose();
        this.smokes.splice(i,1);
      }
    }
    for(let i=this.fires.length-1;i>=0;i--){
      const f = this.fires[i]; f.life -= dt;
      for(const fl of f.flames){
        fl.ph += dt*8;
        const sc = 0.7 + Math.sin(fl.ph)*0.25;
        fl.m.scale.set(1, sc, 1);
        fl.m.material.opacity = 0.75 * Math.min(1, f.life/1.5);
      }
      if(f.life <= 0){
        this.scene.remove(f.group);
        for(const fl of f.flames) fl.m.material.dispose();
        this.fires.splice(i,1);
      }
    }
  }

  clear(){
    const drop = (obj) => { if(obj && obj.material) obj.material.dispose(); };
    for(const t of this.tracers){ this.scene.remove(t.m); drop(t.m); }
    for(const s of this.sparks){ this.scene.remove(s.m); drop(s.m); }
    for(const b of this.balls){ this.scene.remove(b.m); drop(b.m); }
    for(const s of this.smokes){ this.scene.remove(s.group); for(const p of s.puffs) drop(p); }
    for(const f of this.fires){ this.scene.remove(f.group); for(const fl of f.flames) drop(fl.m); }
    for(const l of this.lights){ this.scene.remove(l.light); }
    for(const f of this.flashes){ this.scene.remove(f.s); this.scene.remove(f.light); drop(f.s); }
    for(const p of this.puffs){ this.scene.remove(p.m); drop(p.m); }
    for(const c of this.casings){ this.scene.remove(c.m); }
    for(const r of this.rings){ this.scene.remove(r.m); drop(r.m); }
    this.tracers=[]; this.sparks=[]; this.balls=[]; this.smokes=[]; this.fires=[]; this.lights=[];
    this.flashes=[]; this.puffs=[]; this.casings=[]; this.rings=[];
  }
}

function segCircle(ax,az,bx,bz,cx,cz,r){
  const dx=bx-ax, dz=bz-az;
  const fx=ax-cx, fz=az-cz;
  const a=dx*dx+dz*dz;
  if(a < 0.0001) return (fx*fx+fz*fz) <= r*r;
  let t = -(fx*dx+fz*dz)/a;
  t = Math.max(0, Math.min(1, t));
  const px=ax+dx*t-cx, pz=az+dz*t-cz;
  return px*px+pz*pz <= r*r;
}
