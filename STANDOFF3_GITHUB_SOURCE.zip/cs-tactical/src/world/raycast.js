// Grid raycasting against the level (walls have per-cell heights).
import { isSolid } from '../data/maps.js';

export function raycastWorld(map, ox, oy, oz, dx, dy, dz, maxT){
  const tile = map.tile;
  let cx = Math.floor(ox / tile);
  let cy = Math.floor(oz / tile);
  const stepX = dx > 0 ? 1 : -1;
  const stepY = dz > 0 ? 1 : -1;

  const tDeltaX = dx !== 0 ? Math.abs(tile / dx) : Infinity;
  const tDeltaZ = dz !== 0 ? Math.abs(tile / dz) : Infinity;

  let tMaxX = dx > 0 ? ((cx + 1) * tile - ox) / dx
            : dx < 0 ? (cx * tile - ox) / dx
            : Infinity;
  let tMaxY = dz > 0 ? ((cy + 1) * tile - oz) / dz
            : dz < 0 ? (cy * tile - oz) / dz
            : Infinity;

  let t = 0;
  let side = 0;
  let guard = 0;

  // check starting cell
  if(isSolid(map, cx, cy)){
    const h = map.heights[cy * map.w + cx];
    if(oy + dy * 0 < h) return { hit:true, t:0, x:ox, y:oy, z:oz, side };
  }

  while(t <= maxT && guard++ < 512){
    let nx = cx, ny = cy;
    if(tMaxX < tMaxY){ nx += stepX; t = tMaxX; tMaxX += tDeltaX; side = 0; }
    else { ny += stepY; t = tMaxY; tMaxY += tDeltaZ; side = 1; }

    if(nx < 0 || ny < 0 || nx >= map.w || ny >= map.h){
      return { hit:true, t:Math.min(t, maxT), x:ox+dx*t, y:oy+dy*t, z:oz+dz*t, side };
    }
    cx = nx; cy = ny;
    if(t > maxT) break;

    if(isSolid(map, cx, cy)){
      const h = map.heights[cy * map.w + cx];
      const rayY = oy + dy * t;
      if(rayY < h){
        return {
          hit:true, t, x:ox+dx*t, y:rayY, z:oz+dz*t, side,
          cx, cy, height:h
        };
      }
    }
  }
  return { hit:false, t:maxT, x:ox+dx*maxT, y:oy+dy*maxT, z:oz+dz*maxT, side };
}

export function lineOfSight(map, ax, ay, az, bx, by, bz){
  const dx = bx-ax, dy = by-ay, dz = bz-az;
  const len = Math.hypot(dx,dy,dz);
  if(len < 0.0001) return true;
  const r = raycastWorld(map, ax, ay, az, dx/len, dy/len, dz/len, len - 0.05);
  return !r.hit;
}

// cheap 2D walkable line check for path smoothing
export function walkLineClear(map, ax, az, bx, bz){
  const dx = bx-ax, dz = bz-az;
  const len = Math.hypot(dx,dz);
  const steps = Math.ceil(len / (map.tile * 0.4));
  for(let i=0; i<=steps; i++){
    const t = i / steps;
    const x = ax + dx*t, z = az + dz*t;
    if(isSolid(map, Math.floor(x/map.tile), Math.floor(z/map.tile))) return false;
  }
  return true;
}

// ray vs sphere helper, returns t or -1
export function raySphere(ox, oy, oz, dx, dy, dz, cx, cy, cz, r){
  const lx = cx-ox, ly = cy-oy, lz = cz-oz;
  const tca = lx*dx + ly*dy + lz*dz;
  if(tca < 0) return -1;
  const d2 = (lx*lx+ly*ly+lz*lz) - tca*tca;
  const r2 = r*r;
  if(d2 > r2) return -1;
  const thc = Math.sqrt(r2 - d2);
  const t0 = tca - thc;
  return t0 >= 0 ? t0 : (tca + thc >= 0 ? 0 : -1);
}
