import * as esbuild from 'esbuild';

const watch = process.argv.includes('--watch');

const opts = {
  entryPoints: ['src/main.js'],
  bundle: true,
  format: 'iife',
  outfile: 'dist/bundle.js',
  target: ['es2020'],
  minify: false,
  sourcemap: false,
  legalComments: 'none',
  logLevel: 'info'
};

if(watch){
  const ctx = await esbuild.context(opts);
  await ctx.watch();
  console.log('watching...');
} else {
  await esbuild.build(opts);
  console.log('build complete -> dist/bundle.js');
}
