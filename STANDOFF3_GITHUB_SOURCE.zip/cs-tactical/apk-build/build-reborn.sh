#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
cd "$(dirname "$0")"

ROOT="$(cd .. && pwd)"
KEYSTORE="${HOME}/.android/debug.keystore"

cp "$ROOT/dist/bundle.js" assets/www/dist/bundle.js
cp "$ROOT/index.html" assets/www/index.html
cp "$ROOT/css/style.css" assets/www/css/style.css

rm -rf out
mkdir -p out

aapt package -f -M AndroidManifest.xml -S res -I android.jar -A assets -F out/app-unsigned.apk
zip -q -j out/app-unsigned.apk dex/classes.dex
zipalign -f 4 out/app-unsigned.apk out/aligned.apk
apksigner sign \
  --ks "$KEYSTORE" \
  --ks-pass pass:android \
  --key-pass pass:android \
  --ks-key-alias androiddebugkey \
  --out out/Standoff3Reborn.apk \
  out/aligned.apk
apksigner verify --print-certs out/Standoff3Reborn.apk

cp out/Standoff3Reborn.apk Standoff3.apk
cp out/Standoff3Reborn.apk "$ROOT/Standoff3Reborn.apk"
ls -lh "$ROOT/Standoff3Reborn.apk"
